"use client";

import Link from "next/link";

export default function AccessDeniedPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center bg-white rounded-2xl shadow-lg p-8">
        <span className="material-symbols-outlined text-6xl text-red-500 mb-4 block">
          block
        </span>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Access Denied
        </h1>
        <p className="text-gray-600 mb-6">
          Direct access to this resource is not allowed. Please use the
          application normally.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-medium"
        >
          <span className="material-symbols-outlined">home</span>
          Go to Homepage
        </Link>
      </div>
    </div>
  );
}
