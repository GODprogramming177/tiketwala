"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import Navbar from "@/components/Navbar";

/**
 * Worker Landing Page
 * Shows permission-gated large buttons for POS Terminal and Scan Tickets.
 * Workers only see the buttons their posPermissions allow.
 */
export default function WorkerLandingPage() {
  const router = useRouter();
  const {
    admin,
    logout,
    loading: authLoading,
    isWorker,
    isOwner,
    isSuperAdmin,
    hasPosPermission,
  } = useAdminAuth();

  useEffect(() => {
    if (!authLoading && !admin) {
      router.replace("/admin/login");
      return;
    }
    // Non-workers go to admin dashboard
    if (!authLoading && admin && !isWorker() && !isOwner() && !isSuperAdmin()) {
      router.replace("/admin");
    }
  }, [admin, authLoading, isOwner, isSuperAdmin, isWorker, router]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }
  if (!admin) return null;

  const canPos = hasPosPermission("pos");
  const canScan = hasPosPermission("scan");

  const handleLogout = () => {
    logout();
    router.replace("/admin/login");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">
        <section className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 sm:p-8 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-5">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center">
                <span className="material-symbols-outlined text-3xl text-primary">
                  person
                </span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Worker Workspace
                </h1>
                <p className="text-gray-500 text-sm mt-1">
                  Signed in as {admin.name || admin.email}
                </p>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors font-medium"
            >
              <span className="material-symbols-outlined text-lg">logout</span>
              Logout
            </button>
          </div>

          <div className="mt-6 rounded-2xl border border-primary/10 bg-primary/5 px-4 py-3 text-sm text-primary flex items-start gap-2">
            <span className="material-symbols-outlined text-base mt-0.5">
              info
            </span>
            Use POS for walk-in ticket sales and Scan to validate entry/exit.
          </div>
        </section>

        <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {canPos && (
            <button
              onClick={() => router.push("/worker/pos")}
              className="group relative bg-white border-2 border-primary/20 rounded-2xl p-6 hover:border-primary hover:shadow-lg transition-all text-left overflow-hidden"
            >
              <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary transition-colors">
                  <span className="material-symbols-outlined text-3xl text-primary group-hover:text-white">
                    point_of_sale
                  </span>
                </div>
                <h2 className="text-lg font-bold text-gray-900">
                  POS Terminal
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                  Issue walk-in tickets, collect payment, and print receipts.
                </p>
              </div>
            </button>
          )}

          {canScan && (
            <button
              onClick={() => router.push("/worker/scan")}
              className="group relative bg-white border-2 border-green-200 rounded-2xl p-6 hover:border-green-500 hover:shadow-lg transition-all text-left overflow-hidden"
            >
              <div className="absolute inset-0 bg-green-50 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className="w-14 h-14 bg-green-50 rounded-xl flex items-center justify-center mb-4 group-hover:bg-green-500 transition-colors">
                  <span className="material-symbols-outlined text-3xl text-green-600 group-hover:text-white">
                    qr_code_scanner
                  </span>
                </div>
                <h2 className="text-lg font-bold text-gray-900">
                  Scan Tickets
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                  Validate customer tickets via QR for entry and exit.
                </p>
              </div>
            </button>
          )}
        </section>

        {!canPos && !canScan && (
          <div className="mt-6 bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center">
            <span className="material-symbols-outlined text-3xl text-amber-500 mb-2">
              warning
            </span>
            <p className="text-amber-700 font-medium">
              No permissions assigned
            </p>
            <p className="text-amber-600 text-sm mt-1">
              Contact your admin to get POS or Scan access.
            </p>
          </div>
        )}

        {canPos && (
          <div className="mt-6">
            <button
              onClick={() => router.push("/worker/dashboard")}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-gray-200 text-gray-600 hover:text-primary hover:border-primary/30 transition-colors"
            >
              <span className="material-symbols-outlined text-lg">
                insights
              </span>
              View Sales History
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
