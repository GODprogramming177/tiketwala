"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import QRScanner from "@/components/QRScanner";

export default function WorkerScanPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    isWorker,
    isOwner,
    isSuperAdmin,
    hasPosPermission,
  } = useAdminAuth();

  const [showScanner, setShowScanner] = useState(true);

  /* ── Auth guard ───────────────────────── */
  useEffect(() => {
    if (!authLoading && !admin) {
      router.replace("/admin/login");
      return;
    }
    if (
      !authLoading &&
      admin &&
      !isWorker() &&
      !isOwner() &&
      !isSuperAdmin()
    ) {
      router.replace("/admin");
    }
    if (!authLoading && admin?.role === "worker" && !hasPosPermission("scan")) {
      router.replace("/worker");
    }
  }, [admin, authLoading, hasPosPermission, isOwner, isSuperAdmin, isWorker, router]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }
  if (!admin) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="flex-1 py-10 px-4">
        <div className="max-w-lg mx-auto text-center">
          <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <span className="material-symbols-outlined text-primary text-4xl">
              qr_code_scanner
            </span>
          </div>
          <h1 className="text-3xl font-bold text-primary mb-3">
            Ticket Scanner
          </h1>
          <p className="text-gray-500 mb-8 max-w-sm mx-auto">
            Scan customer QR codes to validate entry or exit, or enter booking IDs manually.
          </p>

          {!showScanner ? (
            <button
              onClick={() => setShowScanner(true)}
              className="w-full flex items-center justify-center gap-2 py-4 bg-primary text-white rounded-xl font-bold text-lg hover:bg-primary/90 transition-all shadow-xl hover:shadow-2xl hover:-translate-y-1"
            >
              <span className="material-symbols-outlined text-2xl">
                camera_alt
              </span>
              Open Scanner
            </button>
          ) : (
            <p className="text-sm font-medium text-primary bg-primary/10 py-2 px-4 rounded-lg inline-block">
              Scanner is active...
            </p>
          )}

          <div className="mt-8 text-xs text-gray-400">
            Ensure you have granted camera permissions to use the QR scanner.
          </div>
        </div>
      </div>

      {showScanner && (
        <QRScanner
          onScan={(result) => {
            // result is handled inside QRScanner entirely
          }}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  );
}
