"use client";

import { useEffect, useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import SlotGrid from "@/components/SlotGrid";
import TicketQR from "@/components/TicketQR";
import PosPaymentButton from "@/components/PosPaymentButton";
import WorldlinePaymentModal from "@/components/WorldlinePaymentModal";
import PaymentMethodModal from "@/components/PaymentMethodModal";
import SetuPaymentModal from "@/components/SetuPaymentModal";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import { calculatePropertyPricing } from "@/lib/listingUtils";

export default function WorkerPosPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    authHeaders,
    getBusinessId,
    isWorker,
    isOwner,
    isSuperAdmin,
    hasPosPermission,
  } = useAdminAuth();

  const [listings, setListings] = useState([]);
  const [selectedListingId, setSelectedListingId] = useState("");
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState(null);
  const [attendeeCounts, setAttendeeCounts] = useState({
    adult: 1,
    child: 0,
  });
  const [selectedAddOns, setSelectedAddOns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [ticket, setTicket] = useState(null);
  const [showTicket, setShowTicket] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [showPaymentMethodModal, setShowPaymentMethodModal] = useState(false);
  const [showWorldlineModal, setShowWorldlineModal] = useState(false);
  const [worldlineActionId, setWorldlineActionId] = useState("1");
  const [showSetuModal, setShowSetuModal] = useState(false);
  const [posInvoiceNo, setPosInvoiceNo] = useState("");
  const [customer, setCustomer] = useState({
    name: "",
    email: "",
    phone: "",
  });
  const quantity = Math.max(
    1,
    (Number(attendeeCounts.adult) || 0) + (Number(attendeeCounts.child) || 0),
  );

  /* ── Auth guard ───────────────────────── */
  useEffect(() => {
    if (!authLoading && !admin) {
      router.replace("/admin/login");
      return;
    }
    if (!authLoading && admin && !isWorker() && !isOwner() && !isSuperAdmin()) {
      router.replace("/admin");
    }
    if (!authLoading && admin?.role === "worker" && !hasPosPermission("pos")) {
      router.replace("/worker");
    }
  }, [
    admin,
    authLoading,
    hasPosPermission,
    isOwner,
    isSuperAdmin,
    isWorker,
    router,
  ]);

  useEffect(() => {
    if (admin) fetchListings();
  }, [admin]);

  /* ── Auto-select first sub-category ────── */
  useEffect(() => {
    if (selectedListingId && listings.length > 0) {
      const listing = listings.find((l) => l.id === selectedListingId);
      if (
        listing &&
        Array.isArray(listing.subCategories) &&
        listing.subCategories.length > 0
      ) {
        const initial = listing.subCategories[0];
        setSelectedSubCategory(initial);
        fetchSlots(selectedListingId, initial.id);
      } else {
        setSelectedSubCategory(null);
        fetchSlots(selectedListingId, null);
      }
      setSelectedAddOns([]);
      setSelectedSlot(null);
    }
  }, [selectedListingId, listings]);

  /* ── Re-fetch slots on sub-category change ── */
  useEffect(() => {
    if (selectedListingId && selectedSubCategory) {
      fetchSlots(selectedListingId, selectedSubCategory.id);
      setSelectedSlot(null);
    }
  }, [selectedSubCategory?.id]);

  /* ── Data fetchers ─────────────────────── */
  const fetchListings = async () => {
    try {
      setLoading(true);
      const businessId = getBusinessId();
      const url = businessId
        ? `/api/listings?businessId=${businessId}`
        : "/api/listings";
      const res = await fetch(url, {
        headers: businessId ? authHeaders() : undefined,
      });
      const data = await res.json();
      const next = Array.isArray(data) ? data : [];
      setListings(next);
      setSelectedListingId(next[0]?.id || "");
    } catch {
      toast.error("Unable to load POS listings");
    } finally {
      setLoading(false);
    }
  };

  const fetchSlots = async (listingId, subCatId) => {
    try {
      const url = subCatId
        ? `/api/slots?id=${listingId}&subCategoryId=${subCatId}`
        : `/api/slots?id=${listingId}`;
      const res = await fetch(url, { headers: authHeaders() });
      const data = await res.json();
      setSlots(Array.isArray(data.slots) ? data.slots : []);
    } catch {
      toast.error("Unable to load slots");
      setSlots([]);
    }
  };

  /* ── Filter slots to today only ─────────── */
  const todayStr = useMemo(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  }, []);

  const todaySlots = useMemo(() => {
    return slots.filter((s) => {
      const slotDate = s.start?.split("T")[0];
      return slotDate === todayStr;
    });
  }, [slots, todayStr]);

  /* ── Derived state ─────────────────────── */
  const selectedListing = listings.find((l) => l.id === selectedListingId);
  const subCategories = Array.isArray(selectedListing?.subCategories)
    ? selectedListing.subCategories
    : [];

  const availableAddOns = selectedSubCategory?.addOns
    ? Array.isArray(selectedSubCategory.addOns)
      ? selectedSubCategory.addOns
      : []
    : Array.isArray(selectedListing?.addOns)
      ? selectedListing.addOns
      : [];

  const pricingPreview = useMemo(
    () =>
      calculatePropertyPricing(selectedListing, {
        quantity,
        attendeeCounts,
        selectedSubCategory:
          selectedSubCategory?.id || selectedSubCategory?.name || null,
        selectedOffering:
          selectedSubCategory?.id || selectedSubCategory?.name || null,
        selectedAddOns,
      }),
    [
      attendeeCounts,
      quantity,
      selectedAddOns,
      selectedListing,
      selectedSubCategory,
    ],
  );
  const normalizedAttendeeCounts = pricingPreview.attendeeCounts || {
    adult: Math.max(0, Number(attendeeCounts.adult) || 0),
    child: Math.max(0, Number(attendeeCounts.child) || 0),
  };
  const selectedAddOnDetails = pricingPreview.selectedAddOns || [];
  const basePrice = pricingPreview.unitPrice || 0;
  const baseAmount = pricingPreview.baseAmount || 0;
  const addOnAmount = pricingPreview.addOnAmount || 0;
  const totalAmount = pricingPreview.totalAmount || 0;
  const fareBreakdown = Array.isArray(pricingPreview.fareBreakdown)
    ? pricingPreview.fareBreakdown
    : [];

  const toggleAddOn = (key) =>
    setSelectedAddOns((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
  const setAttendeeCount = (type, nextValue) => {
    const safeNextValue = Math.max(0, Number(nextValue) || 0);
    setAttendeeCounts((prev) => {
      let nextAdult = type === "adult" ? safeNextValue : prev.adult;
      let nextChild = type === "child" ? safeNextValue : prev.child;

      if (nextAdult + nextChild < 1) {
        nextAdult = 1;
        nextChild = 0;
      }

      if (nextAdult + nextChild > 20) {
        if (type === "adult") {
          nextAdult = Math.max(0, 20 - nextChild);
        } else {
          nextChild = Math.max(0, 20 - nextAdult);
        }
      }

      if (nextAdult + nextChild < 1) {
        nextAdult = 1;
        nextChild = 0;
      }

      return { adult: nextAdult, child: nextChild };
    });
  };

  /* ── Razorpay callbacks ─────────────────── */
  const handlePaymentSuccess = (response) => {
    if (response?.booking) {
      setTicket(response.booking);
      setPaymentStatus("success");
      setShowTicket(true);
      toast.success("Payment received & ticket issued!");
      resetForm();
      fetchSlots(selectedListingId, selectedSubCategory?.id);
    } else {
      setPaymentStatus("error");
    }
  };

  const handleWorldlineSuccess = async (data) => {
    // Ideally, here we would call a backend endpoint to finalize the booking 
    // using the Worldline transaction ID. For this demonstration, we'll
    // mock a ticket object so the receipt prints.
    const mockBooking = {
      bookingId: `WL-${data.transactionId || Date.now()}`,
      listingName: selectedListing?.name,
      amount: totalAmount,
      paymentMode: "POS",
      createdAt: new Date().toISOString()
    };
    handlePaymentSuccess({ booking: mockBooking });
  };

  const handlePaymentError = () => {
    setPaymentStatus("error");
    toast.error("Payment failed. Please retry.");
  };

  const resetForm = () => {
    setCustomer({ name: "", email: "", phone: "" });
    setAttendeeCounts({ adult: 1, child: 0 });
    setSelectedAddOns([]);
    setSelectedSlot(null);
    setPaymentStatus(null);
  };

  /* ── Guards ─────────────────────────────── */
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }
  if (!admin) return null;

  /* ── Render ─────────────────────────────── */
  return (
    <div className="min-h-screen bg-gray-50 pb-24 lg:pb-6">
      <Navbar />

      {showTicket && ticket && (
        <TicketQR booking={ticket} onClose={() => setShowTicket(false)} />
      )}

      <div className="py-4 sm:py-6">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          {/* ── Header ──────────────────────── */}
          <div className="mb-5 sm:mb-6">
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-primary flex items-center gap-2">
              <span className="material-symbols-outlined text-2xl sm:text-3xl">
                point_of_sale
              </span>
              POS Booking Desk
            </h1>
            <p className="text-gray-500 mt-1 text-xs sm:text-sm">
              Issue walk-in tickets for today. Collect payment via Razorpay,
              then print the ticket.
            </p>
          </div>

          {loading ? (
            <PosLoadingSkeleton />
          ) : (
            <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
              {/* ════════ LEFT COLUMN ════════ */}
              <div className="flex-1 min-w-0 space-y-4">
                {/* ── Step 1 · Customer + Guests ── */}
                <PosCard step="1" title="Customer & Guests" icon="person">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <InputField
                      label="Customer Name (Optional)"
                      value={customer.name}
                      onChange={(v) => setCustomer((p) => ({ ...p, name: v }))}
                      placeholder="Full name"
                    />
                    <InputField
                      label="Email (Optional)"
                      type="email"
                      value={customer.email}
                      onChange={(v) => setCustomer((p) => ({ ...p, email: v }))}
                      placeholder="email@example.com"
                    />
                    <InputField
                      label="Phone (Optional)"
                      value={customer.phone}
                      onChange={(v) => setCustomer((p) => ({ ...p, phone: v }))}
                      placeholder="+91 ..."
                    />
                  </div>

                  <div className="mt-4 flex items-center gap-3 flex-wrap">
                    <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">
                      Visitors
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="rounded-xl border border-gray-200 p-3 bg-white">
                      <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">
                        Adults
                      </p>
                      <div className="mt-2 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "adult",
                              normalizedAttendeeCounts.adult - 1,
                            )
                          }
                          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined text-lg">
                            remove
                          </span>
                        </button>
                        <span className="text-xl font-bold text-primary w-8 text-center">
                          {normalizedAttendeeCounts.adult}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "adult",
                              normalizedAttendeeCounts.adult + 1,
                            )
                          }
                          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined text-lg">
                            add
                          </span>
                        </button>
                      </div>
                    </div>

                    <div className="rounded-xl border border-gray-200 p-3 bg-white">
                      <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">
                        Children
                      </p>
                      <div className="mt-2 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "child",
                              normalizedAttendeeCounts.child - 1,
                            )
                          }
                          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined text-lg">
                            remove
                          </span>
                        </button>
                        <span className="text-xl font-bold text-primary w-8 text-center">
                          {normalizedAttendeeCounts.child}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "child",
                              normalizedAttendeeCounts.child + 1,
                            )
                          }
                          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined text-lg">
                            add
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 rounded-xl bg-primary/5 border border-primary/10 px-4 py-3 text-sm text-primary">
                    Total visitors: {quantity}. Child fare is applied from the
                    selected ticket type when configured.
                  </div>
                </PosCard>

                {/* ── Step 2 · Listing ── */}
                <PosCard step="2" title="Choose Listing" icon="storefront">
                  <label className="block text-[11px] font-semibold text-gray-500 uppercase tracking-wider mb-1">
                    Listing
                  </label>
                  <select
                    value={selectedListingId}
                    onChange={(e) => setSelectedListingId(e.target.value)}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-primary/40 text-sm"
                  >
                    {listings.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name} — {l.type}
                      </option>
                    ))}
                  </select>

                  {/* Sub-Category Cards */}
                  {subCategories.length > 0 && (
                    <div className="mt-3">
                      <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider mb-2">
                        Ticket Type
                      </p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {subCategories.map((sub) => {
                          const active =
                            selectedSubCategory?.id === sub.id ||
                            selectedSubCategory?.name === sub.name;
                          return (
                            <button
                              key={sub.id || sub.name}
                              onClick={() => {
                                setSelectedSubCategory(sub);
                                setSelectedAddOns([]);
                              }}
                              className={`rounded-xl border-2 p-2.5 sm:p-3 text-left transition-all ${
                                active
                                  ? "border-primary bg-primary/5 shadow-sm"
                                  : "border-gray-200 hover:border-primary/30 bg-white"
                              }`}
                            >
                              <p className="font-semibold text-gray-800 text-xs sm:text-sm leading-tight">
                                {sub.name}
                              </p>
                              {sub.description && (
                                <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">
                                  {sub.description}
                                </p>
                              )}
                              <p className="text-sm sm:text-base font-bold text-primary mt-1">
                                ₹{sub.price}
                              </p>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Quick info */}
                  <div className="mt-3 flex items-center gap-2 rounded-lg bg-accent/60 px-3 py-2">
                    <span className="material-symbols-outlined text-primary text-base">
                      info
                    </span>
                    <span className="text-[11px] sm:text-xs text-gray-600 truncate">
                      <strong className="text-primary">
                        {selectedListing?.name}
                      </strong>
                      {selectedSubCategory
                        ? ` · ${selectedSubCategory.name}`
                        : ""}
                      {selectedListing?.location
                        ? ` — ${selectedListing.location}`
                        : ""}
                    </span>
                  </div>
                </PosCard>

                {/* ── Step 3 · Today's Slots ── */}
                <PosCard
                  step="3"
                  title={`Today's Slots (${todayStr})`}
                  icon="schedule"
                >
                  {todaySlots.length > 0 ? (
                    <SlotGrid
                      slots={todaySlots}
                      selectedSlot={selectedSlot}
                      onSelectSlot={setSelectedSlot}
                    />
                  ) : (
                    <div className="text-center py-6">
                      <span className="material-symbols-outlined text-4xl text-gray-300">
                        event_busy
                      </span>
                      <p className="mt-2 text-sm text-gray-500">
                        No slots available for today.
                      </p>
                    </div>
                  )}
                </PosCard>

                {/* ── Step 4 · Add-ons ── */}
                {availableAddOns.length > 0 && (
                  <PosCard step="4" title="Add-ons" icon="add_circle">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {availableAddOns.map((addOn) => {
                        const key = addOn.id || addOn.name;
                        const checked = selectedAddOns.includes(key);
                        const chargeLabel =
                          addOn.chargeType === "per_person"
                            ? "per person"
                            : "per booking";
                        return (
                          <label
                            key={key}
                            className={`flex items-start gap-2 rounded-xl border-2 p-2.5 sm:p-3 cursor-pointer transition-all ${
                              checked
                                ? "border-primary bg-primary/5"
                                : "border-gray-200 hover:border-primary/30 bg-white"
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => toggleAddOn(key)}
                              className="mt-0.5 h-4 w-4 accent-primary"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <p className="font-medium text-gray-800 text-xs sm:text-sm truncate">
                                  {addOn.name}
                                </p>
                                <p className="font-semibold text-primary text-xs sm:text-sm whitespace-nowrap">
                                  +₹{addOn.price}
                                </p>
                              </div>
                              <p className="text-[10px] text-gray-400 uppercase tracking-wide mt-0.5">
                                {chargeLabel}
                              </p>
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </PosCard>
                )}
              </div>

              {/* ════════ RIGHT COLUMN / SIDEBAR ════════ */}
              <div className="w-full lg:w-85 xl:w-90 lg:shrink-0 space-y-4 lg:sticky lg:top-20 self-start">
                {/* ── Summary ──────────────────── */}
                <div className="bg-white rounded-2xl shadow-md p-4 sm:p-5">
                  <h2 className="text-sm sm:text-base font-semibold text-primary mb-3 flex items-center gap-2">
                    <span className="material-symbols-outlined text-lg">
                      receipt_long
                    </span>
                    POS Summary
                  </h2>
                  <div className="space-y-2 text-sm">
                    <SummaryRow
                      label={`Ticket ${selectedSubCategory ? `(${selectedSubCategory.name})` : ""}`}
                      value={`₹${basePrice}`}
                    />
                    <SummaryRow
                      label="Adults"
                      value={String(normalizedAttendeeCounts.adult)}
                    />
                    <SummaryRow
                      label="Children"
                      value={String(normalizedAttendeeCounts.child)}
                    />
                    <SummaryRow label="Guests" value={`× ${quantity}`} />
                    {fareBreakdown.map((item) => (
                      <SummaryRow
                        key={item.key}
                        label={`${item.label} • ${item.count}`}
                        value={`₹${item.total}`}
                      />
                    ))}
                    {selectedAddOnDetails.map((a) => {
                      const mul = a.chargeType === "per_person" ? quantity : 1;
                      return (
                        <SummaryRow
                          key={a.id || a.name}
                          label={a.name}
                          value={`₹${(Number(a.price) || 0) * mul}`}
                        />
                      );
                    })}
                    <div className="border-t border-gray-100 pt-2 mt-2">
                      <SummaryRow
                        label="Base subtotal"
                        value={`₹${baseAmount}`}
                      />
                      <SummaryRow label="Add-ons" value={`₹${addOnAmount}`} />
                    </div>
                    <div className="flex justify-between pt-2 border-t border-gray-200 text-base sm:text-lg font-bold text-primary">
                      <span>Total</span>
                      <span>₹{totalAmount}</span>
                    </div>
                  </div>

                  {/* ── Razorpay Payment ── */}
                  <div className="mt-5 flex flex-col gap-3">
                    <PosPaymentButton
                      amount={totalAmount}
                      listingName={selectedListing?.name}
                      listingId={selectedListingId}
                      quantity={quantity}
                      attendeeCounts={normalizedAttendeeCounts}
                      slot={selectedSlot}
                      customerName={customer.name}
                      customerEmail={customer.email || undefined}
                      customerPhone={customer.phone || undefined}
                      selectedAddOns={selectedAddOns}
                      selectedOffering={
                        selectedSubCategory?.id ||
                        selectedSubCategory?.name ||
                        null
                      }
                      disabled={!selectedSlot || !selectedListingId}
                      onSuccess={handlePaymentSuccess}
                      onError={handlePaymentError}
                    />

                    <button
                      type="button"
                      onClick={() => {
                        setPosInvoiceNo(`INV-${Date.now()}`);
                        setShowPaymentMethodModal(true);
                      }}
                      disabled={!selectedSlot || !selectedListingId}
                      className={`
                        w-full flex items-center justify-center gap-2 px-6 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg
                        transition-all duration-200 border-2
                        ${
                          !selectedSlot || !selectedListingId
                            ? "border-gray-300 text-gray-400 cursor-not-allowed bg-gray-50"
                            : "border-primary text-primary hover:bg-primary/5 active:bg-primary/10"
                        }
                      `}
                    >
                      <span className="material-symbols-outlined">point_of_sale</span>
                      Pay via POS Terminal
                    </button>
                  </div>

                  {!selectedSlot && (
                    <p className="text-center text-[11px] text-gray-400 mt-2 flex items-center justify-center gap-1">
                      <span className="material-symbols-outlined text-xs">
                        info
                      </span>
                      Select a slot to continue
                    </p>
                  )}
                  {paymentStatus === "error" && (
                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs text-red-700">
                      <span className="material-symbols-outlined text-red-500 text-base">
                        error
                      </span>
                      Payment failed. Please retry.
                    </div>
                  )}
                </div>

                {/* Recent ticket quick-print */}
                {ticket && !showTicket && (
                  <div className="bg-white rounded-2xl shadow-md p-4 sm:p-5">
                    <h2 className="text-sm font-semibold text-primary mb-2 flex items-center gap-2">
                      <span className="material-symbols-outlined text-lg">
                        confirmation_number
                      </span>
                      Last Ticket
                    </h2>
                    <p className="text-xs text-gray-500 mb-3">
                      {ticket.bookingId} — {ticket.listingName}
                    </p>
                    <button
                      onClick={() => setShowTicket(true)}
                      className="w-full flex items-center justify-center gap-2 py-2.5 bg-primary/10 text-primary rounded-xl text-sm font-medium hover:bg-primary/20 transition-colors"
                    >
                      <span className="material-symbols-outlined text-lg">
                        print
                      </span>
                      View / Print Ticket
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Mobile sticky bottom bar ──────── */}
      <div className="lg:hidden fixed inset-x-0 bottom-0 z-40 border-t border-gray-200 bg-white/95 backdrop-blur-md px-3 py-2.5 shadow-[0_-6px_20px_rgba(0,0,0,0.06)]">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[10px] text-gray-400 uppercase tracking-wide">
              Total
            </p>
            <p className="text-lg font-bold text-primary">₹{totalAmount}</p>
          </div>
          <div className="flex-1 max-w-50 flex flex-col gap-2">
            <PosPaymentButton
              amount={totalAmount}
              listingName={selectedListing?.name}
              listingId={selectedListingId}
              quantity={quantity}
              attendeeCounts={normalizedAttendeeCounts}
              slot={selectedSlot}
              customerName={customer.name}
              customerEmail={customer.email || undefined}
              customerPhone={customer.phone || undefined}
              selectedAddOns={selectedAddOns}
              selectedOffering={
                selectedSubCategory?.id || selectedSubCategory?.name || null
              }
              disabled={!selectedSlot || !selectedListingId}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />

            <button
              type="button"
              onClick={() => {
                setPosInvoiceNo(`INV-${Date.now()}`);
                setShowPaymentMethodModal(true);
              }}
              disabled={!selectedSlot || !selectedListingId}
              className={`
                w-full flex items-center justify-center gap-2 px-4 py-2 sm:py-3 rounded-xl font-semibold text-sm sm:text-base
                transition-all duration-200 border-2
                ${
                  !selectedSlot || !selectedListingId
                    ? "border-gray-300 text-gray-400 cursor-not-allowed bg-gray-50"
                    : "border-primary text-primary hover:bg-primary/5 active:bg-primary/10"
                }
              `}
            >
              <span className="material-symbols-outlined text-lg">point_of_sale</span>
              Pay via POS
            </button>
          </div>
        </div>
      </div>

      {/* ═══ Recent POS Bookings ═══ */}
      <RecentPosBookings authHeaders={authHeaders} />

      <PaymentMethodModal
        isOpen={showPaymentMethodModal}
        onClose={() => setShowPaymentMethodModal(false)}
        amount={totalAmount}
        onSelectMethod={(method) => {
          setShowPaymentMethodModal(false);
          if (method === "worldline") {
            setWorldlineActionId("1");
            setShowWorldlineModal(true);
          } else if (method === "worldline-upi") {
            setWorldlineActionId("133");
            setShowWorldlineModal(true);
          } else if (method === "setu") {
            setShowSetuModal(true);
          }
        }}
      />

      {/* Worldline POS Modal */}
      <WorldlinePaymentModal
        isOpen={showWorldlineModal}
        onClose={() => setShowWorldlineModal(false)}
        amount={totalAmount}
        invoiceNo={posInvoiceNo}
        actionId={worldlineActionId}
        onSuccess={handleWorldlineSuccess}
        onError={() => setPaymentStatus("error")}
      />

      {/* Setu UPI Modal */}
      <SetuPaymentModal
        isOpen={showSetuModal}
        onClose={() => setShowSetuModal(false)}
        amount={totalAmount}
        invoiceNo={posInvoiceNo}
        onSuccess={handleWorldlineSuccess}
        onError={() => setPaymentStatus("error")}
      />
    </div>
  );
}

/* ═════════════════════════════════════════
   Sub-components
   ═════════════════════════════════════════ */

function PosCard({ step, title, icon, children }) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-3.5 sm:p-5">
      <h2 className="text-sm sm:text-base font-semibold text-primary mb-3 flex items-center gap-2">
        <span className="inline-flex items-center justify-center w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-primary text-white text-[10px] sm:text-xs font-bold shrink-0">
          {step}
        </span>
        <span className="material-symbols-outlined text-base sm:text-lg">
          {icon}
        </span>
        {title}
      </h2>
      {children}
    </div>
  );
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex justify-between text-gray-600 text-xs sm:text-sm">
      <span className="truncate mr-2">{label}</span>
      <span className="whitespace-nowrap font-medium">{value}</span>
    </div>
  );
}

function InputField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  ...rest
}) {
  return (
    <div>
      <label className="block text-[11px] font-semibold text-gray-500 uppercase tracking-wider mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3 py-2 sm:py-2.5 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-primary/40 text-sm"
        {...rest}
      />
    </div>
  );
}

function PosLoadingSkeleton() {
  return (
    <div className="flex flex-col lg:flex-row gap-5 animate-pulse">
      <div className="flex-1 space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-2xl shadow-md p-5">
            <div className="h-4 bg-gray-200 rounded w-40 mb-4" />
            <div className="h-10 bg-gray-200 rounded-xl mb-3" />
            {i === 1 && (
              <div className="grid grid-cols-3 gap-2">
                <div className="h-16 bg-gray-200 rounded-xl" />
                <div className="h-16 bg-gray-200 rounded-xl" />
                <div className="h-16 bg-gray-200 rounded-xl" />
              </div>
            )}
            {i === 2 && (
              <div className="grid grid-cols-3 gap-2">
                {[...Array(6)].map((_, j) => (
                  <div key={j} className="h-12 bg-gray-200 rounded-lg" />
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="w-full lg:w-90 space-y-4">
        <div className="bg-white rounded-2xl shadow-md p-5">
          <div className="h-4 bg-gray-200 rounded w-24 mb-4" />
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-3 bg-gray-200 rounded mb-2" />
          ))}
          <div className="h-12 bg-gray-200 rounded-xl mt-4" />
        </div>
      </div>
    </div>
  );
}

function RecentPosBookings({ authHeaders }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState(null);

  const todayIso = new Date().toISOString().slice(0, 10);

  const fetchBookings = async (p = 1) => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        date: todayIso,
        page: String(p),
        limit: "10",
      });
      const res = await fetch(`/api/pos/bookings?${params}`, {
        headers: authHeaders(),
      });
      const data = await res.json();
      if (data.success) {
        setBookings(data.bookings || []);
        setPagination(data.pagination || null);
      }
    } catch (err) {
      console.error("Failed to fetch recent bookings:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings(page);
  }, [page]);

  return (
    <div className="mt-6 bg-white rounded-2xl shadow-md p-4 sm:p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm sm:text-base font-semibold text-primary flex items-center gap-2">
          <span className="material-symbols-outlined text-lg">history</span>
          Recent 10 POS Bookings
        </h2>
        <button
          onClick={() => fetchBookings(page)}
          className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          title="Refresh"
        >
          <span className="material-symbols-outlined text-lg text-gray-500">
            refresh
          </span>
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : bookings.length === 0 ? (
        <div className="text-center py-8 text-gray-400 text-sm">
          <span className="material-symbols-outlined text-3xl block mb-2">
            receipt_long
          </span>
          No POS bookings today yet
        </div>
      ) : (
        <>
          <div className="overflow-x-auto -mx-4 sm:-mx-5">
            <table className="w-full text-sm min-w-150">
              <thead className="bg-gray-50 border-y">
                <tr>
                  <th className="py-2 px-4 text-left font-medium text-gray-500 text-xs">
                    ID
                  </th>
                  <th className="py-2 px-4 text-left font-medium text-gray-500 text-xs">
                    Booked By
                  </th>
                  <th className="py-2 px-4 text-left font-medium text-gray-500 text-xs">
                    Customer
                  </th>
                  <th className="py-2 px-4 text-left font-medium text-gray-500 text-xs">
                    Listing
                  </th>
                  <th className="py-2 px-4 text-right font-medium text-gray-500 text-xs">
                    Qty
                  </th>
                  <th className="py-2 px-4 text-right font-medium text-gray-500 text-xs">
                    Amount
                  </th>
                  <th className="py-2 px-4 text-right font-medium text-gray-500 text-xs">
                    Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr
                    key={b._id || b.bookingId}
                    className="border-b last:border-0 hover:bg-gray-50"
                  >
                    <td className="py-2.5 px-4 font-mono text-xs text-primary">
                      {b.bookingId}
                    </td>
                    <td className="py-2.5 px-4">{b.bookedByName || "-"}</td>
                    <td className="py-2.5 px-4">
                      {b.customerName || b.customerEmail?.split("@")[0] || "-"}
                    </td>
                    <td className="py-2.5 px-4 truncate max-w-35">
                      {b.listingName}
                    </td>
                    <td className="py-2.5 px-4 text-right">{b.quantity}</td>
                    <td className="py-2.5 px-4 text-right font-semibold">
                      ₹{b.totalAmount}
                    </td>
                    <td className="py-2.5 px-4 text-right text-gray-500">
                      {b.createdAt
                        ? new Date(b.createdAt).toLocaleTimeString("en-IN", {
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: true,
                          })
                        : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {pagination && pagination.totalPages > 1 && (
            <div className="flex items-center justify-between mt-3 pt-3 border-t">
              <span className="text-xs text-gray-400">
                Page {pagination.page} of {pagination.totalPages} (
                {pagination.total} total)
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page <= 1}
                  className="px-3 py-1 text-xs border rounded-lg hover:bg-gray-50 disabled:opacity-40"
                >
                  Prev
                </button>
                <button
                  onClick={() =>
                    setPage((p) => Math.min(pagination.totalPages, p + 1))
                  }
                  disabled={page >= pagination.totalPages}
                  className="px-3 py-1 text-xs border rounded-lg hover:bg-gray-50 disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
