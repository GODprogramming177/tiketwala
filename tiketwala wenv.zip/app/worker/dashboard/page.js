"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import TicketQR from "@/components/TicketQR";

export default function WorkerDashboardPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    authHeaders,
    isWorker,
    isOwner,
    isSuperAdmin,
    hasPosPermission,
  } = useAdminAuth();

  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [ticketToView, setTicketToView] = useState(null);

  /* ── Auth Guard ───────────────────────── */
  useEffect(() => {
    if (!authLoading && !admin) {
      router.replace("/admin/login");
      return;
    }
    if (!authLoading && admin && !isWorker() && !isOwner() && !isSuperAdmin()) {
      router.replace("/admin");
    }
    if (!authLoading && admin?.role === "worker" && !hasPosPermission("pos")) {
      router.replace("/worker");
    }
  }, [
    admin,
    authLoading,
    hasPosPermission,
    isOwner,
    isSuperAdmin,
    isWorker,
    router,
  ]);

  /* ── Fetch Bookings ───────────────────── */
  useEffect(() => {
    if (admin) {
      fetchBookings();
    }
  }, [admin]);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/pos/bookings", {
        headers: authHeaders(),
      });
      const data = await res.json();
      if (data.success) {
        setBookings(data.bookings || []);
      } else {
        toast.error(data.error || "Failed to load bookings");
      }
    } catch (error) {
      console.error(error);
      toast.error("Network error");
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }
  if (!admin) return null;

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <Navbar />

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-gray-900">
              Worker Dashboard
            </h1>
            <p className="text-gray-500 mt-1">
              Welcome back, {admin.name || "Worker"}! Here are your recent POS
              sales.
            </p>
          </div>
          <button
            onClick={fetchBookings}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 shadow-sm text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <span
              className={`material-symbols-outlined text-[20px] ${
                loading ? "animate-spin" : ""
              }`}
            >
              refresh
            </span>
            Refresh
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center ring-4 ring-blue-50/50">
              <span className="material-symbols-outlined">receipt_long</span>
            </div>
            <div>
              <p className="text-sm font-medium tracking-wide text-gray-500">
                Total Tickets
              </p>
              <p className="text-2xl font-bold text-gray-900 leading-tight mt-1">
                {bookings.length}
              </p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex items-center gap-4">
            <div className="w-12 h-12 bg-green-50 text-green-600 rounded-full flex items-center justify-center ring-4 ring-green-50/50">
              <span className="material-symbols-outlined">payments</span>
            </div>
            <div>
              <p className="text-sm font-medium tracking-wide text-gray-500">
                Total Revenue
              </p>
              <p className="text-2xl font-bold text-gray-900 leading-tight mt-1">
                ₹{bookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0)}
              </p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center ring-4 ring-amber-50/50">
              <span className="material-symbols-outlined">group</span>
            </div>
            <div>
              <p className="text-sm font-medium tracking-wide text-gray-500">
                Total Visitors
              </p>
              <p className="text-2xl font-bold text-gray-900 leading-tight mt-1">
                {bookings.reduce((sum, b) => sum + (b.quantity || 1), 0)}
              </p>
            </div>
          </div>
        </div>

        {/* Bookings List */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
            <h2 className="text-lg font-semibold text-gray-800">
              Recent Sales
            </h2>
          </div>
          {loading ? (
            <div className="p-12 flex flex-col items-center justify-center text-gray-400">
              <span className="material-symbols-outlined animate-spin text-3xl mb-2 text-primary/50">
                progress_activity
              </span>
              <p>Loading bookings...</p>
            </div>
          ) : bookings.length === 0 ? (
            <div className="p-12 flex flex-col items-center justify-center text-gray-400">
              <span className="material-symbols-outlined text-4xl mb-2 opacity-50">
                receipt_long
              </span>
              <p>No POS tickets booked yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left align-middle">
                <thead className="text-xs text-gray-500 uppercase bg-gray-50/50 border-b border-gray-100">
                  <tr>
                    <th scope="col" className="px-6 py-4 font-semibold">
                      Booking ID
                    </th>
                    <th scope="col" className="px-6 py-4 font-semibold">
                      Venue
                    </th>
                    <th scope="col" className="px-6 py-4 font-semibold">
                      Customer
                    </th>
                    <th scope="col" className="px-6 py-4 font-semibold">
                      Date & Slot
                    </th>
                    <th scope="col" className="px-6 py-4 font-semibold">
                      Details
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-4 font-semibold text-right"
                    >
                      Amount
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-4 font-semibold text-center"
                    >
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {bookings.map((booking) => (
                    <tr
                      key={booking._id || booking.bookingId}
                      className="hover:bg-gray-50/50 transition-colors"
                    >
                      <td className="px-6 py-4 font-mono text-gray-900">
                        {booking.bookingId}
                      </td>
                      <td className="px-6 py-4 font-medium text-gray-900">
                        {booking.listingName}
                      </td>
                      <td className="px-6 py-4 text-gray-600">
                        {booking.customerName || booking.customerEmail || "-"}
                      </td>
                      <td className="px-6 py-4 text-gray-600">
                        <div>{booking.date}</div>
                        <div className="text-xs text-gray-400">
                          {booking.slot}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-600">
                        {booking.quantity}{" "}
                        {booking.quantity === 1 ? "Visitor" : "Visitors"}
                        {booking.selectedOffering && (
                          <span className="block text-xs text-primary bg-primary/10 w-max px-2 py-0.5 rounded mt-1">
                            {booking.selectedOffering}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right font-semibold text-gray-900">
                        ₹{booking.totalAmount}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => setTicketToView(booking)}
                          className="px-3 py-1.5 bg-primary/10 text-primary text-xs font-semibold rounded-lg hover:bg-primary/20 transition-colors"
                        >
                          View Ticket
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      {/* Ticket Modal */}
      {ticketToView && (
        <TicketQR
          booking={ticketToView}
          onClose={() => setTicketToView(null)}
        />
      )}
    </div>
  );
}
