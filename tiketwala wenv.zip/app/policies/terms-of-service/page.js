import React from "react";
import Navbar from "@/components/Navbar";
import AppFooter from "@/components/AppFooter";

export const metadata = {
  title: "Terms of Service | TiketWala",
  description: "Read the Terms of Service for using the TiketWala platform, services, and booking systems.",
};

const SECTIONS = [
  { id: "acceptance-of-terms", title: "1. Acceptance of Terms" },
  { id: "eligibility", title: "2. Eligibility" },
  { id: "services-overview", title: "3. Services Overview" },
  { id: "registration-accounts", title: "4. Registration & Accounts" },
  { id: "content-ip", title: "5. Content & Intellectual Property" },
  { id: "use-restrictions", title: "6. Restrictions on Use" },
  { id: "payment-fees", title: "7. Payments & Booking Fees" },
  { id: "cancellations-refunds", title: "8. Cancellations & Refunds" },
  { id: "liability-disclaimers", title: "9. Liability & Disclaimers" },
  { id: "contact-support", title: "10. Contact & Support" },
];

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col scroll-smooth">
      <Navbar />

      {/* Hero Section */}
      <div className="relative overflow-hidden bg-slate-900 py-16 text-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 opacity-90" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(99,102,241,0.15),transparent_60%)]" />
        <div className="relative max-w-7xl mx-auto px-6">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mb-4">
            Legal Policies
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Terms of Service
          </h1>
          <p className="text-slate-400 text-sm md:text-base max-w-xl mx-auto">
            Last updated: May 18, 2026. Please read these terms carefully before using our platform.
          </p>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto w-full px-6 py-12 flex-1">
        <div className="flex flex-col lg:flex-row gap-10">
          
          {/* Sticky Sidebar Navigation (Desktop) */}
          <aside className="lg:w-1/4 lg:shrink-0">
            <div className="sticky top-24 bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm hidden lg:block">
              <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">
                On this page
              </h3>
              <nav className="space-y-1">
                {SECTIONS.map((sec) => (
                  <a
                    key={sec.id}
                    href={`#${sec.id}`}
                    className="block text-sm text-slate-600 hover:text-indigo-600 hover:translate-x-1 py-2 px-1 rounded transition-all duration-200 font-medium"
                  >
                    {sec.title}
                  </a>
                ))}
              </nav>
            </div>
          </aside>

          {/* Detailed Terms Content */}
          <main className="flex-1 bg-white rounded-3xl border border-slate-200/80 p-8 md:p-12 shadow-sm prose prose-slate max-w-none">
            
            <section id="acceptance-of-terms" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                1. Acceptance of Terms
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  These Terms of Service (the “Terms”) are intended to make you aware of your legal rights and responsibilities with respect to your access to and use of the TiketWala website and any other related mobile or software applications under the brand name 'TiketWala' (collectively “Platform”).
                </p>
                <p>
                  By accessing or using the Platform, you are agreeing to these Terms and concluding a legally binding contract with TiketWala (“TiketWala”/“We”/“Us”/“Our”). You may not use the Platform and/or its Services if you do not accept the Terms or are unable to be bound by the Terms.
                </p>
                <p>
                  By visiting our Platform and/or purchasing something from us, you engage in our Services and agree to be bound by these Terms, including any additional terms and conditions and policies referenced herein and/or available by hyperlink on the Platform. These Terms apply to all users of the Platform, including users who are browsers, vendors, customers, merchants, and/ or contributors of content displayed on the Platform.
                </p>
                <p>
                  These Terms may be updated from time to time without notice. It is therefore recommended that you review these Terms, as available on the Platform, each time you access and/or use the Platform. In the event there is any conflict or inconsistency between these Terms and any other terms and conditions that appear on the Platform, these Terms will prevail.
                </p>
              </div>
            </section>

            <section id="eligibility" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                2. Eligibility
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  Persons who are “incompetent to contract” within the meaning of the Indian Contract Act, 1872 are not eligible to use/access the Platform. However, if you are a minor, i.e. under the age of 18 years, you may use/access the Platform under the supervision of an adult parent or legal guardian who is “competent to contract” and agrees to be bound by these Terms.
                </p>
                <p>
                  If you are using the Platform on behalf of any person/ entity, you represent and warrant that you are authorized to accept these Terms on behalf of such person/ entity. Further, you and such person/ entity agree to be jointly, severally liable and indemnify us for violations of these Terms.
                </p>
              </div>
            </section>

            <section id="services-overview" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                3. Services Overview
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  ‘TiketWala’ is a platform for Customers to avail services with respect to going-out, booking activities, table reservations, movies, sports, events, ticketing, etc., listed by the partner Merchants on the Platform from time to time (“Services”). Services on the Platform are available to select geographies in India.
                </p>
                <p>
                  We facilitate ticketing and booking systems for parks, events, cinemas, temples, and more. Our platform includes tools for POS walk-in handling, CRM management, inventory tracking, and payment processing.
                </p>
              </div>
            </section>

            <section id="registration-accounts" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                4. Registration & Accounts
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  All users must register and log in to make transactions on the Platform. You must keep your account and registration details current and correct for receiving all communications from the Platform. By agreeing to the Terms, you agree to receive promotional, transactional, commercial or other communications, and newsletters from us.
                </p>
                <p>
                  As part of the registration process, access, and usage of the Platform, we may collect your personally identifiable information including your name, email address, age, address, mobile phone number, and demographic profile in compliance with our Privacy Policy.
                </p>
              </div>
            </section>

            <section id="content-ip" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                5. Content & Intellectual Property
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  We are the sole and exclusive copyright owners of the Services and our Content. We also exclusively own the copyrights, trademarks, service marks, logos, trade names, trade dress and other intellectual and proprietary rights throughout the world (“IP Rights”) associated with the Services and our Content.
                </p>
                <p>
                  You agree to protect TiketWala’s proprietary rights in the Services and to comply with all reasonable written requests made by us to protect our rights. Unless you have agreed otherwise in writing with TiketWala, nothing in the Terms gives you a right to use any of TiketWala's trade names, trademarks, service marks, logos, domain names, and any other distinctive brand features or intellectual property.
                </p>
              </div>
            </section>

            <section id="use-restrictions" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                6. Restrictions on Use
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  Without limiting the generality of these Terms, in using the Services, you specifically agree not to post or transmit any Content or engage in any activity that:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Violates our content guidelines and policies;</li>
                  <li>Is harmful, threatening, abusive, harassing, tortious, indecent, defamatory, discriminatory, vulgar, profane, obscene, hateful or otherwise objectionable;</li>
                  <li>Violates any third-party right, including, but not limited to, right of privacy, right of publicity, copyright, trademark, patent, or any other intellectual property rights;</li>
                  <li>Attempts to impersonate another person or entity;</li>
                  <li>Distributes computer viruses or other code, files, or programs that interrupt, destroy, or limit the functionality of any computer software or hardware;</li>
                  <li>Decompiles, reverse engineers, disassembles or otherwise attempts to derive source code from the Services.</li>
                </ul>
              </div>
            </section>

            <section id="payment-fees" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                7. Payments & Booking Fees
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  Through our payment integrations (such as Razorpay), TiketWala facilitates online and mobile-based payment mechanisms.
                </p>
                <p>
                  You can make a payment for the Invoice Amount on the Platform by using any payment method available on the 'Payment' section of the Platform. TiketWala reserves the right to charge a 'Convenience Fee' or 'Booking Fee' in respect of any of its Services, which shall be communicated on the Platform from time to time. By making a transaction or booking, you agree to pay for such charges.
                </p>
              </div>
            </section>

            <section id="cancellations-refunds" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                8. Cancellations & Refunds
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  <strong>Personal Use Only:</strong> Any ticket purchased through the Platform is meant solely and exclusively for personal use by the person in whose name the ticket has been issued. Tickets are not transferable property and cannot be resold, transferred or conveyed unless prior written and express permission has been provided by the Merchant.
                </p>
                <p>
                  <strong>No Exchange or Refund:</strong> Tickets once sold cannot be exchanged, cancelled, modified, transferred, or refunded, and you shall not make any request for modifications in the ticket, including change in date, time, location, or category unless the Merchant has specified otherwise.
                </p>
                <p>
                  <strong>Event Cancellation:</strong> If an Event is cancelled and the Merchant of such Event agrees on issuing a refund for the tickets, it shall be the Merchant's responsibility to instruct TiketWala to communicate and contact you and process the refund.
                </p>
              </div>
            </section>

            <section id="liability-disclaimers" className="mb-10 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                9. Liability & Disclaimers
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  Under no circumstances should you entertain anyone who is selling printouts or SMS messages of booking IDs claiming to be generated by TiketWala. If you happen to come across someone who is engaged in this activity, report it promptly to our customer care team.
                </p>
                <p>
                  Notwithstanding anything to the contrary contained herein, neither TiketWala nor its respective affiliates or their respective officers, directors, employees, or agents shall have any liability to you or to any third party for any indirect, incidental, special or consequential damages or any loss of revenue or profits arising under or relating to these terms.
                </p>
                <p>
                  TiketWala's combined maximum aggregate liability to you for any causes whatsoever, and regardless of the form of action, shall at all times be limited to the ticket price paid or Rs. 5,000, whichever is lower.
                </p>
              </div>
            </section>

            <section id="contact-support" className="mb-6 scroll-mt-24">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 border-b border-slate-100 pb-2">
                10. Contact & Support
              </h2>
              <div className="text-slate-600 text-sm md:text-base leading-relaxed space-y-4">
                <p>
                  For any help, issues, or queries pertaining to ticket bookings, events, dining, or store bookings, you can reach out to us using the following channels:
                </p>
                <ul className="list-none pl-0 space-y-2 font-medium text-slate-800">
                  <li className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-indigo-600">mail</span>
                    <a href="mailto:support@tiketwala.com" className="text-indigo-600 hover:underline">
                      support@tiketwala.com
                    </a>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-indigo-600">call</span>
                    <a href="tel:+919861555755" className="text-indigo-600 hover:underline">
                      +91 98615 55755
                    </a>
                  </li>
                </ul>
              </div>
            </section>

          </main>

        </div>
      </div>
      <AppFooter />
    </div>
  );
}
