import React from "react";

export const metadata = {
  title: "About Us | TiketWala",
  description:
    "Learn more about TiketWala and the team behind the booking experience.",
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pt-16">
      <main className="flex-1 max-w-5xl mx-auto w-full px-6 py-12">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
          {/* Header Section */}
          <div className="bg-indigo-600 px-8 py-16 text-center text-white">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
              About Us
            </h1>
            <p className="text-lg md:text-xl font-medium opacity-90 max-w-2xl mx-auto">
              When It Comes To Reliability, We Are The One You Need!
            </p>
          </div>

          <div className="p-8 md:p-12 space-y-12">
            {/* Identity & Mission */}
            <section className="space-y-4">
              <h2 className="text-3xl font-bold text-gray-900 border-b pb-2">
                TiketWala
              </h2>
              <p className="text-gray-700 text-lg leading-relaxed">
                Welcome to{" "}
                <span className="font-semibold text-indigo-600">
                  TiketWala
                </span>
                . We are the trusted software solution provider for your
                business. Backed by
                <strong className="text-indigo-600">
                  {" "}
                  TiketWala
                </strong>
                , we offer a wide choice of software products suitable for every
                type of business activity. From ticketing and booking systems
                for parks, temples, and events, to Invoicing, Inventory,
                Payroll, MIS, CRM and GST management.
              </p>
            </section>

            {/* Experience & Expertise */}
            <section className="space-y-4">
              <h3 className="text-2xl font-bold text-gray-900">
                Experience & Expertise
              </h3>
              <p className="text-gray-700 text-lg leading-relaxed">
                With more than 25 years of experience in providing accounting,
                inventory, and statutory compliance solutions, we have a rich
                experience combined with the expertise to meet the software
                requirements of any kind of entity—be it a Trader, Distributor,
                Manufacturer, NGO, or Government Public Enterprise. If you have
                a software requirement, we have a ready solution.
              </p>
            </section>

            {/* Our Solutions Overview */}
            <section className="grid md:grid-cols-3 gap-8 pt-6">
              <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100">
                <h4 className="font-bold text-lg text-indigo-900 mb-3">
                  Accounts & Inventory
                </h4>
                <p className="text-indigo-800 text-sm">
                  Automate business activity, generate computerized invoices
                  quickly, and easily maintain books of accounts and stock
                  inventory.
                </p>
              </div>
              <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100">
                <h4 className="font-bold text-lg text-indigo-900 mb-3">
                  GST & E-Invoicing
                </h4>
                <p className="text-indigo-800 text-sm">
                  Enterprise-level cloud solutions to automate compliance and
                  manage TDS, GST & E-Way Bills effortlessly.
                </p>
              </div>
              <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100">
                <h4 className="font-bold text-lg text-indigo-900 mb-3">
                  Custom ERP
                </h4>
                <p className="text-indigo-800 text-sm">
                  Powerful customization options allow us to tailor ERP
                  solutions specifically to match any unique business
                  requirements.
                </p>
              </div>
            </section>

            {/* Contact & Address Section */}
            <section className="mt-12 bg-gray-50 rounded-xl p-8 border border-gray-200">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Reach Us
              </h3>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h4 className="flex items-center text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">
                      <span className="material-symbols-outlined mr-2">
                        location_on
                      </span>
                      Corporate Location
                    </h4>
                    <p className="text-gray-800 font-medium leading-relaxed">
                      10th Lane, Ruby Eye Hospital
                      <br />
                      Govind Bihar, Berhampur
                      <br />
                      Ganjam, Odisha 761001
                    </p>
                  </div>
                  <div>
                    <h4 className="flex items-center text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">
                      <span className="material-symbols-outlined mr-2">
                        apartment
                      </span>
                      Registered Office
                    </h4>
                    <p className="text-gray-800 font-medium leading-relaxed">
                      Main Road, Karapalli
                      <br />
                      Gopalpur On Sea, Berhampur
                      <br />
                      Ganjam, Odisha 761002
                    </p>
                  </div>
                </div>

                <div className="space-y-6 flex flex-col justify-center bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                  <div>
                    <h4 className="flex items-center text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">
                      <span className="material-symbols-outlined mr-2">
                        mail
                      </span>
                      Email
                    </h4>
                    <a
                      href="mailto:support@tiketwala.com"
                      className="text-indigo-600 font-medium hover:underline text-lg"
                    >
                      support@tiketwala.com
                    </a>
                  </div>
                  <div>
                    <h4 className="flex items-center text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">
                      <span className="material-symbols-outlined mr-2">
                        call
                      </span>
                      Phone
                    </h4>
                    <div className="text-gray-800 font-medium text-lg space-y-1">
                      <p>+91 98615 55755</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}
