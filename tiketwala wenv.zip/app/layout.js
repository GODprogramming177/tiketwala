import { AdminAuthProvider } from "@/lib/AdminAuthContext";
import { CustomerAuthProvider } from "@/lib/CustomerAuthContext";
import AppToaster from "@/components/AppToaster";
import "./globals.css";

export const metadata = {
  title: "TiketWala - Book Parks, Temples, Cinemas & Events",
  description:
    "Your one-stop platform for booking visits to parks, temples, cinemas, events, and more.",
  manifest: "/site.webmanifest",
  icons: {
    icon: [
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0"
        />
      </head>
      <body className="antialiased bg-white text-slate-900">
        <AdminAuthProvider>
          <CustomerAuthProvider>
            {children}
            <AppToaster />
          </CustomerAuthProvider>
        </AdminAuthProvider>
      </body>
    </html>
  );
}
