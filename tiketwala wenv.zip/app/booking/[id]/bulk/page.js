"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import AppFooter from "@/components/AppFooter";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";

function getMinBulkDate() {
  return new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString().slice(0, 10);
}

export default function BulkBookingPage({ params }) {
  const router = useRouter();
  const resolvedParams = use(params);
  const { id } = resolvedParams;
  const { customer, isAuthenticated } = useCustomerAuth();

  const [listing, setListing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    visitDate: "",
    quantity: "10",
    notes: "",
  });

  useEffect(() => {
    if (id) fetchListing();
  }, [id]);

  useEffect(() => {
    if (customer) {
      setFormData((prev) => ({
        ...prev,
        customerName: prev.customerName || customer.name || "",
        customerEmail: prev.customerEmail || customer.email || "",
      }));
    }
  }, [customer]);

  const fetchListing = async () => {
    try {
      const res = await fetch(`/api/listings?id=${id}`);
      const data = await res.json();
      setListing(data);
    } catch (err) {
      console.error("Failed to fetch listing:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const res = await fetch("/api/bulk-bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          listingId: id,
          ...formData,
          quantity: Number(formData.quantity),
        }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || "Unable to submit bulk request");
      }

      setSubmitted(true);
      toast.success("Bulk booking request submitted!");
    } catch (err) {
      toast.error(err.message || "Unable to submit request");
    } finally {
      setSubmitting(false);
    }
  };

  const minBulkDate = getMinBulkDate();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center">
            <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4" />
            <p className="text-gray-500">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="text-center">
            <span className="material-symbols-outlined text-6xl text-gray-300">error</span>
            <h1 className="text-2xl font-bold text-gray-800 mt-4">Listing Not Found</h1>
            <Link href="/" className="inline-flex items-center gap-2 mt-6 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90">
              <span className="material-symbols-outlined">arrow_back</span>
              Back to Home
            </Link>
          </div>
        </div>
        <AppFooter />
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-lg w-full bg-white rounded-3xl shadow-lg p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="material-symbols-outlined text-5xl text-green-600">check_circle</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Request Submitted!</h1>
            <p className="text-gray-500 mt-3">
              Your bulk booking request for <strong className="text-primary">{listing.name}</strong> has been sent to the admin team.
              They will review it and get back to you via email.
            </p>
            <div className="mt-6 p-4 bg-accent rounded-2xl text-left text-sm space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">Group Size</span>
                <span className="font-medium text-gray-800">{formData.quantity} guests</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Visit Date</span>
                <span className="font-medium text-gray-800">{formData.visitDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Contact</span>
                <span className="font-medium text-gray-800">{formData.customerEmail}</span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 mt-8">
              <Link
                href={`/booking/${id}`}
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-primary text-primary rounded-xl hover:bg-primary/5 font-medium"
              >
                <span className="material-symbols-outlined">arrow_back</span>
                Back to Listing
              </Link>
              <Link
                href="/"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 font-medium"
              >
                <span className="material-symbols-outlined">home</span>
                Go Home
              </Link>
            </div>
          </div>
        </div>
        <AppFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-2xl mx-auto w-full px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500 mb-6">
          <Link href="/" className="hover:text-primary">Home</Link>
          <span className="material-symbols-outlined text-base">chevron_right</span>
          <Link href={`/booking/${id}`} className="hover:text-primary">{listing.name}</Link>
          <span className="material-symbols-outlined text-base">chevron_right</span>
          <span className="text-primary font-medium">Bulk Booking</span>
        </div>

        {/* Header */}
        <div className="bg-white rounded-3xl shadow-md p-6 sm:p-8 mb-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center">
              <span className="material-symbols-outlined text-3xl text-primary">groups_3</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-primary">Bulk Booking Request</h1>
              <p className="text-gray-500 text-sm">{listing.name}</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mb-6">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 text-amber-700 rounded-full text-xs font-medium">
              <span className="material-symbols-outlined text-sm">schedule</span>
              48-hour advance notice required
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-medium">
              <span className="material-symbols-outlined text-sm">group</span>
              Minimum 10 guests
            </div>
          </div>

          <p className="text-gray-600 text-sm leading-relaxed">
            Need tickets for a large group? Submit a bulk booking request below 
            and our admin team will review it. You&apos;ll be contacted via email 
            with pricing details and confirmation.
          </p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-3xl shadow-md p-6 sm:p-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-5 flex items-center gap-2">
            <span className="material-symbols-outlined text-primary">edit_note</span>
            Fill Request Details
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Contact Name <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.customerName}
                  onChange={(e) => setFormData((p) => ({ ...p, customerName: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Email <span className="text-red-400">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={formData.customerEmail}
                  onChange={(e) => setFormData((p) => ({ ...p, customerEmail: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                  placeholder="you@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.customerPhone}
                  onChange={(e) => setFormData((p) => ({ ...p, customerPhone: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                  placeholder="+91 9876543210"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Group Size <span className="text-red-400">*</span>
                </label>
                <input
                  type="number"
                  required
                  min="10"
                  value={formData.quantity}
                  onChange={(e) => setFormData((p) => ({ ...p, quantity: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                  placeholder="Minimum 10"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Visit Date <span className="text-red-400">*</span>
              </label>
              <input
                type="date"
                required
                min={minBulkDate}
                value={formData.visitDate}
                onChange={(e) => setFormData((p) => ({ ...p, visitDate: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Special Requirements / Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData((p) => ({ ...p, notes: e.target.value }))}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none"
                placeholder="Tell the admin team what you need for your group — e.g. food, transport, guides, etc."
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <Link
                href={`/booking/${id}`}
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 font-medium"
              >
                <span className="material-symbols-outlined">arrow_back</span>
                Cancel
              </Link>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors font-medium disabled:opacity-60"
              >
                <span className="material-symbols-outlined">send</span>
                {submitting ? "Submitting..." : "Submit Bulk Request"}
              </button>
            </div>
          </form>
        </div>
      </div>

      <AppFooter />
    </div>
  );
}
