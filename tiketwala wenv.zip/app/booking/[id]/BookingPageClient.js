"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import AppFooter from "@/components/AppFooter";
import SlotGrid from "@/components/SlotGrid";
import PaymentButton from "@/components/PaymentButton";
import TicketQR from "@/components/TicketQR";
import ReviewsComponent from "@/components/ReviewsComponent";
import SeatLayoutGenerator from "@/components/SeatLayoutGenerator";
import { getTypeIcon } from "@/lib/typeIcons";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";
import { calculatePropertyPricing } from "@/lib/listingUtils";

function getMinBulkDate() {
  return new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString().slice(0, 10);
}

export default function BookingPageClient({ id, initialListing = null }) {
  const router = useRouter();
  const { customer, isAuthenticated, authHeaders } = useCustomerAuth();

  const [listing, setListing] = useState(initialListing);
  const [slots, setSlots] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState(null);
  const [attendeeCounts, setAttendeeCounts] = useState({
    adult: 1,
    child: 0,
  });
  const [selectedAddOns, setSelectedAddOns] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [lockedSeatIds, setLockedSeatIds] = useState([]);
  const [activeImage, setActiveImage] = useState(
    initialListing?.images?.[0] || initialListing?.image || "",
  );
  const [loading, setLoading] = useState(!initialListing);
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [booking, setBooking] = useState(null);
  const [showTicket, setShowTicket] = useState(false);
  const [bulkRequest, setBulkRequest] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    visitDate: "",
    quantity: "10",
    notes: "",
  });
  const [bulkSubmitting, setBulkSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      fetchBookingData();
    }
  }, [id]);

  useEffect(() => {
    if (customer) {
      setBulkRequest((prev) => ({
        ...prev,
        customerName: prev.customerName || customer.name || "",
        customerEmail: prev.customerEmail || customer.email || "",
      }));
    }
  }, [customer]);

  const fetchBookingData = async () => {
    try {
      const usingInitialListing = initialListing?.id === id;
      setLoading(!usingInitialListing);

      const listingData = usingInitialListing
        ? initialListing
        : await fetch(`/api/listings?id=${id}`).then((listingResponse) =>
            listingResponse.json(),
          );
      setListing(listingData);
      setActiveImage(listingData.images?.[0] || listingData.image || "");
      setSelectedAddOns([]);

      // Auto-select first sub-category if available
      if (
        Array.isArray(listingData.subCategories) &&
        listingData.subCategories.length > 0
      ) {
        const initialSubCategory = listingData.subCategories[0];
        setSelectedSubCategory(initialSubCategory);

        const slotsResponse = await fetch(
          `/api/slots?id=${id}&subCategoryId=${initialSubCategory.id}`,
          {
            headers: isAuthenticated ? authHeaders() : undefined,
          },
        );
        const slotsData = await slotsResponse.json();
        setSlots(slotsData.slots || []);
      } else {
        setSelectedSubCategory(null);
        const slotsResponse = await fetch(`/api/slots?id=${id}`, {
          headers: isAuthenticated ? authHeaders() : undefined,
        });
        const slotsData = await slotsResponse.json();
        setSlots(slotsData.slots || []);
      }

      try {
        const reviewsResponse = await fetch(`/api/reviews?listingId=${id}`);
        if (reviewsResponse.ok) {
          const reviewsData = await reviewsResponse.json();
          setReviews(reviewsData.reviews || []);
        }
      } catch (err) {
        console.error("Failed to fetch reviews:", err);
      }
    } catch (error) {
      console.error("Failed to fetch booking data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const fetchSlotsForSubCategory = async () => {
      if (!listing || !id) return;

      try {
        const subCatQuery = selectedSubCategory
          ? `&subCategoryId=${selectedSubCategory.id}`
          : "";
        const slotsResponse = await fetch(`/api/slots?id=${id}${subCatQuery}`, {
          headers: isAuthenticated ? authHeaders() : undefined,
        });
        const slotsData = await slotsResponse.json();
        setSlots(slotsData.slots || []);
      } catch (error) {
        console.error("Failed to fetch slots for subcategory:", error);
      }
    };

    // We already fetched initial slots in fetchBookingData, but if subcategory changes interactively:
    if (!loading) {
      fetchSlotsForSubCategory();
    }
  }, [selectedSubCategory, id, isAuthenticated, listing, loading]);

  const handlePaymentSuccess = (response) => {
    if (response && response.booking) {
      setBooking(response.booking);
      setPaymentStatus("success");
      setShowTicket(true);
      setSelectedSlot(response.booking.slot || selectedSlot);
    } else {
      setPaymentStatus("error");
    }
  };

  const handlePaymentError = (error) => {
    setPaymentStatus("error");
    console.error("Payment failed:", error);
  };

  useEffect(() => {
    if (!selectedSlot || !Array.isArray(slots) || slots.length === 0) {
      return;
    }
    const exists = slots.some(
      (slot) => slot.start === selectedSlot && slot.available,
    );
    if (!exists) {
      setSelectedSlot(null);
    }
  }, [slots, selectedSlot]);

  useEffect(() => {
    if (!selectedSlot || !id || (listing?.category !== "cinema" && listing?.category !== "event")) {
      setLockedSeatIds([]);
      return;
    }
    const fetchSeatStatus = async () => {
      try {
        const res = await fetch(`/api/seats?propertyId=${id}&slot=${selectedSlot}`);
        const data = await res.json();
        if (data.seats) {
          setLockedSeatIds(data.seats.map((s) => s.seatId));
        }
      } catch (err) {
        console.error("Failed to fetch seat status:", err);
      }
    };
    fetchSeatStatus();
  }, [selectedSlot, id, listing?.category]);

  const unavailableSeatIds = useMemo(() => {
    const activeSlotObj = slots.find((s) => s.start === selectedSlot);
    const booked = activeSlotObj?.seatsBooked || [];
    return [...new Set([...booked, ...lockedSeatIds])];
  }, [slots, selectedSlot, lockedSeatIds]);

  useEffect(() => {
    setSelectedSeats([]);
  }, [selectedSlot]);

  const gallery = useMemo(() => {
    if (!listing) {
      return [];
    }
    return Array.isArray(listing.images) && listing.images.length > 0
      ? listing.images
      : listing.image
        ? [listing.image]
        : [];
  }, [listing]);

  // Get sub-categories from listing
  const subCategories = Array.isArray(listing?.subCategories)
    ? listing.subCategories
    : [];
  const isSeatingLayout =
    (listing?.category === "cinema" || listing?.category === "event") &&
    Array.isArray(listing?.seating?.seats) &&
    listing.seating.seats.length > 0;

  const adultCount = Math.max(0, Number(attendeeCounts.adult) || 0);
  const childCount = Math.max(0, Number(attendeeCounts.child) || 0);
  const quantity = isSeatingLayout 
    ? Math.max(1, selectedSeats.length)
    : Math.max(1, adultCount + childCount);

  // Get add-ons from selected sub-category
  const availableAddOns = selectedSubCategory?.addOns
    ? Array.isArray(selectedSubCategory.addOns)
      ? selectedSubCategory.addOns
      : []
    : Array.isArray(listing?.addOns)
      ? listing.addOns
      : [];

  const pricingPreview = useMemo(
    () =>
      calculatePropertyPricing(listing, {
        quantity: isSeatingLayout ? selectedSeats.length : quantity,
        attendeeCounts: isSeatingLayout 
          ? { adult: selectedSeats.length, child: 0 } 
          : attendeeCounts,
        selectedSubCategory:
          selectedSubCategory?.id || selectedSubCategory?.name || null,
        selectedOffering:
          selectedSubCategory?.id || selectedSubCategory?.name || null,
        selectedAddOns,
        selectedSeats,
      }),
    [attendeeCounts, listing, quantity, selectedAddOns, selectedSubCategory, selectedSeats, isSeatingLayout],
  );
  const normalizedAttendeeCounts = pricingPreview.attendeeCounts || {
    adult: isSeatingLayout ? selectedSeats.length : adultCount,
    child: isSeatingLayout ? 0 : childCount,
  };
  const selectedAddOnDetails = pricingPreview.selectedAddOns || [];
  const basePrice = pricingPreview.unitPrice || 0;
  const baseAmount = pricingPreview.baseAmount || 0;
  const addOnAmount = pricingPreview.addOnAmount || 0;
  const totalAmount = pricingPreview.totalAmount || 0;
  const fareBreakdown = Array.isArray(pricingPreview.fareBreakdown)
    ? pricingPreview.fareBreakdown
    : [];
  const minBulkDate = getMinBulkDate();
  const availableSlotCount = slots.filter((slot) => slot.available).length;

  const toggleAddOn = (addOnKey) => {
    setSelectedAddOns((prev) =>
      prev.includes(addOnKey)
        ? prev.filter((item) => item !== addOnKey)
        : [...prev, addOnKey],
    );
  };
  const setAttendeeCount = (type, nextValue) => {
    const safeNextValue = Math.max(0, Number(nextValue) || 0);
    setAttendeeCounts((prev) => {
      let nextAdult = type === "adult" ? safeNextValue : prev.adult;
      let nextChild = type === "child" ? safeNextValue : prev.child;

      if (nextAdult + nextChild < 1) {
        nextAdult = 1;
        nextChild = 0;
      }

      if (nextAdult + nextChild > 10) {
        if (type === "adult") {
          nextAdult = Math.max(0, 10 - nextChild);
        } else {
          nextChild = Math.max(0, 10 - nextAdult);
        }
      }

      if (nextAdult + nextChild < 1) {
        nextAdult = 1;
        nextChild = 0;
      }

      return { adult: nextAdult, child: nextChild };
    });
  };

  const submitBulkRequest = async (event) => {
    event.preventDefault();
    setBulkSubmitting(true);

    try {
      const response = await fetch("/api/bulk-bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          listingId: id,
          ...bulkRequest,
          quantity: Number(bulkRequest.quantity),
        }),
      });
      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Unable to submit bulk request");
      }

      toast.success("Bulk booking request sent");
      setBulkRequest({
        customerName: customer?.name || "",
        customerEmail: customer?.email || "",
        customerPhone: "",
        visitDate: "",
        quantity: "10",
        notes: "",
      });
    } catch (error) {
      toast.error(error.message || "Unable to submit bulk request");
    } finally {
      setBulkSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-accent/30 flex flex-col">
        <Navbar />
        <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 w-full">
          <div className="animate-pulse">
            <div className="h-90 bg-gray-200 rounded-4xl mb-8" />
            <div className="grid xl:grid-cols-[1.1fr_0.9fr] gap-8">
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded w-3/4" />
                <div className="h-5 bg-gray-200 rounded w-1/2" />
                <div className="h-28 bg-gray-200 rounded-2xl" />
              </div>
              <div className="h-130 bg-gray-200 rounded-2xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-accent/30 flex flex-col">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center flex-1">
          <span className="material-symbols-outlined text-6xl text-gray-300">
            error
          </span>
          <h1 className="text-2xl font-bold text-gray-800 mt-4">
            Listing Not Found
          </h1>
          <p className="text-gray-500 mt-2">
            The listing you&apos;re looking for doesn&apos;t exist.
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 mt-6 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90"
          >
            <span className="material-symbols-outlined">arrow_back</span>
            Back to Home
          </Link>
        </div>
        <AppFooter />
      </div>
    );
  }

  if (paymentStatus === "success") {
    const bookingAddOns = Array.isArray(booking?.selectedAddOns)
      ? booking.selectedAddOns
      : [];

    return (
      <div className="min-h-screen bg-accent/30 flex flex-col">
        <Navbar />
        {showTicket && booking && (
          <TicketQR
            booking={booking}
            allowThermalPrint={false}
            onClose={() => setShowTicket(false)}
          />
        )}
        <div className="max-w-2xl mx-auto px-4 py-16 text-center flex-1">
          <div className="bg-white rounded-3xl shadow-lg p-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-5xl text-green-600">
                check_circle
              </span>
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mt-6">
              Booking Confirmed!
            </h1>
            <p className="text-gray-500 mt-2">
              Your TiketWala booking is ready.
            </p>

            {booking && (
              <div className="mt-4 p-4 bg-primary/10 rounded-2xl">
                <p className="text-sm text-gray-600">Booking ID</p>
                <p className="font-mono font-bold text-primary">
                  {booking.bookingId}
                </p>
              </div>
            )}

            <div className="mt-6 p-5 bg-accent rounded-2xl text-left">
              <h3 className="font-semibold text-primary mb-3">
                Booking Details
              </h3>
              <div className="space-y-2 text-sm">
                <DetailRow label="Listing" value={listing.name} />
                <DetailRow
                  label="Time Slot"
                  value={booking?.slot || selectedSlot || "Not selected"}
                />
                <DetailRow
                  label="Adults"
                  value={String(
                    booking?.attendeeCounts?.adult ??
                      normalizedAttendeeCounts.adult,
                  )}
                />
                <DetailRow
                  label="Children"
                  value={String(
                    booking?.attendeeCounts?.child ??
                      normalizedAttendeeCounts.child,
                  )}
                />
                <DetailRow
                  label="Visitors"
                  value={String(booking?.quantity || quantity)}
                />
                {bookingAddOns.length > 0 && (
                  <div className="pt-2 border-t border-gray-200">
                    <p className="text-gray-500 mb-2">Add-ons</p>
                    <div className="space-y-1">
                      {bookingAddOns.map((addOn) => (
                        <div
                          key={addOn.id || addOn.name}
                          className="flex justify-between text-sm"
                        >
                          <span>{addOn.name}</span>
                          <span>₹{addOn.price}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <DetailRow
                  label="Total Paid"
                  value={`₹${booking?.totalAmount || totalAmount}`}
                  strong
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 mt-8">
              {booking && (
                <button
                  onClick={() => setShowTicket(true)}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90"
                >
                  <span className="material-symbols-outlined">qr_code</span>
                  View Ticket
                </button>
              )}
              <Link
                href="/"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-primary text-primary rounded-lg hover:bg-primary/10"
              >
                <span className="material-symbols-outlined">home</span>
                Back to Home
              </Link>
            </div>
          </div>
        </div>
        <AppFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(125deg, rgba(2,6,23,0.75), rgba(11,60,93,0.35)), url(${activeImage || gallery[0] || listing.image})`,
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 lg:py-14">
          <div className="max-w-3xl text-white">
            <div className="flex flex-wrap items-center gap-2 text-sm text-white/75">
              <Link href="/" className="hover:text-white">
                Home
              </Link>
              <span className="material-symbols-outlined text-base">
                chevron_right
              </span>
              <span className="wrap-break-word">{listing.name}</span>
            </div>

            <div className="mt-6 flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1 px-3 py-1.5 bg-white/10 rounded-full text-sm font-medium backdrop-blur-sm">
                <span className="material-symbols-outlined text-base">
                  {getTypeIcon(listing.type)}
                </span>
                {listing.type}
              </span>
              <span className="inline-flex items-center gap-1 px-3 py-1.5 bg-white/10 rounded-full text-sm font-medium backdrop-blur-sm">
                <span className="material-symbols-outlined text-base text-yellow-300">
                  star
                </span>
                {listing.rating}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 leading-tight wrap-break-word">
              {listing.name}
            </h1>

            <div className="flex flex-wrap items-center gap-2 mt-4 text-white/80">
              <span className="material-symbols-outlined">location_on</span>
              <span className="wrap-break-word">{listing.location}</span>
            </div>

            <p className="mt-5 text-white/80 text-base sm:text-lg max-w-2xl">
              {listing.description}
            </p>

            <div className="mt-6 flex gap-3 max-w-2xl">
              <div className="rounded-2xl bg-white/10 backdrop-blur-sm border border-white/10 px-4 py-3">
                <p className="text-xs uppercase tracking-wide text-white/60">
                  Starting
                </p>
                <p className="text-xl font-semibold mt-1">₹{listing.price}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-28 xl:pb-8 flex-1">
        {gallery.length > 0 && (
          <div className="mb-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {gallery.map((image, index) => (
                <button
                  key={`${image}-${index}`}
                  onClick={() => setActiveImage(image)}
                  className={`relative overflow-hidden rounded-2xl border-2 transition-all ${
                    activeImage === image
                      ? "border-primary shadow-lg"
                      : "border-transparent hover:border-primary/30"
                  }`}
                >
                  <img
                    src={image}
                    alt={`${listing.name} ${index + 1}`}
                    className="w-full h-24 sm:h-28 lg:h-32 object-cover"
                  />
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.08fr)_minmax(320px,0.92fr)] gap-6 lg:gap-8">
          <div className="space-y-6">
            {/* Sub-Category Selection */}
            {subCategories.length > 0 && (
              <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
                <h2 className="text-lg sm:text-xl font-semibold text-primary mb-4 flex items-center gap-2">
                  <span className="material-symbols-outlined">
                    {listing?.category === "cinema" ? "movie" : "category"}
                  </span>
                  {listing?.category === "cinema" ? "Choose Movie" : "Choose Ticket Type"}
                </h2>
                <div className={`grid grid-cols-1 sm:grid-cols-2 ${listing?.category === "cinema" ? "lg:grid-cols-3" : ""} gap-4`}>
                  {subCategories.map((subCat) => (
                    <button
                      key={subCat.id || subCat.name}
                      onClick={() => {
                        setSelectedSubCategory(subCat);
                        setSelectedAddOns([]);
                      }}
                      className={`rounded-2xl border-2 p-4 transition-all text-left ${
                        selectedSubCategory?.id === subCat.id ||
                        selectedSubCategory?.name === subCat.name
                          ? "border-primary bg-primary/5"
                          : "border-gray-200 hover:border-primary/30"
                      }`}
                    >
                      <div className={`flex ${listing?.category === "cinema" ? "flex-col" : "flex-col sm:flex-row sm:items-start"} items-center gap-4`}>
                        {subCat.image && (
                          <div className={`shrink-0 overflow-hidden rounded-xl shadow-sm ${listing?.category === "cinema" ? "w-full max-w-[200px]" : "w-[278px] h-[417px]"}`}>
                             <img
                              src={subCat.image}
                              alt={subCat.name}
                              className={`w-full h-full object-cover ${listing?.category === "cinema" ? "aspect-[2/3]" : ""}`}
                            />
                          </div>
                        )}
                        <div className={`flex-1 ${listing?.category === "cinema" ? "text-center" : "text-center sm:text-left"} w-full`}>
                          <p className="font-semibold text-gray-800 text-lg line-clamp-1">
                            {subCat.name}
                          </p>
                          {subCat.description && (
                            <p className="text-sm text-gray-500 mt-2 line-clamp-2">
                              {subCat.description}
                            </p>
                          )}
                          <p className="text-xl font-bold text-primary mt-4">
                            ₹{subCat.price}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg sm:text-xl font-semibold text-primary mb-4 flex items-center gap-2">
                <span className="material-symbols-outlined">schedule</span>
                Pick Your Slot
              </h2>
              <SlotGrid
                slots={slots}
                selectedSlot={selectedSlot}
                onSelectSlot={setSelectedSlot}
              />
            </div>

            {isSeatingLayout ? (
              <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
                <h2 className="text-lg sm:text-xl font-semibold text-primary mb-4 flex items-center gap-2">
                  <span className="material-symbols-outlined">chair</span>
                  Select Your Seats
                </h2>
                {!selectedSlot ? (
                  <p className="text-sm text-gray-500 text-center py-8 bg-gray-50 rounded-2xl border border-dashed border-gray-300">
                    Please pick a time slot first to see seat availability.
                  </p>
                ) : (
                  <SeatLayoutGenerator
                    seats={listing.seating.seats}
                    rows={listing.seating.rows}
                    cols={listing.seating.cols}
                    bookedSeats={unavailableSeatIds}
                    maxSelect={10}
                    onSelect={setSelectedSeats}
                  />
                )}
              </div>
            ) : (
              <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
                <h2 className="text-lg sm:text-xl font-semibold text-primary mb-4 flex items-center gap-2">
                  <span className="material-symbols-outlined">group</span>
                  Visitors
                </h2>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="rounded-2xl border border-gray-200 p-4">
                      <p className="text-xs uppercase tracking-wide text-gray-500">
                        Adults
                      </p>
                      <div className="mt-3 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "adult",
                              normalizedAttendeeCounts.adult - 1,
                            )
                          }
                          className="w-10 h-10 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined">
                            remove
                          </span>
                        </button>
                        <span className="text-2xl font-bold text-primary">
                          {normalizedAttendeeCounts.adult}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "adult",
                              normalizedAttendeeCounts.adult + 1,
                            )
                          }
                          className="w-10 h-10 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined">add</span>
                        </button>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-gray-200 p-4">
                      <p className="text-xs uppercase tracking-wide text-gray-500">
                        Children
                      </p>
                      <div className="mt-3 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "child",
                              normalizedAttendeeCounts.child - 1,
                            )
                          }
                          className="w-10 h-10 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined">
                            remove
                          </span>
                        </button>
                        <span className="text-2xl font-bold text-primary">
                          {normalizedAttendeeCounts.child}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setAttendeeCount(
                              "child",
                              normalizedAttendeeCounts.child + 1,
                            )
                          }
                          className="w-10 h-10 rounded-full bg-accent text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        >
                          <span className="material-symbols-outlined">add</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-primary/10 bg-primary/5 px-4 py-3 text-sm text-primary">
                    Total visitors: {quantity}. Child fare is applied from the
                    selected ticket type when configured.
                  </div>
                </div>
              </div>
            )}

            {availableAddOns.length > 0 && (
              <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
                <div className="flex items-center gap-2 mb-4">
                  <span className="material-symbols-outlined text-primary">
                    add_circle
                  </span>
                  <h2 className="text-lg sm:text-xl font-semibold text-primary">
                    Add Extra Facilities
                  </h2>
                </div>
                <div className="space-y-3">
                  {availableAddOns.map((addOn) => {
                    const addOnKey = addOn.id || addOn.name;
                    const checked = selectedAddOns.includes(addOnKey);
                    const chargeLabel =
                      addOn.chargeType === "per_person"
                        ? "Charges per visitor"
                        : "Charges once per booking";
                    const totalLabel =
                      addOn.chargeType === "per_person"
                        ? `₹${(Number(addOn.price) || 0) * quantity} for ${quantity}`
                        : `₹${Number(addOn.price) || 0} flat`;

                    return (
                      <label
                        key={addOnKey}
                        className={`block rounded-2xl border p-4 cursor-pointer transition-colors ${
                          checked
                            ? "border-primary bg-primary/5"
                            : "border-gray-200 hover:border-primary/30"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => toggleAddOn(addOnKey)}
                            className="mt-1 h-4 w-4 accent-primary"
                          />
                          <div className="flex-1">
                            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                              <div>
                                <p className="font-medium text-gray-800">
                                  {addOn.name}
                                </p>
                                <p className="text-sm text-gray-500 mt-1">
                                  {addOn.description ||
                                    "Optional upgrade for this booking."}
                                </p>
                              </div>
                              <div className="text-left sm:text-right shrink-0">
                                <p className="font-semibold text-primary">
                                  +₹{addOn.price}
                                </p>
                                <p className="text-xs text-gray-400 mt-1">
                                  {totalLabel}
                                </p>
                              </div>
                            </div>
                            <p className="text-xs text-gray-400 mt-3 uppercase tracking-wide">
                              {chargeLabel}
                            </p>
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg sm:text-xl font-semibold text-primary mb-3 flex items-center gap-2">
                <span className="material-symbols-outlined">groups_3</span>
                Need Bulk Booking?
              </h2>
              <p className="text-sm text-gray-500 mb-5">
                Planning a visit with 10+ guests? Submit a bulk booking request
                and our admin team will assist you with special group pricing.
              </p>
              <Link
                href={`/booking/${id}/bulk`}
                className="inline-flex w-full sm:w-auto items-center justify-center gap-2 px-6 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all font-medium"
              >
                <span className="material-symbols-outlined">send</span>
                Request Bulk Booking
              </Link>
            </div>

            {/* Reviews Section */}
            <ReviewsComponent listingId={id} onReviewAdded={fetchBookingData} />
          </div>

          <div className="space-y-6 xl:sticky xl:top-24 self-start hidden xl:block">
            <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg sm:text-xl font-semibold text-primary mb-4 flex items-center gap-2">
                <span className="material-symbols-outlined">receipt_long</span>
                Booking Summary
              </h2>
              <div className="space-y-3">
                <DetailRow label="Starting price" value={`₹${listing.price}`} />
                <DetailRow
                  label="Selected slot"
                  value={selectedSlot || "Choose a slot"}
                />
                <DetailRow
                  label="Adults"
                  value={String(normalizedAttendeeCounts.adult)}
                />
                <DetailRow
                  label="Children"
                  value={String(normalizedAttendeeCounts.child)}
                />
                <DetailRow label="Visitors" value={String(quantity)} />
                {fareBreakdown.map((item) => (
                  <DetailRow
                    key={item.key}
                    label={`${item.label} • ${item.count}`}
                    value={`₹${item.total}`}
                  />
                ))}
                {selectedAddOnDetails.map((addOn) => {
                  const multiplier =
                    addOn.chargeType === "per_person" ? quantity : 1;
                  return (
                    <DetailRow
                      key={addOn.id || addOn.name}
                      label={addOn.name}
                      value={`₹${(Number(addOn.price) || 0) * multiplier}`}
                    />
                  );
                })}
                <DetailRow label="Base subtotal" value={`₹${baseAmount}`} />
                <DetailRow label="Add-ons" value={`₹${addOnAmount}`} />
                <DetailRow label="Total" value={`₹${totalAmount}`} strong />
              </div>
            </div>

            {!isAuthenticated ? (
              <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6 text-center">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="material-symbols-outlined text-primary text-3xl">
                    lock
                  </span>
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  Login Required
                </h3>
                <p className="text-sm text-gray-500 mb-6">
                  Continue with secure email OTP to complete your booking.
                </p>
                <button
                  onClick={() =>
                    router.push(`/booking/login?redirect=/booking/${id}`)
                  }
                  className="w-full py-3 sm:py-4 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-all flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined">login</span>
                  Login to Continue
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
                <PaymentButton
                  amount={totalAmount}
                  listingName={listing.name}
                  listingId={id}
                  quantity={quantity}
                  attendeeCounts={normalizedAttendeeCounts}
                  slot={selectedSlot}
                  customerEmail={customer?.email}
                  selectedOffering={
                    selectedSubCategory?.id || selectedSubCategory?.name || null
                  }
                  selectedAddOns={selectedAddOns}
                  selectedSeats={selectedSeats}
                  disabled={!selectedSlot || (isSeatingLayout && selectedSeats.length === 0)}
                  onSuccess={handlePaymentSuccess}
                  onError={handlePaymentError}
                />
                {!selectedSlot && (
                  <p className="text-center text-sm text-gray-500 mt-3">
                    Select a slot to unlock payment
                  </p>
                )}
              </div>
            )}

            {paymentStatus === "error" && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3">
                <span className="material-symbols-outlined text-red-500">
                  error
                </span>
                <p className="text-red-700">
                  Payment failed. Please try again.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="xl:hidden fixed inset-x-0 bottom-0 z-40 border-t border-gray-200 bg-white/95 backdrop-blur-md px-4 py-3 shadow-[0_-10px_30px_rgba(15,23,42,0.08)]">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-start justify-between gap-4 mb-3">
            <div className="min-w-0">
              <p className="text-xs uppercase tracking-wide text-gray-400">
                Booking total
              </p>
              <p className="text-2xl font-bold text-primary">₹{totalAmount}</p>
              <p className="text-sm text-gray-500 wrap-break-word">
                {selectedSlot || "Choose a slot to continue"}
              </p>
            </div>
            <div className="text-right shrink-0">
              <p className="text-sm text-gray-500">
                A {normalizedAttendeeCounts.adult} · C{" "}
                {normalizedAttendeeCounts.child}
              </p>
              <p className="text-sm text-gray-500">
                {quantity} visitor{quantity > 1 ? "s" : ""}
              </p>
              {selectedAddOnDetails.length > 0 && (
                <p className="text-xs text-gray-400 mt-1">
                  {selectedAddOnDetails.length} add-on
                  {selectedAddOnDetails.length > 1 ? "s" : ""}
                </p>
              )}
            </div>
          </div>

          {!isAuthenticated ? (
            <button
              onClick={() =>
                router.push(`/booking/login?redirect=/booking/${id}`)
              }
              className="w-full py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-all flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined">login</span>
              Login to Continue
            </button>
          ) : (
            <PaymentButton
              amount={totalAmount}
              listingName={listing.name}
              listingId={id}
              quantity={quantity}
              attendeeCounts={normalizedAttendeeCounts}
              slot={selectedSlot}
              customerEmail={customer?.email}
              selectedOffering={
                selectedSubCategory?.id || selectedSubCategory?.name || null
              }
              selectedAddOns={selectedAddOns}
              selectedSeats={selectedSeats}
              disabled={!selectedSlot || (isSeatingLayout && selectedSeats.length === 0)}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />
          )}
        </div>
      </div>

      <AppFooter />
    </div>
  );
}

function InputField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  ...rest
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50"
        {...rest}
      />
    </div>
  );
}

function DetailRow({ label, value, strong = false }) {
  return (
    <div
      className={`flex flex-col sm:flex-row sm:items-start sm:justify-between gap-1 sm:gap-4 ${
        strong
          ? "pt-3 border-t text-lg font-bold text-primary"
          : "text-gray-600"
      }`}
    >
      <span className="shrink-0">{label}</span>
      <span className="text-left sm:text-right wrap-break-word">{value}</span>
    </div>
  );
}
