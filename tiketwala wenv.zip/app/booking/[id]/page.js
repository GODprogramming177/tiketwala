import { notFound } from "next/navigation";
import BookingPageClient from "./BookingPageClient";
import { getDb } from "@/lib/mongodb";
import { mapPropertyToListing } from "@/app/api/listings/route";

export async function generateMetadata({ params }) {
  const { id } = await params;
  const listing = await getPublicListing(id);

  if (!listing) {
    return {
      title: "Listing Not Found | TiketWala",
      description: "The requested booking page could not be found.",
      robots: {
        index: false,
        follow: false,
      },
    };
  }

  const title = `${listing.name} | Book ${listing.type} Tickets | TiketWala`;
  const description =
    listing.description ||
    `Book ${listing.type.toLowerCase()} tickets for ${listing.name} in ${listing.location} on TiketWala.`;
  const image = listing.images?.[0] || listing.image || "/logo.png";
  const path = `/booking/${id}`;

  return {
    title,
    description,
    alternates: {
      canonical: path,
    },
    openGraph: {
      title,
      description,
      url: path,
      siteName: "TiketWala",
      type: "website",
      images: image ? [{ url: image, alt: listing.name }] : [],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: image ? [image] : [],
    },
  };
}

export default async function BookingPage({ params }) {
  const { id } = await params;
  const listing = await getPublicListing(id);

  if (!listing) {
    notFound();
  }

  return <BookingPageClient id={id} initialListing={listing} />;
}

async function getPublicListing(id) {
  const db = await getDb();
  const property = await db.collection("properties").findOne({ _id: id });

  if (!property) {
    return null;
  }

  const business = await db
    .collection("businesses")
    .findOne({ _id: property.businessId });
  const owner = business?.ownerIds?.length
    ? await db
        .collection("users")
        .findOne(
          { _id: business.ownerIds[0] },
          { projection: { name: 1, email: 1 } },
        )
    : null;
  const reviewStats = await db
    .collection("reviews")
    .aggregate([
      { $match: { listingId: id } },
      { $group: { _id: null, avgRating: { $avg: "$rating" } } },
    ])
    .toArray();
  const avgRating = reviewStats.length
    ? Math.round(reviewStats[0].avgRating * 10) / 10
    : 0;

  return mapPropertyToListing(property, business, owner, avgRating);
}
