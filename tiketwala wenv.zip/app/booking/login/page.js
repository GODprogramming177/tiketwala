"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Image from "next/image";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";

/**
 * 3-step unified OTP authentication:
 * Step 1: Enter Mobile Number (default) or Email Address
 * Step 2a (existing user): Enter OTP
 * Step 2b (new user): Enter name + additional detail, then request OTP
 * Step 3: Enter OTP (for new users after filling details)
 */
function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectParams = searchParams.get("redirect");
  const { loginCustomer } = useCustomerAuth();

  // "email" represents Step 1 (identifier stage), "new_user_details" is profile collection, "otp" is OTP input
  const [step, setStep] = useState("email");
  const [loginMethod, setLoginMethod] = useState("mobile"); // "mobile" by default, can be toggled to "email"
  const [isNewCustomer, setIsNewCustomer] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    phone: "",
    otp: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const handleCheckIdentifier = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    setMessage("");

    try {
      const isMobile = loginMethod === "mobile";
      const payload = isMobile
        ? { phone: formData.phone, loginMethod }
        : { email: formData.email, loginMethod };

      const response = await fetch("/api/auth/request-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to check credentials");
      }

      if (data.isNewCustomer) {
        setIsNewCustomer(true);
        setStep("new_user_details");
        setMessage(
          "Looks like you're new! Please complete your profile below.",
        );
      } else {
        setIsNewCustomer(false);
        setStep("otp");
        setMessage(
          isMobile
            ? "OTP sent to your mobile number. Enter it below to continue."
            : "OTP sent to your email. Enter it below to continue."
        );
        toast.success("OTP sent successfully");
      }
    } catch (requestError) {
      const nextError = requestError.message || "Failed to check credentials";
      setError(nextError);
      toast.error(nextError);
    } finally {
      setLoading(false);
    }
  };

  const handleNewUserSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch("/api/auth/request-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.email,
          name: formData.name,
          phone: formData.phone,
          loginMethod,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to send OTP");
      }

      setStep("otp");
      setMessage(
        loginMethod === "mobile"
          ? "OTP sent to your mobile number. Enter it below to continue."
          : "OTP sent to your email. Enter it below to continue."
      );
      toast.success("OTP sent successfully");
    } catch (requestError) {
      const nextError = requestError.message || "Failed to send OTP";
      setError(nextError);
      toast.error(nextError);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.email,
          otp: formData.otp,
          name: formData.name,
          phone: formData.phone,
          loginMethod,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to verify OTP");
      }

      loginCustomer(data.customer, data.token || null);
      toast.success("Logged in successfully");
      router.push(redirectParams || "/");
    } catch (verifyError) {
      const nextError = verifyError.message || "Failed to verify OTP";
      setError(nextError);
      toast.error(nextError);
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/auth/request-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.email,
          name: formData.name,
          phone: formData.phone,
          loginMethod,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to resend OTP");
      }

      setMessage(
        loginMethod === "mobile"
          ? "A new OTP has been sent to your mobile number."
          : "A new OTP has been sent to your email."
      );
      toast.success("OTP resent successfully");
    } catch (requestError) {
      const nextError = requestError.message || "Failed to resend OTP";
      setError(nextError);
      toast.error(nextError);
    } finally {
      setLoading(false);
    }
  };

  const stepInfo = {
    email: {
      icon: loginMethod === "mobile" ? "phone_android" : "mail",
      title: "Welcome to TiketWala",
      subtitle: loginMethod === "mobile"
        ? "Enter your mobile number to get started. We'll send you a secure OTP via SMS."
        : "Enter your email to get started. We'll send you a secure OTP via email.",
      number: 1,
    },
    new_user_details: {
      icon: "person_add",
      title: "Complete Your Profile",
      subtitle: "Just a few more details to create your account.",
      number: 2,
    },
    otp: {
      icon: "verified",
      title: "Verify Your Identity",
      subtitle: loginMethod === "mobile"
        ? `Enter the verification code sent to ${formData.phone}`
        : `Enter the 6-digit code sent to ${formData.email}`,
      number: isNewCustomer ? 3 : 2,
    },
  };

  const current = stepInfo[step];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-primary px-6 py-8 text-center text-white">
            <div className="flex justify-center mb-4">
              <Image
                src="/logo.png"
                alt="TiketWala Logo"
                width={200}
                height={60}
                className="h-12 w-auto object-contain"
              />
            </div>
            <span className="material-symbols-outlined text-4xl mb-2">
              {current.icon}
            </span>
            <h1 className="text-2xl font-bold">{current.title}</h1>
            <p className="text-white/80 mt-2 text-sm">{current.subtitle}</p>

            {/* Step indicators */}
            <div className="flex justify-center gap-2 mt-5">
              {[1, 2, ...(isNewCustomer ? [3] : [])].map((n) => (
                <div
                  key={n}
                  className={`w-8 h-1 rounded-full transition-colors ${
                    n <= current.number ? "bg-white" : "bg-white/30"
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="p-6 md:p-8">
            {error && (
              <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm border border-red-100 flex items-start gap-2">
                <span className="material-symbols-outlined text-lg">error</span>
                {error}
              </div>
            )}

            {message && (
              <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-lg text-sm border border-green-100 flex items-start gap-2">
                <span className="material-symbols-outlined text-lg">
                  check_circle
                </span>
                {message}
              </div>
            )}

            {/* Step 1: Identifier Entry (Mobile or Email) */}
            {step === "email" && (
              <div className="space-y-6">
                {/* Tab Switcher */}
                <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginMethod("mobile");
                      setError("");
                      setMessage("");
                    }}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-2 ${
                      loginMethod === "mobile"
                        ? "bg-white text-primary shadow-sm"
                        : "text-gray-500 hover:text-gray-800"
                    }`}
                  >
                    <span className="material-symbols-outlined text-lg">phone_android</span>
                    Mobile Number
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLoginMethod("email");
                      setError("");
                      setMessage("");
                    }}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-2 ${
                      loginMethod === "email"
                        ? "bg-white text-primary shadow-sm"
                        : "text-gray-500 hover:text-gray-800"
                    }`}
                  >
                    <span className="material-symbols-outlined text-lg">mail</span>
                    Email Address
                  </button>
                </div>

                <form onSubmit={handleCheckIdentifier} className="space-y-4">
                  {loginMethod === "mobile" ? (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Mobile Number
                      </label>
                      <input
                        type="tel"
                        required
                        autoFocus
                        value={formData.phone}
                        onChange={(event) =>
                          setFormData((prev) => ({
                            ...prev,
                            phone: event.target.value,
                          }))
                        }
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-colors"
                        placeholder="9876543210"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        required
                        autoFocus
                        value={formData.email}
                        onChange={(event) =>
                          setFormData((prev) => ({
                            ...prev,
                            email: event.target.value,
                          }))
                        }
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-colors"
                        placeholder="you@example.com"
                      />
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-4 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 focus:ring-4 focus:ring-primary/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <span className="material-symbols-outlined text-lg animate-spin">
                          progress_activity
                        </span>
                        Checking…
                      </>
                    ) : (
                      <>
                        Continue
                        <span className="material-symbols-outlined text-lg">
                          arrow_forward
                        </span>
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}

            {/* Step 2b: New user profile details registration */}
            {step === "new_user_details" && (
              <form onSubmit={handleNewUserSubmit} className="space-y-4">
                {loginMethod === "mobile" ? (
                  <div className="px-3 py-2 bg-accent rounded-lg text-sm text-primary flex items-center gap-2 mb-2">
                    <span className="material-symbols-outlined text-lg">
                      phone_android
                    </span>
                    {formData.phone}
                    <button
                      type="button"
                      onClick={() => {
                        setStep("email");
                        setMessage("");
                        setError("");
                      }}
                      className="ml-auto text-xs text-primary/70 hover:text-primary underline"
                    >
                      Change
                    </button>
                  </div>
                ) : (
                  <div className="px-3 py-2 bg-accent rounded-lg text-sm text-primary flex items-center gap-2 mb-2">
                    <span className="material-symbols-outlined text-lg">
                      mail
                    </span>
                    {formData.email}
                    <button
                      type="button"
                      onClick={() => {
                        setStep("email");
                        setMessage("");
                        setError("");
                      }}
                      className="ml-auto text-xs text-primary/70 hover:text-primary underline"
                    >
                      Change
                    </button>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    autoFocus
                    value={formData.name}
                    onChange={(event) =>
                      setFormData((prev) => ({
                        ...prev,
                        name: event.target.value,
                      }))
                    }
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-colors"
                    placeholder="John Doe"
                  />
                </div>

                {loginMethod === "mobile" ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(event) =>
                        setFormData((prev) => ({
                          ...prev,
                          email: event.target.value,
                        }))
                      }
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-colors"
                      placeholder="you@example.com"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(event) =>
                        setFormData((prev) => ({
                          ...prev,
                          phone: event.target.value,
                        }))
                      }
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-colors"
                      placeholder="9876543210"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 focus:ring-4 focus:ring-primary/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <span className="material-symbols-outlined text-lg animate-spin">
                        progress_activity
                      </span>
                      Sending OTP…
                    </>
                  ) : (
                    <>
                      Send OTP
                      <span className="material-symbols-outlined text-lg">
                        arrow_forward
                      </span>
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Step 2a / Step 3: OTP verification */}
            {step === "otp" && (
              <form onSubmit={handleVerifyOtp} className="space-y-4">
                {loginMethod === "mobile" ? (
                  <div className="px-3 py-2 bg-accent rounded-lg text-sm text-primary flex items-center gap-2 mb-2">
                    <span className="material-symbols-outlined text-lg">
                      phone_android
                    </span>
                    {formData.phone}
                    <button
                      type="button"
                      onClick={() => {
                        setStep("email");
                        setMessage("");
                        setError("");
                        setFormData((prev) => ({ ...prev, otp: "" }));
                      }}
                      className="ml-auto text-xs text-primary/70 hover:text-primary underline"
                    >
                      Change
                    </button>
                  </div>
                ) : (
                  <div className="px-3 py-2 bg-accent rounded-lg text-sm text-primary flex items-center gap-2 mb-2">
                    <span className="material-symbols-outlined text-lg">
                      mail
                    </span>
                    {formData.email}
                    <button
                      type="button"
                      onClick={() => {
                        setStep("email");
                        setMessage("");
                        setError("");
                        setFormData((prev) => ({ ...prev, otp: "" }));
                      }}
                      className="ml-auto text-xs text-primary/70 hover:text-primary underline"
                    >
                      Change
                    </button>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {loginMethod === "mobile" ? "OTP Code" : "6-Digit OTP"}
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern={loginMethod === "mobile" ? "\\d{4,6}" : "\\d{6}"}
                    required
                    autoFocus
                    maxLength={6}
                    value={formData.otp}
                    onChange={(event) =>
                      setFormData((prev) => ({
                        ...prev,
                        otp: event.target.value.replace(/\D/g, "").slice(0, 6),
                      }))
                    }
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-colors tracking-[0.35em] text-center text-lg"
                    placeholder={loginMethod === "mobile" ? "••••" : "123456"}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 focus:ring-4 focus:ring-primary/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <span className="material-symbols-outlined text-lg animate-spin">
                        progress_activity
                      </span>
                      Verifying…
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-lg">
                        verified
                      </span>
                      Verify & Login
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleResendOtp}
                  disabled={loading}
                  className="w-full py-3 px-4 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 disabled:opacity-50 transition-colors"
                >
                  Resend OTP
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CustomerLoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gray-50 flex flex-col">
          <Navbar />
          <div className="flex-1 flex items-center justify-center p-4">
            <div className="animate-pulse flex flex-col items-center">
              <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4"></div>
              <p className="text-gray-500">Loading secure portal...</p>
            </div>
          </div>
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
