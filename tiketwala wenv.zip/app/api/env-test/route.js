import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    email: process.env.EMAIL,
    passwordLength: process.env.EMAIL_PASSWORD ? process.env.EMAIL_PASSWORD.length : 0,
    passwordStr: process.env.EMAIL_PASSWORD,
  });
}
