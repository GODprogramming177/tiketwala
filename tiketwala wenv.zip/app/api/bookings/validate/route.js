import { getDb } from "@/lib/mongodb";
import { requireRole, canAccessBusiness, hasPosPermission } from "@/lib/rbac";
import { enforceApiAccess } from "@/lib/apiAccess";
import {
  buildExpiryUpdate,
  buildUsedUpdate,
  getTicketStatus,
} from "@/lib/ticketing";

/**
 * Auto-expire a booking in DB and return expired response
 */
async function markBookingExpired(db, booking) {
  await db.collection("bookings").updateOne(
    { bookingId: booking.bookingId },
    { $set: buildExpiryUpdate(new Date()) },
  );
}

/**
 * POST /api/bookings/validate
 * Validate and mark a booking as scanned.
 * Optional: scannedBy (userId of the person scanning the QR)
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin", "worker"]);
    if (auth.error) {
      return auth.error;
    }

    if (auth.user.role === "worker" && !hasPosPermission(auth.user, "scan")) {
      return Response.json(
        { success: false, error: "Scan access denied" },
        { status: 403 },
      );
    }

    const { bookingId, scannedBy } = await request.json();

    if (!bookingId) {
      return Response.json(
        { success: false, error: "Booking ID is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const booking = await db.collection("bookings").findOne({ bookingId });

    if (!booking) {
      return Response.json(
        { success: false, valid: false, error: "Booking not found" },
        { status: 404 },
      );
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, booking.businessId)
    ) {
      return Response.json(
        { success: false, error: "Access denied" },
        { status: 403 },
      );
    }

    const ticketStatus = getTicketStatus(booking);

    if (ticketStatus === "expired") {
      if (booking.ticketStatus !== "expired") {
        await markBookingExpired(db, booking);
      }
      return Response.json({
        success: true,
        valid: false,
        scanType: "expired",
        message: "Ticket has expired — the slot time window has passed",
        bookingId: booking.bookingId,
        listingName: booking.listingName,
        validUntil: booking.validUntil || booking.validUntilIso,
      });
    }

    const currentScanCount = booking.scanCount || 0;
    const now = new Date().toISOString();

    // 3rd+ scan → EXPIRED
    if (ticketStatus === "used" || currentScanCount >= 2) {
      return Response.json({
        success: true,
        valid: false,
        scanType: "expired",
        message: "Ticket already used — entry and exit have been completed",
        scannedAt: booking.scannedAt,
      });
    }

    // 1st scan → ENTRY
    if (currentScanCount === 0) {
      await db.collection("bookings").updateOne(
        { bookingId },
        {
          $set: {
            scanned: true,
            scanCount: 1,
            scannedAt: now,
            scannedBy: scannedBy || auth.user._id,
            entryAt: now,
            ticketStatus: "active",
            updatedAt: now,
          },
        },
      );

      return Response.json({
        success: true,
        valid: true,
        scanType: "entry",
        message: "Entry scan — Ticket validated successfully",
        scannedAt: now,
        booking: {
          bookingId: booking.bookingId,
          listingName: booking.listingName,
          listingType: booking.listingType,
          slot: booking.slot,
          quantity: booking.quantity,
          selectedSeats: booking.selectedSeats || [],
        },
      });
    }

    // 2nd scan → EXIT
    if (currentScanCount === 1) {
      await db.collection("bookings").updateOne(
        { bookingId },
        {
          $set: {
            scanCount: 2,
            exitAt: now,
            ...buildUsedUpdate(new Date(now)),
          },
        },
      );

      return Response.json({
        success: true,
        valid: true,
        scanType: "exit",
        message: "Exit scan — Thank you for visiting!",
        scannedAt: now,
        booking: {
          bookingId: booking.bookingId,
          listingName: booking.listingName,
          listingType: booking.listingType,
          slot: booking.slot,
          quantity: booking.quantity,
          selectedSeats: booking.selectedSeats || [],
        },
      });
    }
  } catch (error) {
    console.error("Validate error:", error);
    return Response.json(
      { success: false, error: "Validation failed" },
      { status: 500 },
    );
  }
}

/**
 * GET /api/bookings/validate?id=<bookingId>
 * Check booking validity without marking as scanned.
 */
export async function GET(request) {
  try {
    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const bookingId = searchParams.get("id");

    if (!bookingId) {
      return Response.json(
        { success: false, error: "Booking ID is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const booking = await db.collection("bookings").findOne({ bookingId });

    if (!booking) {
      return Response.json(
        { success: false, error: "Booking not found" },
        { status: 404 },
      );
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, booking.businessId)
    ) {
      return Response.json(
        { success: false, error: "Access denied" },
        { status: 403 },
      );
    }

    let computedTicketStatus = getTicketStatus(booking);
    if (computedTicketStatus === "expired" && booking.ticketStatus !== "expired") {
      await markBookingExpired(db, booking);
    }

    return Response.json({
      success: true,
      booking: {
        bookingId: booking.bookingId,
        listingName: booking.listingName,
        slot: booking.slot,
        quantity: booking.quantity,
        status: booking.status,
        date: booking.date,
        scanned: booking.scanned || false,
        scanCount: booking.scanCount || 0,
        ticketStatus: computedTicketStatus,
      },
    });
  } catch (error) {
    console.error("Validate GET error:", error);
    return Response.json(
      { success: false, error: "Failed to check booking" },
      { status: 500 },
    );
  }
}
