import { getDb } from "@/lib/mongodb";
import {
  requireWorker,
  canAccessBusiness,
  hasPosPermission,
} from "@/lib/rbac";
import { enforceApiAccess } from "@/lib/apiAccess";
import {
  buildExpiryUpdate,
  buildUsedUpdate,
  getTicketStatus,
} from "@/lib/ticketing";

/**
 * POST /api/bookings/scan
 * Smart scan — tracks entry/exit/expired:
 *   scanCount 0 → 1  →  "entry"   (marks scanned = true)
 *   scanCount 1 → 2  →  "exit"    (marks ticketStatus = "used")
 *   scanCount 2+      →  "expired" (error — ticket fully consumed)
 *
 * Workers, owners, and superadmins can use this.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireWorker(request);
    if (auth.error) {
      return auth.error;
    }

    if (auth.user.role === "worker" && !hasPosPermission(auth.user, "scan")) {
      return Response.json(
        { success: false, error: "Scan access denied" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { bookingId } = body;

    if (!bookingId || typeof bookingId !== "string") {
      return Response.json(
        { success: false, error: "bookingId is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const booking = await db
      .collection("bookings")
      .findOne({ bookingId: bookingId.trim() });

    if (!booking) {
      return Response.json(
        { success: false, error: "Booking not found. Invalid ticket." },
        { status: 404 },
      );
    }

    // Business access check (skip for superadmins)
    if (
      auth.user.role !== "superadmin" &&
      booking.businessId &&
      !canAccessBusiness(auth, booking.businessId)
    ) {
      return Response.json(
        { success: false, error: "Access denied for this booking" },
        { status: 403 },
      );
    }

    // Check booking status
    if (booking.status === "cancelled") {
      return Response.json(
        { success: false, error: "This booking has been cancelled" },
        { status: 400 },
      );
    }

    const now = new Date();
    const ticketStatus = getTicketStatus(booking, now);
    const currentScanCount = booking.scanCount || 0;

    if (ticketStatus === "expired") {
      if (booking.ticketStatus !== "expired") {
        await db.collection("bookings").updateOne(
          { bookingId: booking.bookingId },
          { $set: buildExpiryUpdate(now) },
        );
      }
      return Response.json(
        {
          success: false,
          error: "This ticket has expired because the booked slot has already ended",
          scanType: "expired",
        },
        { status: 400 },
      );
    }

    // ── 3rd+ scan → EXPIRED ────────────────────────
    if (ticketStatus === "used" || currentScanCount >= 2) {
      return Response.json({
        success: false,
        error: "Ticket already used — entry and exit have already been completed",
        scanType: "expired",
        booking: {
          bookingId: booking.bookingId,
          listingName: booking.listingName,
          listingType: booking.listingType,
          slot: booking.slot,
          quantity: booking.quantity,
          scanCount: currentScanCount,
          ticketStatus: "expired",
        },
      });
    }

    // ── 1st scan → ENTRY ───────────────────────────
    if (currentScanCount === 0) {
      await db.collection("bookings").updateOne(
        { bookingId: bookingId.trim() },
        {
          $set: {
            scanned: true,
            scanCount: 1,
            scannedAt: now.toISOString(),
            scannedBy: auth.user._id,
            entryAt: now.toISOString(),
            ticketStatus: "active",
            updatedAt: now.toISOString(),
          },
        },
      );

      return Response.json({
        success: true,
        scanType: "entry",
        message: "Entry scan — Welcome!",
        booking: {
          bookingId: booking.bookingId,
          listingName: booking.listingName,
          listingType: booking.listingType,
          slot: booking.slot,
          quantity: booking.quantity,
          scanCount: 1,
          ticketStatus: "active",
        },
      });
    }

    // ── 2nd scan → EXIT ────────────────────────────
    if (currentScanCount === 1) {
      await db.collection("bookings").updateOne(
        { bookingId: bookingId.trim() },
        {
          $set: {
            scanCount: 2,
            exitAt: now.toISOString(),
            ...buildUsedUpdate(now),
          },
        },
      );

      return Response.json({
        success: true,
        scanType: "exit",
        message: "Exit scan — Thank you for visiting!",
        booking: {
          bookingId: booking.bookingId,
          listingName: booking.listingName,
          listingType: booking.listingType,
          slot: booking.slot,
          quantity: booking.quantity,
          scanCount: 2,
          ticketStatus: "used",
        },
      });
    }
  } catch (error) {
    console.error("Scan booking error:", error);
    return Response.json(
      { success: false, error: "Failed to verify ticket" },
      { status: 500 },
    );
  }
}
