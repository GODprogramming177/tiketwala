import { getDb } from "@/lib/mongodb";
import { sendBookingEmail } from "@/lib/email";
import { requireRole, calculateFees, canAccessBusiness } from "@/lib/rbac";
import { calculatePropertyPricing } from "@/lib/listingUtils";
import { enforceApiAccess } from "@/lib/apiAccess";
import {
  buildExpiryUpdate,
  getTicketStatus,
  shouldExpireTicket,
} from "@/lib/ticketing";

/**
 * POST /api/bookings
 * Create a new booking with businessId, platform fees, and seat selection.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const {
      listingId,
      slot,
      quantity,
      paymentId,
      customerEmail,
      customerId,
      selectedSeats,
      selectedOffering,
      selectedAddOns,
      rzpOrderId,
      guestAges = [],
    } = body;

    const safeQuantity = Number(quantity);
    if (
      !listingId ||
      !slot ||
      !Number.isFinite(safeQuantity) ||
      safeQuantity < 1 ||
      !customerEmail
    ) {
      return Response.json(
        { success: false, error: "Missing required fields or login context" },
        { status: 400 },
      );
    }

    if (customerEmail !== auth.user.email) {
      return Response.json(
        { success: false, error: "Cannot create booking for another customer" },
        { status: 403 },
      );
    }

    const db = await getDb();

    // Prevent booking creation without a paid order linkage.
    if (!rzpOrderId || !paymentId) {
      return Response.json(
        {
          success: false,
          error: "Verified payment details are required to create a booking",
        },
        { status: 400 },
      );
    }

    const paidOrder = await db.collection("orders").findOne({
      rzpOrderId,
      status: "paid",
      propertyId: listingId,
      customerId: auth.user._id,
      slot,
    });

    if (!paidOrder) {
      return Response.json(
        { success: false, error: "No matching paid order found" },
        { status: 409 },
      );
    }

    // Fetch the property for pricing / info
    const property = await db
      .collection("properties")
      .findOne({ _id: listingId });
    if (!property) {
      return Response.json(
        { success: false, error: "Listing not found" },
        { status: 404 },
      );
    }

    // Fetch the business for fee calculation
    const business = await db
      .collection("businesses")
      .findOne({ _id: property.businessId });

    const pricing = calculatePropertyPricing(property, {
      quantity: safeQuantity,
      selectedSeats,
      selectedOffering,
      selectedAddOns,
      guestAges,
    });
    const totalAmount = pricing.totalAmount;

    if (totalAmount !== paidOrder.totalAmount) {
      return Response.json(
        { success: false, error: "Order and booking amount mismatch" },
        { status: 409 },
      );
    }

    // Calculate platform fees
    const fees = calculateFees(totalAmount, business);

    const now = new Date();
    const slotDate = new Date(slot);
    const computedSlotEnd =
      !Number.isNaN(slotDate.getTime())
        ? new Date(slotDate.getTime() + 60 * 60 * 1000).toISOString()
        : null;
    const validUntil =
      computedSlotEnd
        ? new Date(computedSlotEnd)
        : property.category === "event" && !isNaN(slotDate.getTime())
          ? slotDate
        : new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const bookingDateSource = !isNaN(slotDate.getTime()) ? slotDate : now;
    const bookingDateIso = bookingDateSource.toISOString().slice(0, 10);
    const validUntilIso = validUntil.toISOString();

    const bookingId =
      "BKG" +
      Date.now().toString(36).toUpperCase() +
      Math.random().toString(36).substring(2, 5).toUpperCase();

    const booking = {
      bookingId,
      customerId: auth.user._id,
      customerEmail,
      propertyId: listingId,
      businessId: property.businessId,
      listingName: property.name,
      listingType:
        property.category.charAt(0).toUpperCase() + property.category.slice(1),
      slot,
      quantity: safeQuantity,
      selectedSeats: pricing.selectedSeats,
      selectedOffering: pricing.selectedOffering,
      guestAges: pricing.guestAges,
      fareBreakdown: pricing.fareBreakdown,
      selectedAddOns: pricing.selectedAddOns,
      unitPrice: pricing.unitPrice,
      baseAmount: pricing.baseAmount,
      addOnAmount: pricing.addOnAmount,
      totalAmount,
      platformFee: fees.platformFee,
      businessAmount: fees.businessAmount,
      paymentId,
      rzpOrderId,
      status: "confirmed",
      date: bookingDateSource.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      bookingDateIso,
      validUntil: validUntil.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      validUntilIso,
      slotEnd: computedSlotEnd,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
      scanned: false,
      scanCount: 0,
      ticketStatus: "valid",
      scannedAt: null,
      scannedBy: null,
    };

    const slotFilterBase = { propertyId: listingId, start: slot };
    const selectedSeatLabels = pricing.selectedSeats;

    let slotUpdateResult;
    if (selectedSeatLabels.length > 0) {
      slotUpdateResult = await db.collection("slots").updateOne(
        {
          ...slotFilterBase,
          $and: selectedSeatLabels.map((label) => ({
            seatsBooked: { $nin: [label] },
          })),
          $expr: { $lte: [{ $add: ["$booked", safeQuantity] }, "$capacity"] },
        },
        {
          $inc: { booked: safeQuantity },
          $push: { seatsBooked: { $each: selectedSeatLabels } },
        },
      );
    } else {
      slotUpdateResult = await db.collection("slots").updateOne(
        {
          ...slotFilterBase,
          $expr: { $lte: [{ $add: ["$booked", safeQuantity] }, "$capacity"] },
        },
        { $inc: { booked: safeQuantity } },
      );
    }

    if (!slotUpdateResult?.matchedCount) {
      return Response.json(
        { success: false, error: "Selected slot is no longer available" },
        { status: 409 },
      );
    }

    // Insert booking after slot availability is safely reserved.
    await db.collection("bookings").insertOne(booking);

    // Fetch the admins to email
    let emailsToNotify = [];
    if (process.env.SEED_SUPERADMIN_EMAIL) {
      emailsToNotify.push(process.env.SEED_SUPERADMIN_EMAIL);
    }

    if (business && business.ownerEmail) {
      if (!emailsToNotify.includes(business.ownerEmail)) {
        emailsToNotify.push(business.ownerEmail);
      }
    } else if (
      process.env.ADMIN_EMAIL &&
      !emailsToNotify.includes(process.env.ADMIN_EMAIL)
    ) {
      emailsToNotify.push(process.env.ADMIN_EMAIL);
    }

    if (emailsToNotify.length > 0) {
      sendBookingEmail(emailsToNotify, booking).catch((err) => {
        console.error("Failed to trigger background email process", err);
      });
    }

    return Response.json({ success: true, booking }, { status: 201 });
  } catch (error) {
    console.error("Booking create error:", error);
    return Response.json(
      { success: false, error: "Failed to create booking" },
      { status: 500 },
    );
  }
}

/**
 * GET /api/bookings
 * Get bookings. Supports multi-tenant scoping:
 * - customerEmail: customer's own bookings
 * - businessId: owner scope
 * - ownerId: resolve all businesses for this owner
 * - No filter: superadmin gets all, others get nothing
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, [
      "customer",
      "owner",
      "superadmin",
    ]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const listingId = searchParams.get("listingId");
    const propertyId = searchParams.get("propertyId");
    const status = searchParams.get("status");
    const customerEmail = searchParams.get("customerEmail");
    const email = searchParams.get("email");
    const businessId = searchParams.get("businessId");
    const ownerId = searchParams.get("ownerId");

    const db = await getDb();
    const filter = {};

    if (auth.user.role === "customer") {
      filter.customerEmail = auth.user.email;
    } else if (auth.user.role === "owner") {
      if (!Array.isArray(auth.businessIds) || auth.businessIds.length === 0) {
        return Response.json({ success: true, bookings: [] });
      }

      if (businessId) {
        if (!canAccessBusiness(auth, businessId)) {
          return Response.json(
            { success: false, error: "Access denied for this business" },
            { status: 403 },
          );
        }
        filter.businessId = businessId;
      } else {
        filter.businessId = { $in: auth.businessIds };
      }

      if (ownerId && ownerId !== auth.user._id) {
        return Response.json(
          { success: false, error: "Cross-tenant access is not allowed" },
          { status: 403 },
        );
      }
    } else if (businessId) {
      filter.businessId = businessId;
    }

    if (listingId) filter.propertyId = listingId;
    if (propertyId) filter.propertyId = propertyId;
    if (status) filter.status = status;
    if ((customerEmail || email) && auth.user.role !== "customer") {
      filter.customerEmail = customerEmail || email;
    }

    const bookings = await db
      .collection("bookings")
      .find(filter)
      .sort({ createdAt: -1 })
      .toArray();

    const now = new Date();
    const expiredIds = [];

    for (const b of bookings) {
      const ticketStatus = getTicketStatus(b, now);
      b.ticketStatus = ticketStatus;
      if (ticketStatus === "expired" && shouldExpireTicket(b, now)) {
        expiredIds.push(b.bookingId);
      }
    }

    if (expiredIds.length > 0) {
      db.collection("bookings")
        .updateMany(
          { bookingId: { $in: expiredIds }, ticketStatus: { $ne: "expired" } },
          { $set: buildExpiryUpdate(now) },
        )
        .catch((err) => console.error("Lazy expiry batch update error:", err));
    }

    return Response.json({ success: true, bookings });
  } catch (error) {
    console.error("Bookings GET error:", error);
    return Response.json(
      { success: false, error: "Failed to fetch bookings" },
      { status: 500 },
    );
  }
}
