import { getDb } from "@/lib/mongodb";
import { requireRole, canAccessBusiness } from "@/lib/rbac";
import {
  getCategoryHours,
  getCategoryConfig,
  mergeOperatingHours,
} from "@/lib/categoryConfig";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * GET /api/slots?id=<propertyId>&date=<YYYY-MM-DD>&mode=template
 * Returns bookable slots, the default template, or a date override.
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const { searchParams } = new URL(request.url);
    const propertyId = searchParams.get("id");
    const date = searchParams.get("date");
    const mode = searchParams.get("mode");
    const subCategoryId = searchParams.get("subCategoryId");

    if (!propertyId) {
      return Response.json(
        { error: "Property ID (id) is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const property = await db
      .collection("properties")
      .findOne({ _id: propertyId });
    if (!property) {
      return Response.json({ error: "Listing not found" }, { status: 404 });
    }

    const activeSubCategoryId = subCategoryId || (property.subCategories?.[0]?.id || null);
    const query = { propertyId };
    if (activeSubCategoryId) {
      query.subCategoryId = activeSubCategoryId;
    } else {
      query.subCategoryId = { $in: [null, undefined] };
    }

    let allSlots = await db
      .collection("slots")
      .find(query)
      .sort({ start: 1 })
      .toArray();

    let baseDatesToSync = buildDateRange(getIndiaIsoDate(new Date()), 31);
    if ((property.category === "event" || property.category === "cinema") && Array.isArray(property.eventDates) && property.eventDates.length > 0) {
      baseDatesToSync = property.eventDates;
    }
    const datesToSync =
      date && isIsoDate(date)
        ? [date]
        : baseDatesToSync;
    const syncResult = await syncSlotsForDates({
      db,
      property,
      propertyId,
      subCategoryId: activeSubCategoryId,
      allSlots,
      dates: datesToSync,
    });

    if (syncResult.changed) {
      if (activeSubCategoryId) {
        property.subCategorySlots = property.subCategorySlots || {};
        property.subCategorySlots[activeSubCategoryId] = {
           slotTemplate: syncResult.slotTemplate,
           slotOverrides: syncResult.slotOverrides
        };
      } else {
        property.slotTemplate = syncResult.slotTemplate;
        property.slotOverrides = syncResult.slotOverrides;
      }

      allSlots = await db
        .collection("slots")
        .find(query)
        .sort({ start: 1 })
        .toArray();
    }

    const baseTemplate = getDefaultTemplate(property, allSlots, activeSubCategoryId);
    const selectedDate =
      date && isIsoDate(date) ? date : getIndiaIsoDate(new Date());
    const dateTemplate = getTemplateForDate(property, allSlots, selectedDate, activeSubCategoryId);

    if (mode === "template") {
      return Response.json({
        listingId: propertyId,
        listingName: property.name,
        date: selectedDate,
        hasDateOverride: hasDateOverride(property, selectedDate, activeSubCategoryId),
        defaultSlots: baseTemplate.map(mapTemplateToResponse),
        slots: dateTemplate.map(mapTemplateToResponse),
      });
    }

    const visibleSlots = allSlots
      .filter((slot) => {
        if (date && isIsoDate(date)) {
          return slot.start.startsWith(date);
        }
        return slot.start >= `${getIndiaIsoDate(new Date())}T00:00:00+05:30`;
      })
      .map(slot => mapSlotToResponse(slot, property.category));

    return Response.json({
      listingId: propertyId,
      listingName: property.name,
      date: date || null,
      slots: visibleSlots,
      defaultSlots: baseTemplate.map(mapTemplateToResponse),
      hasDateOverride: date ? hasDateOverride(property, date, activeSubCategoryId) : false,
    });
  } catch (error) {
    console.error("Slots API error:", error);
    return Response.json({ error: "Failed to fetch slots" }, { status: 500 });
  }
}

/**
 * POST /api/slots
 * Save either the default slot template or a date-specific override.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { listingId, subCategoryId, slots: incomingSlots, mode = "template", date } = body;

    if (!listingId || !Array.isArray(incomingSlots)) {
      return Response.json(
        { error: "Listing ID and slots are required" },
        { status: 400 },
      );
    }

    if (mode === "date" && !isIsoDate(date)) {
      return Response.json(
        { error: "A valid date is required for date overrides" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const property = await db
      .collection("properties")
      .findOne({ _id: listingId });
    if (!property) {
      return Response.json({ error: "Listing not found" }, { status: 404 });
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, property.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const activeSubCategoryId = subCategoryId || (property.subCategories?.[0]?.id || null);

    const normalizedSlots = normalizeTemplateEntries(
      incomingSlots,
      Number(property.capacityPerSlot) || 100,
    );
    const nowIso = new Date().toISOString();
    const updates = { updatedAt: nowIso };
    const nextProperty = {
      ...property,
      updatedAt: nowIso,
    };

    let currentOverrides = property.slotOverrides || {};
    let nextOverrides = {};
    if (activeSubCategoryId) {
       const subCatSlots = property.subCategorySlots?.[activeSubCategoryId] || {};
       if (mode === "date") {
           nextOverrides = { ...(subCatSlots.slotOverrides || {}), [date]: normalizedSlots };
           updates[`subCategorySlots.${activeSubCategoryId}.slotOverrides`] = nextOverrides;
           
           nextProperty.subCategorySlots = nextProperty.subCategorySlots || {};
           nextProperty.subCategorySlots[activeSubCategoryId] = { ...subCatSlots, slotOverrides: nextOverrides };
       } else {
           updates[`subCategorySlots.${activeSubCategoryId}.slotTemplate`] = normalizedSlots;
           
           nextProperty.subCategorySlots = nextProperty.subCategorySlots || {};
           nextProperty.subCategorySlots[activeSubCategoryId] = { ...subCatSlots, slotTemplate: normalizedSlots };
       }
    } else {
       if (mode === "date") {
         nextOverrides = { ...currentOverrides, [date]: normalizedSlots };
         updates.slotOverrides = nextOverrides;
         nextProperty.slotOverrides = nextOverrides;
       } else {
         updates.slotTemplate = normalizedSlots;
         nextProperty.slotTemplate = normalizedSlots;
       }
    }

    await db
      .collection("properties")
      .updateOne({ _id: listingId }, { $set: updates });

    const query = { propertyId: listingId };
    if (activeSubCategoryId) {
       query.subCategoryId = activeSubCategoryId;
    } else {
       query.subCategoryId = { $in: [null, undefined] };
    }

    const allSlots = await db
      .collection("slots")
      .find(query)
      .sort({ start: 1 })
      .toArray();

    let baseSyncDates = buildDateRange(getIndiaIsoDate(new Date()), 31);
    if ((nextProperty.category === "event" || nextProperty.category === "cinema") && Array.isArray(nextProperty.eventDates) && nextProperty.eventDates.length > 0) {
      baseSyncDates = nextProperty.eventDates;
    }
    const syncDates =
      mode === "date"
        ? [date]
        : baseSyncDates;

    await syncSlotsForDates({
      db,
      property: nextProperty,
      propertyId: listingId,
      subCategoryId: activeSubCategoryId,
      allSlots,
      dates: syncDates,
    });

    const refreshedQuery = { ...query };
    if (mode === "date") {
       refreshedQuery.start = new RegExp(`^${date}`);
    }

    const refreshedSlots = await db
      .collection("slots")
      .find(refreshedQuery)
      .sort({ start: 1 })
      .toArray();

    return Response.json({
      success: true,
      mode,
      date: mode === "date" ? date : null,
      slots:
        mode === "date"
          ? refreshedSlots.map(slot => mapSlotToResponse(slot, nextProperty.category))
          : normalizedSlots.map(mapTemplateToResponse),
    });
  } catch (error) {
    console.error("Slots POST error:", error);
    return Response.json({ error: "Failed to update slots" }, { status: 500 });
  }
}

function getIndiaIsoDate(input) {
  return new Date(input).toLocaleDateString("en-CA", {
    timeZone: "Asia/Kolkata",
  });
}

function buildDateRange(startIso, days) {
  return Array.from({ length: days }, (_, index) => addDays(startIso, index));
}

function addDays(isoDate, days) {
  const dt = new Date(`${isoDate}T00:00:00+05:30`);
  dt.setDate(dt.getDate() + days);
  return getIndiaIsoDate(dt);
}

function isIsoDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));
}

function mapSlotToResponse(slot, category) {
  const startTimeStr = formatSlotTime(slot.start);
  const endTimeStr = formatSlotTime(slot.end);
  
  let displayTime = startTimeStr;
  if (category === "event" || category === "cinema") {
    displayTime = `${startTimeStr} - ${endTimeStr}`;
  }
  
  return {
    _id: slot._id,
    time: displayTime,
    start: slot.start,
    end: slot.end,
    startTime: slot.start.slice(11, 16),
    endTime: slot.end.slice(11, 16),
    capacity: Number(slot.capacity) || 0,
    booked: Number(slot.booked) || 0,
    seatsBooked: Array.isArray(slot.seatsBooked) ? slot.seatsBooked : [],
    available: Number(slot.booked) < Number(slot.capacity),
  };
}

function mapTemplateToResponse(slot) {
  return {
    time: `${formatTime(slot.startTime)} - ${formatTime(slot.endTime)}`,
    startTime: slot.startTime,
    endTime: slot.endTime,
    capacity: slot.capacity,
    available: true,
  };
}

function generateSlotsFromHours(openTime, closeTime, category, capacity) {
  const config = getCategoryConfig(category);
  const durationMins = config?.slotDuration || 60;

  const [openHour, openMin] = openTime.split(":").map(Number);
  const [closeHour, closeMin] = closeTime.split(":").map(Number);

  const slots = [];
  let currentTime = new Date();
  currentTime.setHours(openHour, openMin, 0, 0);

  const endTime = new Date();
  endTime.setHours(closeHour, closeMin, 0, 0);

  while (currentTime < endTime) {
    const startTime = `${String(currentTime.getHours()).padStart(2, "0")}:${String(
      currentTime.getMinutes(),
    ).padStart(2, "0")}`;

    const nextSlot = new Date(currentTime);
    nextSlot.setMinutes(nextSlot.getMinutes() + durationMins);

    if (nextSlot > endTime) {
      nextSlot.setTime(endTime.getTime());
    }

    const endSlotTime = `${String(nextSlot.getHours()).padStart(2, "0")}:${String(
      nextSlot.getMinutes(),
    ).padStart(2, "0")}`;

    slots.push({
      startTime,
      endTime: endSlotTime,
      capacity,
    });

    currentTime = nextSlot;
  }

  return slots;
}

function getDefaultTemplate(property, allSlots, subCategoryId) {
  // When a subCategoryId is specified, only look at that sub-category's config
  if (subCategoryId) {
    const subConfig = property?.subCategorySlots?.[subCategoryId];
    if (subConfig?.slotTemplate !== undefined) {
      return normalizeTemplateEntries(
        subConfig.slotTemplate || [],
        Number(property?.capacityPerSlot) || 100
      );
    }
    // Sub-category has no config yet — check for existing slot docs in DB
    const derived = deriveTemplateFromExisting(allSlots);
    if (derived.length > 0) {
      return derived;
    }
    // No slots configured for this sub-category yet — return empty
    return [];
  }

  // No subCategoryId — use property-level template
  if (property?.slotTemplate !== undefined) {
    return normalizeTemplateEntries(
      property.slotTemplate || [],
      Number(property?.capacityPerSlot) || 100,
    );
  }

  const derived = deriveTemplateFromExisting(allSlots);
  if (derived.length > 0) {
    return derived;
  }

  return [];
}

function hasDateOverride(property, date, subCategoryId) {
  if (subCategoryId && property?.subCategorySlots?.[subCategoryId]) {
     const subOverrides = property.subCategorySlots[subCategoryId].slotOverrides;
     return Boolean(subOverrides && Object.prototype.hasOwnProperty.call(subOverrides, date));
  }
  return Boolean(
    property?.slotOverrides &&
    Object.prototype.hasOwnProperty.call(property.slotOverrides, date),
  );
}

function getTemplateForDate(property, allSlots, date, subCategoryId) {
  if (hasDateOverride(property, date, subCategoryId)) {
    let overrides = [];
    if (subCategoryId && property?.subCategorySlots?.[subCategoryId]) {
        overrides = property.subCategorySlots[subCategoryId].slotOverrides[date] || [];
    } else {
        overrides = property.slotOverrides[date] || [];
    }
    return normalizeTemplateEntries(
      overrides,
      Number(property?.capacityPerSlot) || 100,
    );
  }

  return getDefaultTemplate(property, allSlots, subCategoryId);
}

function deriveTemplateFromExisting(allSlots) {
  if (!Array.isArray(allSlots) || allSlots.length === 0) {
    return [];
  }

  const latestDate = [...allSlots]
    .reverse()
    .find((slot) => slot.start)
    ?.start?.slice(0, 10);
  if (!latestDate) {
    return [];
  }

  return normalizeTemplateEntries(
    allSlots
      .filter((slot) => slot.start.startsWith(latestDate))
      .map((slot) => ({
        startTime: slot.start.slice(11, 16),
        endTime: slot.end.slice(11, 16),
        capacity: Number(slot.capacity) || 100,
      })),
    100,
  );
}

function normalizeTemplateEntries(entries, defaultCapacity = 100) {
  if (!Array.isArray(entries)) {
    return [];
  }

  const seen = new Set();
  return entries
    .map((entry, index) => {
      const startTime =
        normalizeTime(entry?.startTime || entry?.start?.slice?.(11, 16)) ||
        normalizeTime(parseLabelTime(entry?.time)?.startTime);
      const endTime =
        normalizeTime(entry?.endTime || entry?.end?.slice?.(11, 16)) ||
        normalizeTime(parseLabelTime(entry?.time)?.endTime) ||
        (startTime ? addHour(startTime) : "");
      const capacity = Math.max(
        1,
        Number(entry?.capacity) || Number(defaultCapacity) || 100,
      );
      const available = entry?.available !== false;

      if (!startTime || !endTime || !available) {
        return null;
      }

      const key = `${startTime}|${endTime}`;
      if (seen.has(key)) {
        return null;
      }
      seen.add(key);

      return {
        id: entry?.id || `slot-${index + 1}`,
        startTime,
        endTime,
        capacity,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));
}

function normalizeTime(value) {
  if (typeof value !== "string") {
    return "";
  }

  const trimmed = value.trim();
  if (/^\d{2}:\d{2}$/.test(trimmed)) {
    return trimmed;
  }
  return "";
}

function parseLabelTime(value) {
  if (typeof value !== "string" || !value.includes("-")) {
    return null;
  }
  const [rawStart, rawEnd] = value.split("-").map((part) => part.trim());
  return {
    startTime: from12Hour(rawStart),
    endTime: from12Hour(rawEnd),
  };
}

function from12Hour(value) {
  const match = String(value || "")
    .trim()
    .match(/^(\d{1,2}):(\d{2})\s?(AM|PM)$/i);
  if (!match) {
    return "";
  }
  let hours = Number(match[1]);
  const minutes = match[2];
  const meridiem = match[3].toUpperCase();

  if (meridiem === "AM" && hours === 12) {
    hours = 0;
  } else if (meridiem === "PM" && hours !== 12) {
    hours += 12;
  }

  return `${String(hours).padStart(2, "0")}:${minutes}`;
}

function addHour(startTime) {
  const [hours, minutes] = String(startTime || "09:00")
    .split(":")
    .map(Number);
  const dt = new Date();
  dt.setHours(hours || 0, minutes || 0, 0, 0);
  dt.setHours(dt.getHours() + 1);
  return `${String(dt.getHours()).padStart(2, "0")}:${String(
    dt.getMinutes(),
  ).padStart(2, "0")}`;
}

function buildSlotDocument(propertyId, date, templateEntry, subCategoryId) {
  return {
    propertyId,
    subCategoryId: subCategoryId || null,
    start: `${date}T${templateEntry.startTime}:00+05:30`,
    end: `${date}T${templateEntry.endTime}:00+05:30`,
    capacity: templateEntry.capacity,
    booked: 0,
    seatsBooked: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

async function syncSlotsForDates({
  db,
  property,
  propertyId,
  subCategoryId,
  allSlots,
  dates,
}) {
  const existingByDate = new Map();
  (allSlots || []).forEach((slot) => {
    const date = slot.start.slice(0, 10);
    if (!existingByDate.has(date)) {
      existingByDate.set(date, []);
    }
    existingByDate.get(date).push(slot);
  });

  const inserts = [];
  const deletes = [];
  const updates = [];

  dates.forEach((date) => {
    const template = getTemplateForDate(property, allSlots, date, subCategoryId);
    const desiredByStart = new Map(
      template.map((entry) => [
        `${date}T${entry.startTime}:00+05:30`,
        {
          start: `${date}T${entry.startTime}:00+05:30`,
          end: `${date}T${entry.endTime}:00+05:30`,
          capacity: entry.capacity,
        },
      ]),
    );

    const current = existingByDate.get(date) || [];
    const existingStarts = new Set(current.map((slot) => slot.start));

    current.forEach((slot) => {
      const desired = desiredByStart.get(slot.start);
      if (!desired) {
        if ((Number(slot.booked) || 0) === 0) {
          deletes.push(slot._id);
        }
        return;
      }

      const nextCapacity = Number(desired.capacity) || 0;
      if (slot.end !== desired.end || Number(slot.capacity) !== nextCapacity) {
        updates.push({
          _id: slot._id,
          end: desired.end,
          capacity: Math.max(nextCapacity, Number(slot.booked) || 0, 1),
        });
      }
    });

    desiredByStart.forEach((desired, start) => {
      if (!existingStarts.has(start)) {
        inserts.push(
          buildSlotDocument(propertyId, date, {
            startTime: desired.start.slice(11, 16),
            endTime: desired.end.slice(11, 16),
            capacity: desired.capacity,
          }, subCategoryId),
        );
      }
    });
  });

  if (deletes.length > 0) {
    await db.collection("slots").deleteMany({ _id: { $in: deletes } });
  }

  if (updates.length > 0) {
    await Promise.all(
      updates.map((slot) =>
        db.collection("slots").updateOne(
          { _id: slot._id },
          {
            $set: {
              end: slot.end,
              capacity: slot.capacity,
              updatedAt: new Date().toISOString(),
            },
          },
        ),
      ),
    );
  }

  if (inserts.length > 0) {
    await db.collection("slots").insertMany(inserts, { ordered: false });
  }

  return {
    changed: deletes.length > 0 || updates.length > 0 || inserts.length > 0,
    slotTemplate: subCategoryId ? property?.subCategorySlots?.[subCategoryId]?.slotTemplate : property.slotTemplate,
    slotOverrides: subCategoryId ? property?.subCategorySlots?.[subCategoryId]?.slotOverrides : property.slotOverrides,
  };
}

function formatSlotTime(isoStr) {
  const match = isoStr.match(/T(\d{2}):(\d{2})/);
  if (!match) {
    return isoStr;
  }
  return formatTime(`${match[1]}:${match[2]}`);
}

function formatTime(time) {
  const [hoursRaw, minutes = "00"] = String(time || "00:00").split(":");
  let hours = Number(hoursRaw);
  const ampm = hours >= 12 ? "PM" : "AM";

  if (hours === 0) {
    hours = 12;
  } else if (hours > 12) {
    hours -= 12;
  }

  return `${String(hours).padStart(2, "0")}:${minutes} ${ampm}`;
}
