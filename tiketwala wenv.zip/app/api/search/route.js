import { getDb } from "@/lib/mongodb";
import { getDefaultImage } from "@/lib/typeIcons";
import { normalizeCategory, getCategoryLabel, normalizeImageGallery } from "@/lib/listingUtils";

/**
 * GET /api/search?q=<query>&limit=6
 * Lightweight search endpoint for navbar autocomplete.
 * Searches properties by name, address, category.
 * Does NOT preload all listings — only queries on demand.
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = (searchParams.get("q") || "").trim();
    const limit = Math.min(Math.max(1, Number(searchParams.get("limit")) || 6), 20);

    if (!query || query.length < 2) {
      return Response.json([]);
    }

    const db = await getDb();

    // Case-insensitive regex search on name, address, and category
    const regex = { $regex: query, $options: "i" };
    const filter = {
      active: { $ne: false },
      $or: [
        { name: regex },
        { address: regex },
        { category: regex },
      ],
    };

    // Also try to match category aliases
    const normalizedCategory = normalizeCategory(query);
    if (normalizedCategory) {
      filter.$or.push({ category: normalizedCategory });
    }

    const properties = await db
      .collection("properties")
      .find(filter)
      .sort({ name: 1 })
      .limit(limit)
      .toArray();

    if (properties.length === 0) {
      return Response.json([]);
    }

    // Fetch businesses for location info
    const businessIds = [...new Set(properties.map((p) => p.businessId).filter(Boolean))];
    const businesses = businessIds.length
      ? await db
          .collection("businesses")
          .find({ _id: { $in: businessIds } })
          .project({ _id: 1, "location.city": 1, "location.state": 1 })
          .toArray()
      : [];
    const businessMap = Object.fromEntries(
      businesses.map((b) => [b._id, b]),
    );

    const results = properties.map((property) => {
      const category = normalizeCategory(property.category) || "park";
      const business = businessMap[property.businessId];
      const gallery = normalizeImageGallery(
        [...(Array.isArray(property.images) ? property.images : []), property.imageUrl],
        category,
      );
      const location =
        property.address ||
        (business
          ? `${business.location?.city || "Odisha"}, ${business.location?.state || "India"}`
          : "Odisha, India");

      // Get starting price from sub-categories or legacy pricing
      let price = 0;
      if (Array.isArray(property.subCategories) && property.subCategories.length > 0) {
        const prices = property.subCategories
          .map((s) => Number(s?.price))
          .filter((p) => Number.isFinite(p) && p >= 0);
        price = prices.length > 0 ? Math.min(...prices) : 0;
      } else if (property.pricing?.adult) {
        price = Number(property.pricing.adult) || 0;
      } else if (Array.isArray(property.offerings) && property.offerings.length > 0) {
        const offeringPrices = property.offerings
          .map((o) => Number(o?.price))
          .filter((p) => Number.isFinite(p) && p >= 0);
        price = offeringPrices.length > 0 ? Math.min(...offeringPrices) : 0;
      }

      return {
        id: property._id,
        name: property.name,
        type: getCategoryLabel(category),
        category,
        location,
        image: gallery[0] || getDefaultImage(category),
        price,
      };
    });

    return Response.json(results);
  } catch (error) {
    console.error("Search API error:", error);
    return Response.json([], { status: 500 });
  }
}
