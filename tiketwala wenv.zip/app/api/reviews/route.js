import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";

/**
 * POST /api/reviews
 * Create a review for a listing. Requires a confirmed booking.
 */
export async function POST(request) {
  try {
    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { listingId, rating, comment } = body;

    if (!listingId) {
      return Response.json(
        { success: false, error: "listingId is required" },
        { status: 400 },
      );
    }

    const numRating = Number(rating);
    if (!Number.isFinite(numRating) || numRating < 1 || numRating > 5) {
      return Response.json(
        { success: false, error: "Rating must be between 1 and 5" },
        { status: 400 },
      );
    }

    const db = await getDb();

    // Backend validation: user must have a confirmed booking for this listing
    const confirmedBooking = await db.collection("bookings").findOne({
      customerEmail: auth.user.email,
      propertyId: listingId,
      status: "confirmed",
    });

    if (!confirmedBooking) {
      return Response.json(
        {
          success: false,
          error:
            "You can only review listings where you have a confirmed booking",
        },
        { status: 403 },
      );
    }

    // Prevent duplicate reviews for the same listing
    const existingReview = await db.collection("reviews").findOne({
      customerId: auth.user._id,
      listingId,
    });

    if (existingReview) {
      // Update the existing review
      await db.collection("reviews").updateOne(
        { _id: existingReview._id },
        {
          $set: {
            rating: Math.round(numRating),
            comment: String(comment || "").trim(),
            updatedAt: new Date().toISOString(),
          },
        },
      );

      const updated = await db
        .collection("reviews")
        .findOne({ _id: existingReview._id });
      return Response.json({ success: true, review: updated, updated: true });
    }

    const now = new Date().toISOString();
    const review = {
      _id:
        "rev_" +
        Date.now().toString(36) +
        Math.random().toString(36).slice(2, 6),
      listingId,
      customerId: auth.user._id,
      customerName: auth.user.name || auth.user.email.split("@")[0],
      customerEmail: auth.user.email,
      bookingId: confirmedBooking.bookingId,
      rating: Math.round(numRating),
      comment: String(comment || "").trim(),
      createdAt: now,
      updatedAt: now,
    };

    await db.collection("reviews").insertOne(review);
    return Response.json({ success: true, review }, { status: 201 });
  } catch (error) {
    console.error("Create review error:", error);
    return Response.json(
      { success: false, error: "Failed to create review" },
      { status: 500 },
    );
  }
}

/**
 * GET /api/reviews?listingId=<id>
 * Fetch reviews for a listing. Optionally returns average rating.
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const listingId = searchParams.get("listingId");

    if (!listingId) {
      return Response.json(
        { success: false, error: "listingId query param is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const reviews = await db
      .collection("reviews")
      .find({ listingId })
      .sort({ createdAt: -1 })
      .toArray();

    // Calculate average rating
    const totalRatings = reviews.length;
    const averageRating =
      totalRatings > 0
        ? Math.round(
            (reviews.reduce((sum, r) => sum + r.rating, 0) / totalRatings) * 10,
          ) / 10
        : 0;

    return Response.json({
      success: true,
      reviews,
      averageRating,
      totalRatings,
    });
  } catch (error) {
    console.error("Fetch reviews error:", error);
    return Response.json(
      { success: false, error: "Failed to fetch reviews" },
      { status: 500 },
    );
  }
}

/**
 * PUT /api/reviews?id=<reviewId>
 * Update a review (only by the creator)
 */
export async function PUT(request) {
  try {
    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const reviewId = searchParams.get("id");

    if (!reviewId) {
      return Response.json(
        { success: false, error: "Review ID is required" },
        { status: 400 },
      );
    }

    const body = await request.json();
    const { rating, comment } = body;

    if (!rating || !comment) {
      return Response.json(
        { success: false, error: "Rating and comment are required" },
        { status: 400 },
      );
    }

    const numRating = Number(rating);
    if (!Number.isFinite(numRating) || numRating < 1 || numRating > 5) {
      return Response.json(
        { success: false, error: "Rating must be between 1 and 5" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const review = await db.collection("reviews").findOne({ _id: reviewId });

    if (!review) {
      return Response.json(
        { success: false, error: "Review not found" },
        { status: 404 },
      );
    }

    // Check ownership
    if (review.customerId !== auth.user._id) {
      return Response.json(
        { success: false, error: "You can only edit your own reviews" },
        { status: 403 },
      );
    }

    const now = new Date().toISOString();
    await db.collection("reviews").updateOne(
      { _id: reviewId },
      {
        $set: {
          rating: Math.round(numRating),
          comment: String(comment).trim(),
          updatedAt: now,
        },
      },
    );

    // Recalculate listing averages
    const listingId = review.listingId;
    const allReviews = await db
      .collection("reviews")
      .find({ listingId })
      .toArray();

    const avgRating = allReviews.length
      ? Math.round(
          (allReviews.reduce((sum, r) => sum + r.rating, 0) /
            allReviews.length) *
            10,
        ) / 10
      : 0;

    await db.collection("properties").updateOne(
      { _id: listingId },
      {
        $set: {
          averageRating: avgRating,
          totalReviews: allReviews.length,
          updatedAt: now,
        },
      },
    );

    const updated = await db.collection("reviews").findOne({ _id: reviewId });
    return Response.json({ success: true, review: updated });
  } catch (error) {
    console.error("Update review error:", error);
    return Response.json(
      { success: false, error: "Failed to update review" },
      { status: 500 },
    );
  }
}

/**
 * DELETE /api/reviews?id=<reviewId>
 * Delete a review (only by the creator)
 */
export async function DELETE(request) {
  try {
    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const reviewId = searchParams.get("id");

    if (!reviewId) {
      return Response.json(
        { success: false, error: "Review ID is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const review = await db.collection("reviews").findOne({ _id: reviewId });

    if (!review) {
      return Response.json(
        { success: false, error: "Review not found" },
        { status: 404 },
      );
    }

    // Check ownership
    if (review.customerId !== auth.user._id) {
      return Response.json(
        { success: false, error: "You can only delete your own reviews" },
        { status: 403 },
      );
    }

    const listingId = review.listingId;
    await db.collection("reviews").deleteOne({ _id: reviewId });

    // Recalculate listing stats
    const allReviews = await db
      .collection("reviews")
      .find({ listingId })
      .toArray();

    const avgRating = allReviews.length
      ? Math.round(
          (allReviews.reduce((sum, r) => sum + r.rating, 0) /
            allReviews.length) *
            10,
        ) / 10
      : 0;

    const now = new Date().toISOString();
    await db.collection("properties").updateOne(
      { _id: listingId },
      {
        $set: {
          averageRating: avgRating,
          totalReviews: allReviews.length,
          updatedAt: now,
        },
      },
    );

    return Response.json({ success: true, message: "Review deleted" });
  } catch (error) {
    console.error("Delete review error:", error);
    return Response.json(
      { success: false, error: "Failed to delete review" },
      { status: 500 },
    );
  }
}
