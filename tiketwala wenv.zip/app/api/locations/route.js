import { getDb } from "@/lib/mongodb";

/**
 * GET /api/locations
 * Returns unique business locations to populate the filter dropdown.
 * Merges locations from both businesses and properties for full coverage.
 */
export async function GET() {
  try {
    const db = await getDb();
    const [businesses, properties] = await Promise.all([
      db.collection("businesses").find({}).toArray(),
      db.collection("properties").find({}, { projection: { address: 1, businessId: 1 } }).toArray(),
    ]);

    // Extract unique locations and keep the first coordinate set for each city
    const locationMap = new Map();

    businesses.forEach((b) => {
      if (
        b.location &&
        b.location.city &&
        b.location.state &&
        b.location.coordinates
      ) {
        const cityStr = `${b.location.city}, ${b.location.state}`;
        if (!locationMap.has(cityStr)) {
          locationMap.set(cityStr, {
            cityStr,
            coords: b.location.coordinates, // [lng, lat] from GeoJSON
          });
        }
      }
    });

    // Also extract locations from properties' address field
    const businessMap = new Map(
      businesses.map((b) => [b._id, b]),
    );
    properties.forEach((p) => {
      if (p.address) {
        // Extract city from "City, State" format
        const parts = p.address.split(",").map((s) => s.trim());
        if (parts.length >= 2) {
          const cityStr = `${parts[0]}, ${parts[1]}`;
          if (!locationMap.has(cityStr)) {
            // Try to get coords from the parent business
            const business = businessMap.get(p.businessId);
            const coords = business?.location?.coordinates || [0, 0];
            locationMap.set(cityStr, { cityStr, coords });
          }
        }
      }
    });

    const uniqueLocations = Array.from(locationMap.values());

    return Response.json({ success: true, locations: uniqueLocations });
  } catch (error) {
    console.error("Locations API error:", error);
    return Response.json(
      { error: "Failed to fetch locations" },
      { status: 500 },
    );
  }
}

