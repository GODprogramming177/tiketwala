import { getDb } from "@/lib/mongodb";
import { getDefaultImage } from "@/lib/typeIcons";
import { requireRole, canAccessBusiness } from "@/lib/rbac";
import { getCategoryHours } from "@/lib/categoryConfig";
import { enforceApiAccess } from "@/lib/apiAccess";
import {
  calculatePropertyPricing,
  getBusinessAllowedTypes,
  getBusinessListingLimit,
  getCategoryLabel,
  getListingStartingPrice,
  normalizeFareRules,
  normalizeImageGallery,
  normalizeAddOns,
  normalizeSubCategories,
  normalizeCategory,
} from "@/lib/listingUtils";

/**
 * GET /api/listings
 * Returns listings with optional type, location, owner, or business filters.
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const { searchParams } = new URL(request.url);
    const type = normalizeCategory(searchParams.get("type"));
    const id = searchParams.get("id");
    const location = searchParams.get("location");
    const lat = searchParams.get("lat");
    const lng = searchParams.get("lng");
    const ownerId = searchParams.get("ownerId");
    const businessId = searchParams.get("businessId");

    const db = await getDb();

    if (id) {
      const property = await db.collection("properties").findOne({ _id: id });
      if (!property) {
        return Response.json({ error: "Listing not found" }, { status: 404 });
      }

      const business = await db
        .collection("businesses")
        .findOne({ _id: property.businessId });
      const owner = business?.ownerIds?.length
        ? await db
            .collection("users")
            .findOne(
              { _id: business.ownerIds[0] },
              { projection: { name: 1, email: 1 } },
            )
        : null;

      const reviewStats = await db
        .collection("reviews")
        .aggregate([
          { $match: { listingId: id } },
          { $group: { _id: null, avgRating: { $avg: "$rating" } } },
        ])
        .toArray();
      const avgRating = reviewStats.length
        ? Math.round(reviewStats[0].avgRating * 10) / 10
        : 0;

      return Response.json(
        mapPropertyToListing(property, business, owner, avgRating),
      );
    }

    const filter = {};
    if (type) {
      filter.category = type;
    }

    let scopedAuth = null;
    if (ownerId || businessId) {
      scopedAuth = await requireRole(request, [
        "owner",
        "superadmin",
        "worker",
      ]);
      if (scopedAuth.error) {
        return scopedAuth.error;
      }
    }

    if (ownerId) {
      if (scopedAuth.user.role === "worker") {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }

      if (scopedAuth.user.role === "owner" && ownerId !== scopedAuth.user._id) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }

      const user = await db.collection("users").findOne({ _id: ownerId });
      const orConditions = [{ ownerIds: ownerId }];
      if (user?.email) {
        orConditions.push({ ownerEmail: user.email });
      }
      const ownerBusinesses = await db
        .collection("businesses")
        .find({ $or: orConditions })
        .project({ _id: 1 })
        .toArray();
      filter.businessId = {
        $in: ownerBusinesses.map((business) => business._id),
      };
    } else if (businessId) {
      if (
        (scopedAuth.user.role === "owner" ||
          scopedAuth.user.role === "worker") &&
        !canAccessBusiness(scopedAuth, businessId)
      ) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
      filter.businessId = businessId;
    }

    const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
    const limitParam = searchParams.get("limit");
    // Default limit to a high number backward compatibility, or 20 if explicitly provided
    const limit = limitParam ? Math.max(1, parseInt(limitParam, 10)) : 100;
    const skip = (page - 1) * limit;

    const totalCount = await db.collection("properties").countDocuments(filter);
    const totalPages = Math.ceil(totalCount / limit);

    const properties = await db
      .collection("properties")
      .find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .toArray();
    const businessIds = [
      ...new Set(properties.map((property) => property.businessId)),
    ];

    const businesses = businessIds.length
      ? await db
          .collection("businesses")
          .find({ _id: { $in: businessIds } })
          .toArray()
      : [];
    const businessMap = Object.fromEntries(
      businesses.map((business) => [business._id, business]),
    );

    const ownerIds = [
      ...new Set(
        businesses.flatMap((business) =>
          Array.isArray(business.ownerIds) ? business.ownerIds : [],
        ),
      ),
    ];
    const owners = ownerIds.length
      ? await db
          .collection("users")
          .find({ _id: { $in: ownerIds } })
          .project({ _id: 1, name: 1, email: 1 })
          .toArray()
      : [];
    const ownerMap = Object.fromEntries(
      owners.map((owner) => [owner._id, owner]),
    );

    const listingIds = properties.map((p) => p._id);
    const reviewStats = await db
      .collection("reviews")
      .aggregate([
        { $match: { listingId: { $in: listingIds } } },
        { $group: { _id: "$listingId", avgRating: { $avg: "$rating" } } },
      ])
      .toArray();
    const ratingsMap = Object.fromEntries(
      reviewStats.map((r) => [r._id, Math.round(r.avgRating * 10) / 10]),
    );

    let listings = properties.map((property) => {
      const business = businessMap[property.businessId];
      const owner =
        business?.ownerIds?.length > 0 ? ownerMap[business.ownerIds[0]] : null;
      return mapPropertyToListing(
        property,
        business,
        owner,
        ratingsMap[property._id] || 0,
      );
    });

    if (location) {
      const citySearch = location.split(",")[0].trim().toLowerCase();
      listings = listings.filter((listing) =>
        listing.location.toLowerCase().includes(citySearch),
      );
    }

    if (lat && lng && !location) {
      const MAX_DISTANCE_KM = 100;
      const userLat = Number(lat);
      const userLng = Number(lng);

      listings = listings.filter((listing) => {
        if (Array.isArray(listing.coords) && listing.coords.length === 2) {
          listing.distanceKm = getDistance(
            userLat,
            userLng,
            listing.coords[0],
            listing.coords[1],
          );
          return listing.distanceKm <= MAX_DISTANCE_KM;
        }
        return false;
      });

      listings.sort((a, b) => a.distanceKm - b.distanceKm);
    }

    // Apply post-filtering pagination if geo/location was used
    if (location || (lat && lng)) {
       listings = listings.slice(skip, skip + limit);
    }

    return Response.json(listings, {
      headers: {
        "X-Total-Count": totalCount.toString(),
        "X-Total-Pages": totalPages.toString(),
        "X-Current-Page": page.toString(),
        "X-Page-Limit": limit.toString()
      }
    });
  } catch (error) {
    console.error("Listings API error:", error);
    return Response.json(
      { error: "Failed to fetch listings" },
      { status: 500 },
    );
  }
}

/**
 * POST /api/listings
 * Create a property under an allowed business with enforced admin controls.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { businessId } = body;

    if (!businessId) {
      return Response.json(
        { error: "businessId is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const business = await db
      .collection("businesses")
      .findOne({ _id: businessId });
    if (!business) {
      return Response.json({ error: "Business not found" }, { status: 404 });
    }

    if (auth.user.role === "owner" && !canAccessBusiness(auth, businessId)) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const payload = buildPropertyPayload(body);
    const allowedTypes = getBusinessAllowedTypes(business);
    if (!allowedTypes.includes(payload.category)) {
      return Response.json(
        {
          error: `This admin can only create: ${allowedTypes.join(", ")}`,
        },
        { status: 403 },
      );
    }

    const listingLimit = getBusinessListingLimit(business);
    if (listingLimit) {
      const existingCount = await db
        .collection("properties")
        .countDocuments({ businessId });
      if (existingCount >= listingLimit) {
        return Response.json(
          { error: `Listing limit reached for this admin (${listingLimit})` },
          { status: 403 },
        );
      }
    }

    const nowIso = new Date().toISOString();
    const newProperty = {
      _id: crypto.randomUUID().replace(/-/g, "").slice(0, 24),
      ...payload,
      businessId,
      active: true,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    await db.collection("properties").insertOne(newProperty);
    return Response.json(newProperty, { status: 201 });
  } catch (error) {
    console.error("Create listing error:", error);
    if (error.message === "Unsupported listing type") {
      return Response.json({ error: error.message }, { status: 400 });
    }
    return Response.json(
      { error: "Failed to create listing" },
      { status: 500 },
    );
  }
}

/**
 * PUT /api/listings
 * Update a listing while respecting the business controls.
 */
export async function PUT(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const listingId = body.id || body.listingId;
    if (!listingId) {
      return Response.json({ error: "listingId is required" }, { status: 400 });
    }

    const db = await getDb();
    const existing = await db
      .collection("properties")
      .findOne({ _id: listingId });
    if (!existing) {
      return Response.json({ error: "Listing not found" }, { status: 404 });
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, existing.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const business = await db
      .collection("businesses")
      .findOne({ _id: existing.businessId });

    const mergedInput = { ...existing, ...body };
    const updates = {
      ...buildPropertyPayload(mergedInput),
      updatedAt: new Date().toISOString(),
    };

    // Preserve subCategorySlots (slot configs) — buildPropertyPayload doesn't handle these
    if (existing.subCategorySlots) {
      updates.subCategorySlots = existing.subCategorySlots;
    }
    // Preserve slotTemplate and slotOverrides
    if (existing.slotTemplate !== undefined) {
      updates.slotTemplate = existing.slotTemplate;
    }
    if (existing.slotOverrides !== undefined) {
      updates.slotOverrides = existing.slotOverrides;
    }

    console.log("[PUT /api/listings] incoming subCategories:", JSON.stringify(body.subCategories));
    console.log("[PUT /api/listings] final subCategories:", JSON.stringify(updates.subCategories));

    const allowedTypes = getBusinessAllowedTypes(business);
    if (!allowedTypes.includes(updates.category)) {
      return Response.json(
        {
          error: `This admin can only manage: ${allowedTypes.join(", ")}`,
        },
        { status: 403 },
      );
    }

    delete updates.businessId;
    delete updates.createdAt;

    await db
      .collection("properties")
      .updateOne({ _id: listingId }, { $set: updates });

    const updated = await db
      .collection("properties")
      .findOne({ _id: listingId });
    return Response.json(updated);
  } catch (error) {
    console.error("Update listing error:", error);
    if (error.message === "Unsupported listing type") {
      return Response.json({ error: error.message }, { status: 400 });
    }
    return Response.json(
      { error: "Failed to update listing" },
      { status: 500 },
    );
  }
}

/**
 * DELETE /api/listings?id=<listingId>
 */
export async function DELETE(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const listingId = searchParams.get("id");
    if (!listingId) {
      return Response.json(
        { error: "listing id is required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const existing = await db
      .collection("properties")
      .findOne({ _id: listingId });
    if (!existing) {
      return Response.json({ error: "Listing not found" }, { status: 404 });
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, existing.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    await db.collection("properties").deleteOne({ _id: listingId });
    return Response.json({ success: true });
  } catch (error) {
    console.error("Delete listing error:", error);
    return Response.json(
      { error: "Failed to delete listing" },
      { status: 500 },
    );
  }
}

function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) *
      Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function deg2rad(deg) {
  return deg * (Math.PI / 180);
}

export function mapPropertyToListing(property, business, owner, avgRating = 0) {
  const category = normalizeCategory(property.category) || "park";
  const gallery = normalizeImageGallery(
    [
      ...(Array.isArray(property.images) ? property.images : []),
      property.imageUrl,
    ],
    category,
  );
  const storedImages = [
    ...(Array.isArray(property.images) ? property.images : []),
    property.imageUrl,
  ]
    .map((image) => String(image || "").trim())
    .filter(Boolean);
  const location =
    property.address ||
    (business
      ? `${business.location?.city || "Odisha"}, ${business.location?.state || "India"}`
      : "Odisha, India");

  const businessCoords =
    business?.location?.coordinates || business?.location?.coords || null;
  const coords =
    Array.isArray(businessCoords) && businessCoords.length === 2
      ? [businessCoords[1], businessCoords[0]]
      : null;

  const pricingPreview = calculatePropertyPricing(property, { quantity: 1 });
  const subCategories = normalizeSubCategories(property.subCategories);
  const defaultChildFare =
    subCategories[0]?.childPrice ??
    property?.pricing?.child ??
    pricingPreview.unitPrice;
  const fareRules = normalizeFareRules(property.fareRules, {
    enabled: false,
    adultFare: pricingPreview.unitPrice,
    childFare: defaultChildFare,
  });

  return {
    id: property._id,
    name: property.name,
    type: getCategoryLabel(category),
    category,
    location,
    businessId: property.businessId || null,
    businessName: business?.name || "",
    ownerIds: business?.ownerIds || [],
    ownerName: owner?.name || business?.ownerName || "",
    ownerEmail: owner?.email || business?.ownerEmail || "",
    listingLimit: getBusinessListingLimit(business),
    allowedListingTypes: business ? getBusinessAllowedTypes(business) : [],
    coords,
    image: gallery[0] || getDefaultImage(category),
    images: gallery,
    storedImages,
    description: property.shortDesc || "",
    price: getListingStartingPrice(property),
    totalBasePrice: pricingPreview.baseAmount || 0,
    rating: avgRating || 4.5,
    operatingHours: property.operatingHours,
    fareRules,
    subCategories,
    addOns: normalizeAddOns(property.addOns),
    ...(category === "park" && {
      rides: property.rides,
      pricing: property.pricing,
      capacityPerSlot: property.capacityPerSlot,
    }),
    ...(category === "cinema" && {
      pricing: property.pricing,
      capacityPerSlot: property.capacityPerSlot,
      screenInfo: property.screenInfo || {},
      seating: property.seating || { rows: 0, cols: 0, seats: [] },
    }),
    ...(category === "temple" && { offerings: property.offerings }),
    ...(category === "event" && {
      eventDates: property.eventDates,
      eventDate: property.eventDate,
      eventTime: property.eventTime,
      seating: property.seating,
    }),
  };
}

function buildPropertyPayload(input) {
  const category = normalizeCategory(input.category || input.type || "park");
  if (!category) {
    throw new Error("Unsupported listing type");
  }

  const gallery = normalizeImageGallery(
    [
      ...(Array.isArray(input.images) ? input.images : []),
      input.imageUrl,
      input.image,
    ].filter(Boolean),
    category,
  );
  const rawGallery = gallery.filter(
    (image) => image !== getDefaultImage(category),
  );

  const price = Math.max(0, Number(input.price) || 0);
  const subCategories = normalizeSubCategories(input.subCategories || []);
  const fallbackChildFare =
    subCategories[0]?.childPrice ?? input?.pricing?.child ?? price;
  const fareRules = normalizeFareRules(input.fareRules, {
    enabled: input?.fareRules?.enabled === true,
    adultFare: price,
    childFare: fallbackChildFare,
  });

  // Use category-specific default operating hours
  const categoryDefaults = getCategoryHours(category);
  const defaultHours = {
    open: categoryDefaults.open,
    close: categoryDefaults.close,
  };

  const payload = {
    name: String(input.name || "Untitled Listing").trim(),
    category,
    address: String(input.address || input.location || "Odisha, India").trim(),
    shortDesc: String(input.shortDesc || input.description || "").trim(),
    imageUrl: rawGallery[0] || "",
    images: rawGallery,
    operatingHours: input.operatingHours || defaultHours,
    subCategories,
    fareRules,
    addOns: normalizeAddOns(input.addOns || []),
  };

  if (category === "park") {
    payload.pricing = input.pricing || {
      adult: price,
      child: Math.max(0, Math.round(price * 0.6)),
    };
    payload.capacityPerSlot = Number(input.capacityPerSlot) || 200;
    payload.rides = Array.isArray(input.rides) ? input.rides : [];
  } else if (category === "cinema") {
    payload.pricing = input.pricing || {
      adult: price,
      child: Math.max(0, Math.round(price * 0.75)),
    };
    payload.capacityPerSlot = Number(input.capacityPerSlot) || 150;
    payload.screenInfo = input.screenInfo || {
      format: "",
      language: "",
    };
    payload.seating = input.seating || { rows: 0, cols: 0, seats: [] };
  } else if (category === "temple") {
    payload.offerings =
      Array.isArray(input.offerings) && input.offerings.length > 0
        ? input.offerings
        : [
            {
              name: "General Darshan",
              price,
            },
          ];
    payload.darshanCapacity = Number(input.darshanCapacity) || 150;
  } else if (category === "event") {
    payload.eventDate = input.eventDate || "";
    payload.eventTime = input.eventTime || "";
    payload.eventDates = input.eventDate ? [input.eventDate] : input.eventDates || [
      new Date().toISOString().slice(0, 10),
    ];
    payload.seating = input.seating || {
      rows: 5,
      cols: 10,
      seats: Array.from({ length: 50 }, (_, index) => ({
        label: `S${index + 1}`,
        price,
      })),
    };
  }

  // Common additions for event/cinema if they share some time structure
  if (category === "cinema" && input.eventDate && input.eventTime) {
    payload.eventDate = input.eventDate;
    payload.eventTime = input.eventTime;
    payload.eventDates = [input.eventDate];
  }

  return payload;
}
