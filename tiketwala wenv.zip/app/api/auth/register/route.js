import { getDb } from "@/lib/mongodb";
import { createAuthToken } from "@/lib/auth";

/**
 * POST /api/auth/register
 * Register a new customer in the users collection.
 * Required fields: name, email, password
 * Optional: phone
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const name = String(body.name || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const password = body.password;
    const phone = body.phone || null;

    if (!name || !email || !password) {
      return Response.json(
        { success: false, error: "Name, email, and password are required" },
        { status: 400 },
      );
    }

    const db = await getDb();

    // Check if email already exists
    const existingUser = await db.collection("users").findOne({ email });
    if (existingUser) {
      return Response.json(
        { success: false, error: "A user with this email already exists" },
        { status: 409 },
      );
    }

    // Hash the password securely
    const bcryptModule = await import("bcryptjs");
    const bcrypt = bcryptModule.default || bcryptModule;
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const now = new Date().toISOString();

    // Insert new customer record
    const newUser = {
      name,
      email,
      passwordHash,
      phone,
      role: "customer", // Explicitly lock as customer
      location: {},
      createdAt: now,
      updatedAt: now,
    };

    const result = await db.collection("users").insertOne(newUser);

    if (result.acknowledged) {
      const insertedId = String(result.insertedId);
      const token = createAuthToken({
        userId: insertedId,
        email: newUser.email,
        role: "customer",
      });

      return Response.json({
        success: true,
        token,
        customer: {
          id: insertedId,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
        },
      });
    } else {
      throw new Error("Failed to insert user into database");
    }
  } catch (error) {
    console.error("Auth register error:", error);
    return Response.json(
      { success: false, error: "Registration failed" },
      { status: 500 },
    );
  }
}
