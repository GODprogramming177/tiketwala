import { getDb } from "@/lib/mongodb";
import { sendCustomerOtpEmail } from "@/lib/email";
import { sendMsg91Otp } from "@/lib/msg91";
import { generateOtp, getOtpExpiry, hashOtp } from "@/lib/otp";
import { isValidEmail } from "@/lib/schemas";

export async function POST(request) {
  try {
    const { email, name, phone, loginMethod } = await request.json();

    const isMobileLogin = loginMethod === "mobile" || (!!phone && !email);

    const db = await getDb();

    if (isMobileLogin) {
      const cleanPhone = String(phone || "").trim();
      const digitsOnly = cleanPhone.replace(/\D/g, "");
      if (digitsOnly.length < 10) {
        return Response.json(
          { success: false, error: "A valid 10-digit mobile number is required" },
          { status: 400 }
        );
      }

      // Check if user exists by phone
      const searchPhones = [cleanPhone];
      if (digitsOnly.length === 10) {
        searchPhones.push("91" + digitsOnly);
        searchPhones.push("+91" + digitsOnly);
        searchPhones.push(digitsOnly);
      } else if (digitsOnly.length > 10) {
        searchPhones.push(digitsOnly);
        searchPhones.push("+" + digitsOnly);
        if (digitsOnly.startsWith("91")) {
          searchPhones.push(digitsOnly.slice(2));
        }
      }

      const existingUser = await db.collection("users").findOne({
        phone: { $in: searchPhones }
      });

      if (existingUser && existingUser.role !== "customer") {
        return Response.json(
          {
            success: false,
            error: "Business and admin accounts cannot use customer booking OTP login",
          },
          { status: 403 }
        );
      }

      const isNewCustomer = !existingUser;
      const hasNewCustomerProfile =
        String(name || "").trim().length > 0 && isValidEmail(String(email || "").trim());

      if (isNewCustomer && !hasNewCustomerProfile) {
        return Response.json({
          success: true,
          isNewCustomer: true,
          otpSent: false,
          requiresProfile: true,
          message: "Profile details (name and email) required before sending OTP",
        });
      }

      // If new customer and profile is provided, check if email is already taken
      if (isNewCustomer && hasNewCustomerProfile) {
        const emailConflict = await db.collection("users").findOne({
          email: String(email).trim().toLowerCase()
        });
        if (emailConflict) {
          return Response.json(
            { success: false, error: "A user with this email address already exists. Please login using that email instead." },
            { status: 400 }
          );
        }
      }

      // Send SMS OTP via MSG91
      const smsResult = await sendMsg91Otp(digitsOnly);
      if (!smsResult.success) {
        return Response.json(
          { success: false, error: smsResult.error || "Unable to send SMS OTP right now" },
          { status: 500 }
        );
      }

      // Save OTP reference to database
      const now = new Date().toISOString();
      const otpDoc = {
        phone: digitsOnly,
        email: email ? String(email).trim().toLowerCase() : null,
        name: name ? String(name).trim() : null,
        reqId: smsResult.reqId, // store the MSG91 request ID
        purpose: "customer_auth_sms",
        expiresAt: getOtpExpiry(10),
        used: false,
        createdAt: now,
        updatedAt: now,
      };

      await db.collection("auth_otps").deleteMany({
        phone: digitsOnly,
        purpose: "customer_auth_sms",
      });
      await db.collection("auth_otps").insertOne(otpDoc);

      return Response.json({
        success: true,
        message: "OTP sent successfully via SMS",
        isNewCustomer,
        otpSent: true,
      });

    } else {
      // Email Login Flow
      const normalizedEmail = String(email || "")
        .trim()
        .toLowerCase();
      const normalizedName = String(name || "").trim();
      const normalizedPhone = String(phone || "").trim();

      if (!isValidEmail(normalizedEmail)) {
        return Response.json(
          { success: false, error: "A valid email address is required" },
          { status: 400 },
        );
      }

      const existingUser = await db
        .collection("users")
        .findOne({ email: normalizedEmail });

      if (existingUser && existingUser.role !== "customer") {
        return Response.json(
          {
            success: false,
            error:
              "Business and admin accounts cannot use customer booking OTP login",
          },
          { status: 403 },
        );
      }

      const isNewCustomer = !existingUser;
      const hasNewCustomerProfile =
        normalizedName.length > 0 && normalizedPhone.length > 0;

      if (isNewCustomer && !hasNewCustomerProfile) {
        return Response.json({
          success: true,
          isNewCustomer: true,
          otpSent: false,
          requiresProfile: true,
          message: "Profile details required before sending OTP",
        });
      }

      const otp = generateOtp();
      const now = new Date().toISOString();
      const otpDoc = {
        email: normalizedEmail,
        name: normalizedName,
        phone: normalizedPhone,
        otpHash: hashOtp(normalizedEmail, otp),
        purpose: "customer_auth",
        expiresAt: getOtpExpiry(10),
        used: false,
        attempts: 0,
        createdAt: now,
        updatedAt: now,
      };

      await db.collection("auth_otps").deleteMany({
        email: normalizedEmail,
        purpose: "customer_auth",
      });
      await db.collection("auth_otps").insertOne(otpDoc);

      const emailResult = await sendCustomerOtpEmail(normalizedEmail, otp);
      if (!emailResult.success) {
        await db.collection("auth_otps").deleteMany({
          email: normalizedEmail,
          purpose: "customer_auth",
        });
        return Response.json(
          { success: false, error: "Unable to send OTP email right now" },
          { status: 500 },
        );
      }

      return Response.json({
        success: true,
        message: "OTP sent successfully",
        isNewCustomer,
        otpSent: true,
      });
    }
  } catch (error) {
    console.error("Request OTP error:", error);
    return Response.json(
      { success: false, error: "Failed to send OTP" },
      { status: 500 },
    );
  }
}
