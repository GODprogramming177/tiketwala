import { getDb } from "@/lib/mongodb";
import { createAuthToken } from "@/lib/auth";
import { hashOtp, isOtpExpired } from "@/lib/otp";
import { isValidEmail } from "@/lib/schemas";
import { verifyMsg91Otp } from "@/lib/msg91";

export async function POST(request) {
  try {
    const { email, otp, name, phone, loginMethod } = await request.json();
    const normalizedOtp = String(otp || "").trim();
    const isMobileLogin = loginMethod === "mobile" || (!!phone && !email);

    const db = await getDb();

    if (isMobileLogin) {
      const cleanPhone = String(phone || "").trim();
      const digitsOnly = cleanPhone.replace(/\D/g, "");

      if (digitsOnly.length < 10 || !/^\d{4,6}$/.test(normalizedOtp)) {
        return Response.json(
          { success: false, error: "Valid mobile number and OTP are required" },
          { status: 400 }
        );
      }

      const otpEntry = await db
        .collection("auth_otps")
        .find({ phone: digitsOnly, purpose: "customer_auth_sms", used: false })
        .sort({ createdAt: -1 })
        .limit(1)
        .next();

      if (!otpEntry || isOtpExpired(otpEntry.expiresAt)) {
        return Response.json(
          { success: false, error: "OTP expired. Please request a new one." },
          { status: 410 },
        );
      }

      // Verify OTP via MSG91 Widget API
      const verifyResult = await verifyMsg91Otp(otpEntry.reqId, normalizedOtp);
      if (!verifyResult.success) {
        return Response.json(
          { success: false, error: verifyResult.error || "Incorrect OTP" },
          { status: 401 }
        );
      }

      // Update OTP status in DB
      await db.collection("auth_otps").updateOne(
        { _id: otpEntry._id },
        {
          $set: {
            used: true,
            verifiedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
        },
      );

      // Look up or register the user
      const searchPhones = [digitsOnly];
      if (digitsOnly.length === 10) {
        searchPhones.push("91" + digitsOnly);
        searchPhones.push("+91" + digitsOnly);
        searchPhones.push(digitsOnly);
      } else if (digitsOnly.length > 10) {
        searchPhones.push(digitsOnly);
        searchPhones.push("+" + digitsOnly);
        if (digitsOnly.startsWith("91")) {
          searchPhones.push(digitsOnly.slice(2));
        }
      }

      let user = await db.collection("users").findOne({
        phone: { $in: searchPhones }
      });

      if (user && user.role !== "customer") {
        return Response.json(
          {
            success: false,
            error: "Business and admin accounts cannot use customer booking OTP login",
          },
          { status: 403 },
        );
      }

      if (!user) {
        const now = new Date().toISOString();
        const userEmail = String(email || otpEntry.email || "").trim().toLowerCase();
        const userName = String(name || otpEntry.name || "").trim() || digitsOnly;

        user = {
          _id:
            "usr_" +
            Date.now().toString(36) +
            Math.random().toString(36).slice(2, 6),
          name: userName,
          email: userEmail,
          passwordHash: null,
          phone: digitsOnly,
          role: "customer",
          authMethod: "sms_otp",
          phoneVerifiedAt: now,
          emailVerifiedAt: userEmail ? now : null,
          location: {},
          createdAt: now,
          updatedAt: now,
        };
        await db.collection("users").insertOne(user);
      } else {
        await db.collection("users").updateOne(
          { _id: user._id },
          {
            $set: {
              authMethod: "sms_otp",
              phoneVerifiedAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
          },
        );
        user = await db.collection("users").findOne({ _id: user._id });
      }

      const token = createAuthToken({
        userId: user._id,
        email: user.email,
        role: "customer",
      });

      return Response.json({
        success: true,
        token,
        customer: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: "customer",
        },
      });

    } else {
      // Email Login Flow (Existing)
      const normalizedEmail = String(email || "").trim().toLowerCase();

      if (!isValidEmail(normalizedEmail) || !/^\d{6}$/.test(normalizedOtp)) {
        return Response.json(
          { success: false, error: "Valid email and 6-digit OTP are required" },
          { status: 400 },
        );
      }

      const otpEntry = await db
        .collection("auth_otps")
        .find({ email: normalizedEmail, purpose: "customer_auth", used: false })
        .sort({ createdAt: -1 })
        .limit(1)
        .next();

      if (!otpEntry || isOtpExpired(otpEntry.expiresAt)) {
        return Response.json(
          { success: false, error: "OTP expired. Please request a new one." },
          { status: 410 },
        );
      }

      const expectedHash = hashOtp(normalizedEmail, normalizedOtp);
      if (otpEntry.otpHash !== expectedHash) {
        await db.collection("auth_otps").updateOne(
          { _id: otpEntry._id },
          {
            $inc: { attempts: 1 },
            $set: { updatedAt: new Date().toISOString() },
          },
        );
        return Response.json(
          { success: false, error: "Incorrect OTP" },
          { status: 401 },
        );
      }

      await db.collection("auth_otps").updateOne(
        { _id: otpEntry._id },
        {
          $set: {
            used: true,
            verifiedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
        },
      );

      let user = await db.collection("users").findOne({ email: normalizedEmail });
      if (user && user.role !== "customer") {
        return Response.json(
          {
            success: false,
            error:
              "Business and admin accounts cannot use customer booking OTP login",
          },
          { status: 403 },
        );
      }

      if (!user) {
        const now = new Date().toISOString();
        user = {
          _id:
            "usr_" +
            Date.now().toString(36) +
            Math.random().toString(36).slice(2, 6),
          name:
            String(name || otpEntry.name || "").trim() ||
            normalizedEmail.split("@")[0],
          email: normalizedEmail,
          passwordHash: null,
          phone: String(phone || otpEntry.phone || "").trim() || null,
          role: "customer",
          authMethod: "email_otp",
          emailVerifiedAt: now,
          location: {},
          createdAt: now,
          updatedAt: now,
        };
        await db.collection("users").insertOne(user);
      } else {
        await db.collection("users").updateOne(
          { _id: user._id },
          {
            $set: {
              authMethod: "email_otp",
              emailVerifiedAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
          },
        );
        user = await db.collection("users").findOne({ _id: user._id });
      }

      const token = createAuthToken({
        userId: user._id,
        email: user.email,
        role: "customer",
      });

      return Response.json({
        success: true,
        token,
        customer: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: "customer",
        },
      });
    }
  } catch (error) {
    console.error("Verify OTP error:", error);
    return Response.json(
      { success: false, error: "Failed to verify OTP" },
      { status: 500 },
    );
  }
}
