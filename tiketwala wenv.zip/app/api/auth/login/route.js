import { getDb } from "@/lib/mongodb";
import { createAuthToken, normalizeRole, getDashboardPath } from "@/lib/auth";
import bcrypt from "bcryptjs";
import { authRateLimiter } from "@/lib/rateLimit";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * POST /api/auth/login
 * Authenticate any user (superadmin / owner / customer) against MongoDB.
 * Returns auth token, user info, businessIds (for owners), and dashboard path.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    // Rate limit auth attempts
    const limited = authRateLimiter(request);
    if (limited) return limited;

    const body = await request.json();
    const email = String(body.email || "").trim().toLowerCase();
    const password = body.password;

    if (!email || !password) {
      return Response.json(
        { success: false, error: "Email and password are required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const user = await db.collection("users").findOne({ email });

    if (!user) {
      return Response.json(
        { success: false, error: "Invalid email or password" },
        { status: 401 },
      );
    }

    // Block disabled / inactive accounts
    if (user.active === false || user.disabled === true) {
      return Response.json(
        { success: false, error: "Your account has been deactivated. Please contact support." },
        { status: 403 },
      );
    }

    if (!user.passwordHash) {
      return Response.json(
        { success: false, error: "Invalid email or password" },
        { status: 401 },
      );
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);

    if (!isMatch) {
      return Response.json(
        { success: false, error: "Invalid email or password" },
        { status: 401 },
      );
    }

    // Fetch business scope for owner and worker roles.
    let businessIds = [];
    if (user.role === "owner") {
      const businesses = await db
        .collection("businesses")
        .find({
          $or: [{ ownerIds: user._id }, { ownerEmail: user.email }],
        })
        .project({ _id: 1 })
        .toArray();
      businessIds = businesses.map((b) => String(b._id));
    } else if (user.role === "worker") {
      const rawIds = user.businessId
        ? [user.businessId]
        : Array.isArray(user.businessIds)
          ? user.businessIds
          : [];
      businessIds = rawIds.map((id) => String(id));

      if (businessIds.length > 0) {
        const activeBusiness = await db
          .collection("businesses")
          .findOne(
            { _id: businessIds[0] },
            { projection: { active: 1, workerLimit: 1 } },
          );
        if (activeBusiness?.active === false) {
          return Response.json(
            {
              success: false,
              error: "Your business is inactive. Please contact support.",
            },
            { status: 403 },
          );
        }
      }
    }

    const userId = String(user._id);
    const role = normalizeRole(user.role);
    const token = createAuthToken({
      userId,
      email: user.email,
      role,
    });

    // Include posPermissions for workers
    const posPermissions = user.role === "worker"
      ? (Array.isArray(user.posPermissions) ? user.posPermissions : ["pos", "scan"])
      : undefined;

    return Response.json({
      success: true,
      token,
      user: {
        id: userId,
        email: user.email,
        name: user.name,
        phone: user.phone || null,
        role,
        businessIds,
        businessId: user.businessId ? String(user.businessId) : businessIds[0] || null,
        dashboardPath: getDashboardPath(role),
        ...(posPermissions ? { posPermissions } : {}),
      },
      // Keep legacy "admin" key for backward compat with AdminAuthContext
      admin: {
        id: userId,
        email: user.email,
        name: user.name,
        role,
        businessIds,
        businessId: user.businessId ? String(user.businessId) : businessIds[0] || null,
        ...(posPermissions ? { posPermissions } : {}),
      },
    });
  } catch (error) {
    console.error("Auth login error:", error);
    return Response.json(
      { success: false, error: "Authentication failed" },
      { status: 500 },
    );
  }
}
