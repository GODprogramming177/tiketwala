import { getDb } from "@/lib/mongodb";
import { requireRole, canAccessBusiness } from "@/lib/rbac";

const MIN_LEAD_HOURS = 48;

export async function GET(request) {
  try {
    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const businessId = searchParams.get("businessId");
    const db = await getDb();
    const filter = {};

    if (auth.user.role === "owner") {
      filter.businessId = { $in: auth.businessIds || [] };
    }

    if (businessId) {
      if (
        auth.user.role === "owner" &&
        !canAccessBusiness(auth, businessId)
      ) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
      filter.businessId = businessId;
    }

    const requests = await db
      .collection("bulkBookings")
      .find(filter)
      .sort({ createdAt: -1 })
      .limit(100)
      .toArray();

    return Response.json({ success: true, requests });
  } catch (error) {
    console.error("Bulk booking GET error:", error);
    return Response.json(
      { success: false, error: "Failed to fetch bulk bookings" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      listingId,
      customerName,
      customerEmail,
      customerPhone,
      visitDate,
      quantity,
      notes,
    } = body;

    const safeQuantity = Number(quantity);
    if (
      !listingId ||
      !customerName ||
      !customerEmail ||
      !visitDate ||
      !Number.isFinite(safeQuantity) ||
      safeQuantity < 10
    ) {
      return Response.json(
        {
          success: false,
          error:
            "listingId, customerName, customerEmail, visitDate, and quantity (minimum 10) are required",
        },
        { status: 400 },
      );
    }

    const requestedDate = new Date(`${visitDate}T00:00:00+05:30`);
    const minAllowedDate = new Date(Date.now() + MIN_LEAD_HOURS * 60 * 60 * 1000);
    if (Number.isNaN(requestedDate.getTime()) || requestedDate < minAllowedDate) {
      return Response.json(
        {
          success: false,
          error: "Bulk bookings must be requested at least 48 hours in advance",
        },
        { status: 400 },
      );
    }

    const db = await getDb();
    const listing = await db.collection("properties").findOne({ _id: listingId });
    if (!listing) {
      return Response.json(
        { success: false, error: "Listing not found" },
        { status: 404 },
      );
    }

    const now = new Date().toISOString();
    const bulkRequest = {
      _id:
        "bulk_" +
        Date.now().toString(36) +
        Math.random().toString(36).slice(2, 6),
      listingId,
      businessId: listing.businessId,
      listingName: listing.name,
      listingType: listing.category,
      customerName: String(customerName).trim(),
      customerEmail: String(customerEmail).trim().toLowerCase(),
      customerPhone: String(customerPhone || "").trim(),
      visitDate,
      quantity: Math.floor(safeQuantity),
      notes: String(notes || "").trim(),
      status: "pending",
      createdAt: now,
      updatedAt: now,
    };

    await db.collection("bulkBookings").insertOne(bulkRequest);

    return Response.json(
      { success: true, request: bulkRequest },
      { status: 201 },
    );
  } catch (error) {
    console.error("Bulk booking POST error:", error);
    return Response.json(
      { success: false, error: "Failed to submit bulk booking request" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { requestId, status } = await request.json();
    if (!requestId || !status) {
      return Response.json(
        { success: false, error: "requestId and status are required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const existing = await db
      .collection("bulkBookings")
      .findOne({ _id: requestId });

    if (!existing) {
      return Response.json(
        { success: false, error: "Request not found" },
        { status: 404 },
      );
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, existing.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    await db.collection("bulkBookings").updateOne(
      { _id: requestId },
      {
        $set: {
          status,
          updatedAt: new Date().toISOString(),
        },
      },
    );

    return Response.json({ success: true });
  } catch (error) {
    console.error("Bulk booking PATCH error:", error);
    return Response.json(
      { success: false, error: "Failed to update bulk booking request" },
      { status: 500 },
    );
  }
}
