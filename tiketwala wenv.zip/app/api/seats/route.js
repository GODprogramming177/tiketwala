import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";

const LOCK_DURATION_MS = 10 * 60 * 1000; // 10 minutes

/**
 * POST /api/seats/lock
 * Lock seats for a booking (prevents double booking during payment)
 * Body: { propertyId, slot, seats: ["A1", "A2", ...] }
 */
export async function POST(request) {
  try {
    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { propertyId, slot, seats } = body;

    if (!propertyId || !slot || !Array.isArray(seats) || seats.length === 0) {
      return Response.json(
        { error: "propertyId, slot, and seats array are required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const property = await db
      .collection("properties")
      .findOne({ _id: propertyId });

    if (!property) {
      return Response.json({ error: "Property not found" }, { status: 404 });
    }

    const now = new Date();
    const lockedUntil = new Date(now.getTime() + LOCK_DURATION_MS);

    // Check if any seats are already locked or booked
    const existingSeats = await db
      .collection("seats")
      .find({
        propertyId,
        slot,
        seatId: { $in: seats },
      })
      .toArray();

    const unavailableSeats = existingSeats
      .filter((s) => {
        if (s.lockedUntil && new Date(s.lockedUntil) > now) {
          return true; // Still locked
        }
        if (s.status === "booked") {
          return true; // Already booked
        }
        return false;
      })
      .map((s) => s.seatId);

    if (unavailableSeats.length > 0) {
      return Response.json(
        {
          error: "Some seats are unavailable",
          unavailableSeatIds: unavailableSeats,
        },
        { status: 409 },
      );
    }

    // Lock the seats (upsert)
    const lockOperations = seats.map((seatId) => ({
      updateOne: {
        filter: { propertyId, slot, seatId },
        update: {
          $set: {
            propertyId,
            slot,
            seatId,
            status: "locked",
            lockedBy: auth.user._id,
            lockedByEmail: auth.user.email,
            lockedUntil: lockedUntil.toISOString(),
            updatedAt: now.toISOString(),
          },
          $setOnInsert: {
            createdAt: now.toISOString(),
          },
        },
        upsert: true,
      },
    }));

    if (lockOperations.length > 0) {
      await db.collection("seats").bulkWrite(lockOperations);
    }

    return Response.json(
      {
        success: true,
        lockedSeats: seats,
        lockedUntil: lockedUntil.toISOString(),
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Seat lock error:", error);
    return Response.json({ error: "Failed to lock seats" }, { status: 500 });
  }
}

/**
 * POST /api/seats/unlock
 * Unlock seats (when user cancels booking or payment fails)
 * Body: { propertyId, slot, seats: ["A1", "A2", ...] }
 */
export async function PUT(request) {
  try {
    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { propertyId, slot, seats } = body;

    if (!propertyId || !slot || !Array.isArray(seats) || seats.length === 0) {
      return Response.json(
        { error: "propertyId, slot, and seats array are required" },
        { status: 400 },
      );
    }

    const db = await getDb();

    // Unlock only seats locked by this user
    await db.collection("seats").updateMany(
      {
        propertyId,
        slot,
        seatId: { $in: seats },
        lockedBy: auth.user._id,
        status: "locked",
      },
      {
        $set: {
          status: "available",
          lockedBy: null,
          lockedByEmail: null,
          lockedUntil: null,
          updatedAt: new Date().toISOString(),
        },
      },
    );

    return Response.json({
      success: true,
      unlockedSeats: seats,
    });
  } catch (error) {
    console.error("Seat unlock error:", error);
    return Response.json({ error: "Failed to unlock seats" }, { status: 500 });
  }
}

/**
 * GET /api/seats/status?propertyId=<id>&slot=<slot>
 * Get seat status for a property and specific slot
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const propertyId = searchParams.get("propertyId");
    const slot = searchParams.get("slot");

    if (!propertyId || !slot) {
      return Response.json(
        { error: "propertyId and slot query params are required" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const now = new Date();

    // Clean up expired locks
    await db.collection("seats").updateMany(
      {
        propertyId,
        slot,
        status: "locked",
        lockedUntil: { $lt: now.toISOString() },
      },
      {
        $set: {
          status: "available",
          lockedBy: null,
          lockedByEmail: null,
          lockedUntil: null,
          updatedAt: now.toISOString(),
        },
      },
    );

    // Get all seats
    const seats = await db.collection("seats").find({ propertyId, slot }).toArray();

    return Response.json({
      propertyId,
      slot,
      seats: seats.map((s) => ({
        seatId: s.seatId,
        status: s.status,
        lockedUntil: s.lockedUntil,
      })),
    });
  } catch (error) {
    console.error("Seat status error:", error);
    return Response.json(
      { error: "Failed to fetch seat status" },
      { status: 500 },
    );
  }
}
