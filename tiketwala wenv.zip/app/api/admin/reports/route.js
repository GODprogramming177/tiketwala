import { getDb } from "@/lib/mongodb";
import { requireRole, canAccessBusiness } from "@/lib/rbac";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * GET /api/admin/reports
 * Sales reports for Admin (own business) and Super Admin (all businesses).
 *
 * Query params:
 * - startDate (ISO date, e.g. 2026-01-01)
 * - endDate (ISO date, e.g. 2026-04-10)
 * - businessId (optional, for super admin filtering)
 * - listingId (optional, specific listing)
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const startDate = searchParams.get("startDate") || "2020-01-01";
    const endDate = searchParams.get("endDate") || new Date().toISOString().slice(0, 10);
    const startTime = searchParams.get("startTime") || "";
    const endTime = searchParams.get("endTime") || "";
    const businessIdParam = searchParams.get("businessId");
    const listingId = searchParams.get("listingId");

    const db = await getDb();
    const filter = {
      status: { $in: ["confirmed", "completed"] },
    };

    // Date range filter
    filter.bookingDateIso = {
      $gte: startDate,
      $lte: endDate,
    };

    // Scope by role
    if (auth.user.role === "owner") {
      if (!Array.isArray(auth.businessIds) || auth.businessIds.length === 0) {
        return Response.json({
          success: true,
          summary: { totalBookings: 0, totalRevenue: 0, platformFee: 0, businessAmount: 0 },
          bookings: [],
          dailyBreakdown: [],
          listingBreakdown: [],
        });
      }
      filter.businessId = { $in: auth.businessIds };
    } else if (auth.user.role === "superadmin" || auth.user.role === "super_admin") {
      // Superadmin can filter by specific business
      if (businessIdParam) {
        filter.businessId = businessIdParam;
      }
    }

    if (listingId) {
      filter.propertyId = listingId;
    }

    let bookings = await db
      .collection("bookings")
      .find(filter)
      .sort({ createdAt: -1 })
      .toArray();

    if (startTime || endTime) {
      bookings = bookings.filter((booking) =>
        matchesTimeFilter(booking.createdAt || booking.slot, startTime, endTime),
      );
    }

    const businessIds = [
      ...new Set(bookings.map((booking) => booking.businessId).filter(Boolean)),
    ];
    const businesses = businessIds.length
      ? await db
          .collection("businesses")
          .find({ _id: { $in: businessIds } })
          .project({ _id: 1, name: 1 })
          .toArray()
      : [];
    const businessNameMap = Object.fromEntries(
      businesses.map((business) => [business._id, business.name]),
    );

    // Compute summary
    const totalRevenue = bookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);
    const platformFee = bookings.reduce((sum, b) => sum + (b.platformFee || 0), 0);
    const businessAmount = bookings.reduce((sum, b) => sum + (b.businessAmount || 0), 0);
    const totalQuantity = bookings.reduce((sum, b) => sum + (b.quantity || 1), 0);

    // Daily breakdown
    const dailyMap = {};
    for (const b of bookings) {
      const day = b.bookingDateIso || "unknown";
      if (!dailyMap[day]) {
        dailyMap[day] = { date: day, bookings: 0, revenue: 0, visitors: 0 };
      }
      dailyMap[day].bookings++;
      dailyMap[day].revenue += b.totalAmount || 0;
      dailyMap[day].visitors += b.quantity || 1;
    }
    const dailyBreakdown = Object.values(dailyMap).sort((a, b) =>
      b.date.localeCompare(a.date),
    );

    // Listing breakdown
    const listingMap = {};
    for (const b of bookings) {
      const key = b.propertyId || "unknown";
      if (!listingMap[key]) {
        listingMap[key] = {
          listingId: key,
          listingName: b.listingName || "Unknown",
          listingType: b.listingType || "",
          bookings: 0,
          revenue: 0,
          visitors: 0,
        };
      }
      listingMap[key].bookings++;
      listingMap[key].revenue += b.totalAmount || 0;
      listingMap[key].visitors += b.quantity || 1;
    }
    const listingBreakdown = Object.values(listingMap).sort(
      (a, b) => b.revenue - a.revenue,
    );

    // Park/business breakdown for super admin
    let businessBreakdown = [];
    if (auth.user.role === "superadmin" || auth.user.role === "super_admin") {
      const bizMap = {};
      for (const b of bookings) {
        const key = b.businessId || "unknown";
        if (!bizMap[key]) {
          bizMap[key] = {
            businessId: key,
            bookings: 0,
            revenue: 0,
            platformFee: 0,
            businessAmount: 0,
            visitors: 0,
          };
        }
        bizMap[key].bookings++;
        bizMap[key].revenue += b.totalAmount || 0;
        bizMap[key].platformFee += b.platformFee || 0;
        bizMap[key].businessAmount += b.businessAmount || 0;
        bizMap[key].visitors += b.quantity || 1;
      }

      // Enrich with business names
      const bizIds = Object.keys(bizMap).filter((id) => id !== "unknown");
      if (bizIds.length > 0) {
        const businesses = await db
          .collection("businesses")
          .find({ _id: { $in: bizIds } })
          .project({ _id: 1, name: 1 })
          .toArray();
        const nameMap = Object.fromEntries(businesses.map((b) => [b._id, b.name]));
        for (const entry of Object.values(bizMap)) {
          entry.businessName = nameMap[entry.businessId] || "Unknown Business";
        }
      }
      businessBreakdown = Object.values(bizMap).sort((a, b) => b.revenue - a.revenue);
    }

    return Response.json({
      success: true,
      summary: {
        totalBookings: bookings.length,
        totalRevenue,
        platformFee,
        businessAmount,
        totalQuantity,
        dateRange: { startDate, endDate },
      },
      bookings: bookings.map((b) => ({
        bookingId: b.bookingId,
        customerEmail: b.customerEmail,
        customerName: b.customerName,
        bookedByName: b.bookedByName || "",
        listingName: b.listingName,
        listingType: b.listingType,
        businessId: b.businessId,
        businessName: businessNameMap[b.businessId] || "",
        slot: b.slot,
        date: b.date,
        bookingDateIso: b.bookingDateIso,
        quantity: b.quantity,
        totalAmount: b.totalAmount,
        platformFee: b.platformFee,
        businessAmount: b.businessAmount,
        status: b.status,
        ticketStatus: b.ticketStatus || "valid",
        channel: b.channel || "online",
        createdAt: b.createdAt,
      })),
      dailyBreakdown,
      listingBreakdown,
      businessBreakdown,
    });
  } catch (error) {
    console.error("Reports GET error:", error);
    return Response.json(
      { success: false, error: "Failed to generate report" },
      { status: 500 },
    );
  }
}

function matchesTimeFilter(input, startTime, endTime) {
  const minutes = getIndiaMinutes(input);
  if (minutes === null) {
    return true;
  }

  const startMinutes = parseTimeToMinutes(startTime);
  const endMinutes = parseTimeToMinutes(endTime);

  if (startMinutes !== null && minutes < startMinutes) {
    return false;
  }

  if (endMinutes !== null && minutes > endMinutes) {
    return false;
  }

  return true;
}

function getIndiaMinutes(input) {
  const date = new Date(input);
  if (Number.isNaN(date.getTime())) {
    return null;
  }

  const formatter = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
  const parts = formatter.formatToParts(date);
  const hour = Number(parts.find((part) => part.type === "hour")?.value);
  const minute = Number(parts.find((part) => part.type === "minute")?.value);

  if (!Number.isFinite(hour) || !Number.isFinite(minute)) {
    return null;
  }

  return hour * 60 + minute;
}

function parseTimeToMinutes(value) {
  if (!value || !/^\d{2}:\d{2}$/.test(value)) {
    return null;
  }

  const [hours, minutes] = value.split(":").map(Number);
  return hours * 60 + minutes;
}
