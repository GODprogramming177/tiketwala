import { getDb } from "@/lib/mongodb";
import { requireRole, canAccessBusiness } from "@/lib/rbac";
import { enforceApiAccess } from "@/lib/apiAccess";

export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const businessId = searchParams.get("businessId");
    const db = await getDb();

    let businessFilter = {};
    if (auth.user.role === "owner") {
      businessFilter = { _id: { $in: auth.businessIds || [] } };
    }
    if (businessId) {
      if (
        auth.user.role === "owner" &&
        !canAccessBusiness(auth, businessId)
      ) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
      businessFilter = { _id: businessId };
    }

    const businesses = await db
      .collection("businesses")
      .find(businessFilter)
      .project({ _id: 1, name: 1, workerLimit: 1 })
      .toArray();
    const businessIds = businesses.map((business) => business._id);

    const workers = businessIds.length
      ? await db
          .collection("users")
          .find({ role: "worker", businessId: { $in: businessIds } })
          .project({ passwordHash: 0 })
          .sort({ createdAt: -1 })
          .toArray()
      : [];

    const businessMap = Object.fromEntries(
      businesses.map((business) => [business._id, business]),
    );
    const activeCounts = workers.reduce((acc, worker) => {
      if (worker.active === false) {
        return acc;
      }
      acc[worker.businessId] = (acc[worker.businessId] || 0) + 1;
      return acc;
    }, {});

    const workersWithBusiness = workers.map((worker) => ({
      ...worker,
      businessName: businessMap[worker.businessId]?.name || "",
      workerLimit: businessMap[worker.businessId]?.workerLimit || 2,
    }));

    return Response.json({
      workers: workersWithBusiness,
      businesses: businesses.map((business) => ({
        ...business,
        currentWorkers: activeCounts[business._id] || 0,
      })),
    });
  } catch (error) {
    console.error("Workers GET error:", error);
    return Response.json(
      { error: "Failed to fetch workers" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner"]);
    if (auth.error) {
      return auth.error;
    }

    const { name, email, password, phone, businessId, posPermissions } = await request.json();

    if (!name || !email || !password || !businessId) {
      return Response.json(
        { error: "name, email, password, and businessId are required" },
        { status: 400 },
      );
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const db = await getDb();
    const business = await db
      .collection("businesses")
      .findOne({ _id: businessId });
    if (!business) {
      return Response.json({ error: "Business not found" }, { status: 404 });
    }

    const existingUser = await db.collection("users").findOne({ email });
    if (existingUser) {
      return Response.json(
        { error: "A user with this email already exists" },
        { status: 409 },
      );
    }

    const workerLimit = Number(business.workerLimit) > 0 ? Number(business.workerLimit) : 2;
    // Only count ACTIVE workers toward limit
    const currentCount = await db
      .collection("users")
      .countDocuments({ role: "worker", businessId, active: { $ne: false } });

    if (currentCount >= workerLimit) {
      return Response.json(
        { error: `Worker limit reached for this admin (${workerLimit})` },
        { status: 403 },
      );
    }

    // Validate posPermissions
    const validPermissions = ["pos", "scan"];
    const safePosPermissions = Array.isArray(posPermissions)
      ? posPermissions.filter((p) => validPermissions.includes(p))
      : ["pos", "scan"]; // Default: both

    const bcrypt = await import("bcryptjs");
    const passwordHash = await bcrypt.hash(password, 10);
    const now = new Date().toISOString();
    const worker = {
      _id:
        "wrk_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name,
      email,
      passwordHash,
      phone: phone || null,
      role: "worker",
      businessId,
      businessIds: [businessId],
      active: true,
      posPermissions: safePosPermissions,
      assignedBy: auth.user._id,
      createdAt: now,
      updatedAt: now,
    };

    await db.collection("users").insertOne(worker);

    return Response.json(
      {
        worker: {
          id: worker._id,
          name: worker.name,
          email: worker.email,
          role: worker.role,
          businessId,
          posPermissions: safePosPermissions,
        },
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Workers POST error:", error);
    return Response.json(
      { error: "Failed to create worker" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { userId, password, posPermissions, ...updates } = await request.json();
    if (!userId) {
      return Response.json({ error: "userId is required" }, { status: 400 });
    }

    const db = await getDb();
    const existing = await db.collection("users").findOne({ _id: userId });
    if (!existing || existing.role !== "worker") {
      return Response.json({ error: "Worker not found" }, { status: 404 });
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, existing.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    if (updates.active === true && existing.active === false) {
      const business = await db
        .collection("businesses")
        .findOne({ _id: existing.businessId });
      const workerLimit =
        Number(business?.workerLimit) > 0 ? Number(business.workerLimit) : 2;
      const currentCount = await db.collection("users").countDocuments({
        role: "worker",
        businessId: existing.businessId,
        active: { $ne: false },
      });

      if (currentCount >= workerLimit) {
        return Response.json(
          {
            error: `Worker limit reached for this admin (${workerLimit}). Deactivate another worker before reactivating this account.`,
          },
          { status: 403 },
        );
      }
    }

    const nextUpdates = {
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    delete nextUpdates._id;
    delete nextUpdates.role;
    delete nextUpdates.businessId;
    delete nextUpdates.passwordHash;

    // Handle posPermissions update
    if (Array.isArray(posPermissions)) {
      const validPermissions = ["pos", "scan"];
      nextUpdates.posPermissions = posPermissions.filter((p) =>
        validPermissions.includes(p),
      );
    }

    if (password) {
      const bcrypt = await import("bcryptjs");
      nextUpdates.passwordHash = await bcrypt.hash(password, 10);
    }

    await db.collection("users").updateOne(
      { _id: userId },
      { $set: nextUpdates },
    );

    return Response.json({ success: true });
  } catch (error) {
    console.error("Workers PATCH error:", error);
    return Response.json(
      { error: "Failed to update worker" },
      { status: 500 },
    );
  }
}

/**
 * DELETE /api/admin/workers?userId=xxx
 * Superadmin-only. Permanently deletes a worker and sends notification email.
 * For owners: use PATCH with { active: false } to deactivate instead.
 */
export async function DELETE(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    if (!userId) {
      return Response.json({ error: "userId is required" }, { status: 400 });
    }

    const db = await getDb();
    const existing = await db.collection("users").findOne({ _id: userId });
    if (!existing || existing.role !== "worker") {
      return Response.json({ error: "Worker not found" }, { status: 404 });
    }

    // Send notification email to the business owner
    try {
      const business = await db
        .collection("businesses")
        .findOne({ _id: existing.businessId });
      const recipients = [
        business?.ownerEmail,
        business?.contact?.email,
      ].filter(Boolean);
      if (recipients.length > 0) {
        const { sendWorkerDeletionNotification } = await import("@/lib/email");
        await sendWorkerDeletionNotification(recipients, {
          workerName: existing.name,
          workerEmail: existing.email,
          businessName: business.name,
          deletedBy: auth.user.name || auth.user.email,
        });
      }
    } catch (emailErr) {
      console.error("Failed to send deletion notification:", emailErr);
      // Proceed with deletion even if email fails
    }

    await db.collection("users").deleteOne({ _id: userId });
    return Response.json({ success: true });
  } catch (error) {
    console.error("Workers DELETE error:", error);
    return Response.json(
      { error: "Failed to delete worker" },
      { status: 500 },
    );
  }
}
