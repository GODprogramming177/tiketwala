import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";
import {
  getBusinessAllowedTypes,
  getBusinessListingLimit,
  slugifyName,
} from "@/lib/listingUtils";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * POST /api/admin/register
 * Superadmin-only endpoint to create an owner/admin and the controlled business.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const {
      name,
      email,
      password,
      phone,
      businessName,
      city,
      state,
      gstin,
      pan,
      listingLimit,
      workerLimit,
      allowedListingTypes,
    } = body;

    if (!name || !email || !password || !businessName || !city || !state) {
      return Response.json(
        {
          success: false,
          error:
            "Name, email, password, business name, city, and state are required",
        },
        { status: 400 },
      );
    }

    // PAN validation — mandatory, strict format
    const panValue = String(pan || "").trim().toUpperCase();
    const PAN_REGEX = /^[A-Z]{3}[PCFHATBLJG][A-Z]\d{4}[A-Z]$/;
    if (!panValue || !PAN_REGEX.test(panValue)) {
      return Response.json(
        {
          success: false,
          error: "Valid PAN is required. Format: 10 characters (e.g., ABCPD1234E). 4th character must be a valid entity type.",
        },
        { status: 400 },
      );
    }

    const normalizedAllowedTypes = getBusinessAllowedTypes({
      allowedListingTypes,
    });

    if (normalizedAllowedTypes.length === 0) {
      return Response.json(
        {
          success: false,
          error: "Select at least one listing type for this admin",
        },
        { status: 400 },
      );
    }

    const db = await getDb();

    const existingUser = await db.collection("users").findOne({ email });
    if (existingUser) {
      return Response.json(
        { success: false, error: "A user with this email already exists" },
        { status: 409 },
      );
    }

    const businessSlug = slugifyName(
      `${businessName}-${city}-${state}`.slice(0, 120),
    );
    const existingBusiness = await db
      .collection("businesses")
      .findOne({ slug: businessSlug });
    if (existingBusiness) {
      return Response.json(
        {
          success: false,
          error: "A business with similar details already exists",
        },
        { status: 409 },
      );
    }

    const bcrypt = await import("bcryptjs");
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const now = new Date().toISOString();
    const userId =
      "usr_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const businessId =
      "biz_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

    const newUser = {
      _id: userId,
      name,
      email,
      passwordHash,
      phone: phone || null,
      role: "owner",
      location: {
        city,
        state,
      },
      createdBy: auth.user._id,
      pan: panValue,
      createdAt: now,
      updatedAt: now,
    };

    const business = {
      _id: businessId,
      name: businessName,
      slug: businessSlug,
      type: normalizedAllowedTypes[0],
      ownerIds: [userId],
      ownerName: name,
      ownerEmail: email,
      location: {
        city,
        state,
      },
      contact: {
        email,
        phone: phone || "",
      },
      platformFeePercent: 5,
      razorpayLinked: false,
      active: true,
      pan: panValue,
      gstin: String(gstin || "").trim(),
      listingLimit: getBusinessListingLimit({ listingLimit }) || 10,
      workerLimit:
        Number(workerLimit) > 0 ? Math.floor(Number(workerLimit)) : 2,
      allowedListingTypes: normalizedAllowedTypes,
      createdAt: now,
      updatedAt: now,
    };

    await db.collection("users").insertOne(newUser);
    await db.collection("businesses").insertOne(business);

    return Response.json({
      success: true,
      user: {
        id: userId,
        name,
        email,
        role: "owner",
        phone: phone || null,
      },
      business: {
        id: business._id,
        name: business.name,
        gstin: business.gstin,
        listingLimit: business.listingLimit,
        workerLimit: business.workerLimit,
        allowedListingTypes: business.allowedListingTypes,
      },
    });
  } catch (error) {
    console.error("Admin register error:", error);
    return Response.json(
      { success: false, error: "Failed to create admin account" },
      { status: 500 },
    );
  }
}
