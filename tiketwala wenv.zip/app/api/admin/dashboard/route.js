import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";

/**
 * GET /api/admin/dashboard
 * Fetch aggregated statistics and recent listings for the dashboard.
 * Supports multi-tenant scoping:
 *   - ownerId: returns data only for the owner's businesses
 *   - role=superadmin: returns platform-wide stats
 *   - No ownerId + no superadmin: returns basic stats
 */
export async function GET(request) {
  try {
    const auth = await requireRole(request, ["owner", "superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const requestedOwnerId = searchParams.get("ownerId");

    const db = await getDb();
    const isSuperAdmin = auth.user.role === "superadmin";

    const ownerId = isSuperAdmin ? requestedOwnerId : auth.user._id;

    const businessIds = ownerId ? await getBusinessIds(db, ownerId) : null;
    // For owners, scope to their businesses; if no businesses found, return empty
    const propFilter = businessIds
      ? { businessId: { $in: businessIds } }
      : ownerId
        ? { businessId: "__none__" }
        : {};
    const bookingFilter = businessIds
      ? { businessId: { $in: businessIds } }
      : ownerId
        ? { businessId: "__none__" }
        : {};

    const [properties, bookings, totalOrders, bulkRequests] = await Promise.all([
      db.collection("properties").find(propFilter).toArray(),
      db
        .collection("bookings")
        .find(bookingFilter)
        .sort({ createdAt: -1 })
        .limit(50)
        .toArray(),
      db
        .collection("orders")
        .countDocuments(
          businessIds ? { businessId: { $in: businessIds } } : {},
        ),
      db
        .collection("bulkBookings")
        .find(
          businessIds ? { businessId: { $in: businessIds } } : {},
        )
        .sort({ createdAt: -1 })
        .limit(20)
        .toArray(),
    ]);

    const stats = {
      totalListings: properties.length,
      temples: properties.filter((p) => p.category === "temple").length,
      parks: properties.filter((p) => p.category === "park").length,
      events: properties.filter((p) => p.category === "event").length,
      cinemas: properties.filter((p) => p.category === "cinema").length,
      totalBookings: bookings.length,
      totalOrders,
      bulkBookingRequests: bulkRequests.length,
      totalRevenue: bookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0),
      platformRevenue: bookings.reduce(
        (sum, b) => sum + (b.platformFee || 0),
        0,
      ),
      businessRevenue: bookings.reduce(
        (sum, b) => sum + (b.businessAmount || 0),
        0,
      ),
    };

    // Superadmin gets additional platform-wide metrics
    if (isSuperAdmin) {
      const [totalUsers, totalBusinesses, pendingPayouts] = await Promise.all([
        db.collection("users").countDocuments({}),
        db.collection("businesses").countDocuments({}),
        db.collection("payouts").countDocuments({ status: "pending" }),
      ]);
      stats.totalUsers = totalUsers;
      stats.totalBusinesses = totalBusinesses;
      stats.pendingPayouts = pendingPayouts;
    }

    // Include allowedListingTypes for the UI
    let allowedListingTypes = ["park", "cinema", "event", "temple"]; 
    if (!isSuperAdmin && businessIds && businessIds.length > 0) {
      const businesses = await db.collection("businesses").find({ _id: { $in: businessIds } }).toArray();
      const types = new Set();
      businesses.forEach(b => {
        if (Array.isArray(b.allowedListingTypes)) {
          b.allowedListingTypes.forEach(t => types.add(t));
        }
      });
      if (types.size > 0) {
        allowedListingTypes = Array.from(types);
      }
    }

    return Response.json({
      stats,
      allowedListingTypes,
      listings: properties,
      recentBookings: bookings.slice(0, 10),
      bulkRequests,
    });
  } catch (error) {
    console.error("Dashboard API error:", error);
    return Response.json(
      { error: "Failed to fetch dashboard data" },
      { status: 500 },
    );
  }
}

// Helper: resolve businesses for an owner by ownerIds OR ownerEmail
async function getBusinessIds(db, ownerId) {
  // First get the user's email for ownerEmail lookup
  const user = await db.collection("users").findOne({ _id: ownerId });
  const orConditions = [{ ownerIds: ownerId }];
  if (user?.email) {
    orConditions.push({ ownerEmail: user.email });
  }
  const businesses = await db
    .collection("businesses")
    .find({ $or: orConditions })
    .toArray();
  return businesses.length > 0 ? businesses.map((b) => b._id) : null;
}
