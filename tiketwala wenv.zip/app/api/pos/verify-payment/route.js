import crypto from "crypto";
import { getDb } from "@/lib/mongodb";
import {
  requireWorker,
  calculateFees,
  canAccessBusiness,
  hasPosPermission,
} from "@/lib/rbac";
import { calculatePropertyPricing } from "@/lib/listingUtils";
import { enforceApiAccess } from "@/lib/apiAccess";

export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireWorker(request);
    if (auth.error) return auth.error;

    if (!hasPosPermission(auth.user, "pos")) {
      return Response.json(
        { success: false, error: "POS access denied" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return Response.json(
        { success: false, error: "Missing required payment details" },
        { status: 400 },
      );
    }

    const key_secret = process.env.RAZORPAY_KEY_SECRET;
    const data = razorpay_order_id + "|" + razorpay_payment_id;
    const generated_signature = crypto
      .createHmac("sha256", key_secret)
      .update(data)
      .digest("hex");

    if (generated_signature !== razorpay_signature) {
      return Response.json(
        { success: false, error: "Invalid payment signature" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const now = new Date().toISOString();

    const order = await db
      .collection("orders")
      .findOne({ rzpOrderId: razorpay_order_id, channel: "pos" });
    if (!order) {
      return Response.json(
        { success: false, error: "Order not found" },
        { status: 404 },
      );
    }

    if (
      auth.user.role !== "superadmin" &&
      !canAccessBusiness(auth, order.businessId)
    ) {
      return Response.json(
        { success: false, error: "Access denied" },
        { status: 403 },
      );
    }

    const existingBooking = await db
      .collection("bookings")
      .findOne({ rzpOrderId: razorpay_order_id });

    if (existingBooking) {
      if (order.status !== "paid") {
        await db.collection("orders").updateOne(
          { _id: order._id },
          {
            $set: {
              status: "paid",
              updatedAt: now,
              paymentId: razorpay_payment_id,
            },
          },
        );
      }
      return Response.json({ success: true, booking: existingBooking });
    }

    const property = await db
      .collection("properties")
      .findOne({ _id: order.propertyId });
    if (!property) {
      return Response.json(
        { success: false, error: "Listing not found for order" },
        { status: 404 },
      );
    }

    const business = await db
      .collection("businesses")
      .findOne({ _id: order.businessId });

    const safeQuantity = Number(order.quantity || 1);

    const pricing = calculatePropertyPricing(property, {
      quantity: safeQuantity,
      attendeeCounts: order.attendeeCounts || null,
      selectedSubCategory: order.selectedOffering || null,
      selectedOffering: order.selectedOffering || null,
      selectedAddOns: order.selectedAddOns || [],
      guestAges: order.guestAges || [],
    });

    if (pricing.totalAmount !== order.totalAmount) {
      return Response.json(
        {
          success: false,
          error: "Order amount mismatch",
        },
        { status: 409 },
      );
    }

    const slotFilterBase = { propertyId: order.propertyId, start: order.slot };
    const slotUpdateResult = await db.collection("slots").updateOne(
      {
        ...slotFilterBase,
        $expr: { $lte: [{ $add: ["$booked", safeQuantity] }, "$capacity"] },
      },
      { $inc: { booked: safeQuantity } },
    );

    if (!slotUpdateResult?.matchedCount) {
      return Response.json(
        {
          success: false,
          error:
            "Slot is no longer available. Payment is verified but booking could not be created.",
        },
        { status: 409 },
      );
    }

    const bookingId =
      "BKG" +
      Date.now().toString(36).toUpperCase() +
      Math.random().toString(36).substring(2, 5).toUpperCase();

    const slotDate = new Date(order.slot);
    const slotEndDate = order.slotEnd ? new Date(order.slotEnd) : null;
    const bookingDateSource = !isNaN(slotDate.getTime())
      ? slotDate
      : new Date();
    const validUntil =
      slotEndDate && !Number.isNaN(slotEndDate.getTime())
        ? slotEndDate
        : property.category === "event" && !isNaN(slotDate.getTime())
          ? slotDate
          : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    const fees = calculateFees(pricing.totalAmount, business);

    const booking = {
      _id: crypto.randomUUID().replace(/-/g, "").slice(0, 24),
      bookingId,
      customerId: null,
      customerEmail: order.customerEmail,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      propertyId: order.propertyId,
      businessId: order.businessId,
      listingName: order.listingName,
      location: property.address || property.location || "N/A",
      listingType:
        property.category?.charAt(0).toUpperCase() +
        property.category?.slice(1),
      slot: order.slot,
      quantity: safeQuantity,
      attendeeCounts: pricing.attendeeCounts,
      selectedSeats: [],
      selectedOffering: pricing.selectedOffering,
      selectedAddOns: pricing.selectedAddOns,
      unitPrice: pricing.unitPrice,
      baseAmount: pricing.baseAmount,
      addOnAmount: pricing.addOnAmount,
      totalAmount: pricing.totalAmount,
      platformFee: fees.platformFee,
      businessAmount: fees.businessAmount,
      paymentId: razorpay_payment_id,
      rzpOrderId: razorpay_order_id,
      status: "confirmed",
      channel: "pos",
      createdById: auth.user._id,
      createdByRole: auth.user.role,
      bookedByName: order.bookedByName || auth.user.name || auth.user.email,
      date: bookingDateSource.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      bookingDateIso: bookingDateSource.toISOString().slice(0, 10),
      slotEnd: order.slotEnd || null,
      guestAges: pricing.guestAges,
      fareBreakdown: pricing.fareBreakdown,
      validUntil: validUntil.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      validUntilIso: validUntil.toISOString(),
      createdAt: now,
      updatedAt: now,
      scanned: false,
      scanCount: 0,
      ticketStatus: "valid",
      scannedAt: null,
      scannedBy: null,
    };

    await db.collection("bookings").insertOne(booking);

    // Update order status and payment linkage
    await db.collection("orders").updateOne(
      { _id: order._id },
      {
        $set: {
          status: "paid",
          paymentId: razorpay_payment_id,
          updatedAt: now,
        },
      },
    );

    return Response.json({ success: true, booking }, { status: 201 });
  } catch (error) {
    console.error("POS Payment verify error:", error);
    return Response.json(
      { success: false, error: "POS Payment verification failed" },
      { status: 500 },
    );
  }
}
