import { getDb } from "@/lib/mongodb";
import Razorpay from "razorpay";
import {
  calculateFees,
  requireWorker,
  canAccessBusiness,
  hasPosPermission,
} from "@/lib/rbac";
import {
  calculatePropertyPricing,
  isAgePricingEnabled,
} from "@/lib/listingUtils";
import { enforceApiAccess } from "@/lib/apiAccess";

export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireWorker(request);
    if (auth.error) return auth.error;

    if (!hasPosPermission(auth.user, "pos")) {
      return Response.json({ error: "POS access denied" }, { status: 403 });
    }

    const body = await request.json();
    const {
      listingId,
      slot,
      quantity = 1,
      attendeeCounts = null,
      selectedAddOns = [],
      selectedOffering = null,
      customerName,
      customerEmail,
      customerPhone,
      guestAges = [],
    } = body;

    if (!listingId || !slot) {
      return Response.json(
        { error: "Listing ID and slot are required" },
        { status: 400 },
      );
    }

    const requestedAdultCount = Math.max(
      0,
      Math.floor(Number(attendeeCounts?.adult) || 0),
    );
    const requestedChildCount = Math.max(
      0,
      Math.floor(Number(attendeeCounts?.child) || 0),
    );
    const requestedTotalCount = requestedAdultCount + requestedChildCount;

    const requestedQuantity = Number(quantity);
    const safeQuantity =
      requestedTotalCount > 0 ? requestedTotalCount : requestedQuantity;
    if (!Number.isFinite(safeQuantity) || safeQuantity < 1) {
      return Response.json(
        { error: "quantity must be at least 1" },
        { status: 400 },
      );
    }

    const normalizedAttendeeCounts =
      requestedTotalCount > 0
        ? {
            adult: requestedAdultCount,
            child: requestedChildCount,
          }
        : null;

    const db = await getDb();
    const property = await db
      .collection("properties")
      .findOne({ _id: listingId });

    if (!property) {
      return Response.json({ error: "Listing not found" }, { status: 404 });
    }

    const hasCompleteGuestAges =
      Array.isArray(guestAges) && guestAges.length >= safeQuantity;
    if (
      isAgePricingEnabled(property) &&
      !hasCompleteGuestAges &&
      !normalizedAttendeeCounts
    ) {
      return Response.json(
        { error: "Guest ages are required for this listing" },
        { status: 400 },
      );
    }

    if (
      auth.user.role !== "superadmin" &&
      !canAccessBusiness(auth, property.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    const slotDoc = await db.collection("slots").findOne({
      propertyId: listingId,
      start: slot,
    });
    if (!slotDoc) {
      return Response.json({ error: "Slot not found" }, { status: 404 });
    }

    const business = await db
      .collection("businesses")
      .findOne({ _id: property.businessId });

    const pricing = calculatePropertyPricing(property, {
      quantity: safeQuantity,
      attendeeCounts: normalizedAttendeeCounts,
      selectedSubCategory: selectedOffering,
      selectedOffering,
      selectedAddOns,
      guestAges,
    });
    const totalAmount = pricing.totalAmount;

    if (totalAmount <= 0) {
      return Response.json({ error: "Invalid order amount" }, { status: 400 });
    }

    const totalAmountPaise = totalAmount * 100;
    const fees = calculateFees(totalAmount, business);

    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });

    const options = {
      amount: totalAmountPaise,
      currency: "INR",
      receipt: `pos_${Date.now()}_${listingId.substring(0, 5)}`,
    };

    const rzpOrder = await razorpay.orders.create(options);

    const safeEmail =
      String(customerEmail || "")
        .trim()
        .toLowerCase() || `pos-${Date.now()}@tiketwala.local`;

    const order = {
      _id: crypto.randomUUID().replace(/-/g, "").slice(0, 24),
      orderId: `POSORD${Date.now()}${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
      rzpOrderId: rzpOrder.id,
      propertyId: listingId,
      businessId: property.businessId,
      createdById: auth.user._id,
      createdByRole: auth.user.role,
      bookedByName: auth.user.name || auth.user.email,
      customerName: String(customerName || "").trim(),
      customerEmail: safeEmail,
      customerPhone: String(customerPhone || "").trim(),
      listingName: property.name,
      slot,
      slotEnd: slotDoc.end,
      quantity: safeQuantity,
      attendeeCounts: pricing.attendeeCounts,
      selectedSeats: [],
      selectedOffering: pricing.selectedOffering,
      guestAges: pricing.guestAges,
      fareBreakdown: pricing.fareBreakdown,
      selectedAddOns: pricing.selectedAddOns,
      unitPrice: pricing.unitPrice,
      baseAmount: pricing.baseAmount,
      addOnAmount: pricing.addOnAmount,
      totalAmount,
      platformFee: fees.platformFee,
      businessAmount: fees.businessAmount,
      currency: "INR",
      status: "created",
      channel: "pos",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.collection("orders").insertOne(order);

    return Response.json(order, { status: 201 });
  } catch (error) {
    console.error("POS Order create error:", error);
    return Response.json(
      { error: "Failed to create POS order" },
      { status: 500 },
    );
  }
}
