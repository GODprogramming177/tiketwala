import { getDb } from "@/lib/mongodb";
import { requireWorker, hasPosPermission } from "@/lib/rbac";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * GET /api/pos/bookings
 * Get POS bookings created by the logged-in worker, or bookings for assigned businesses.
 * Supports pagination via `page` and `limit` query params.
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireWorker(request);
    if (auth.error) return auth.error;

    if (auth.user.role === "worker" && !hasPosPermission(auth.user, "pos")) {
      return Response.json(
        { success: false, error: "POS access denied" },
        { status: 403 },
      );
    }

    const db = await getDb();

    // Default filter for workers: bookings created via POS channel by this worker
    const filter = { channel: "pos" };

    if (auth.user.role === "worker") {
      filter.createdById = auth.user._id;
    } else if (auth.user.role === "owner" && auth.businessIds?.length > 0) {
      filter.businessId = { $in: auth.businessIds };
    }

    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date");
    if (date) {
      filter.bookingDateIso = date;
    }

    // Pagination
    const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20", 10)));
    const skip = (page - 1) * limit;

    const [bookings, total] = await Promise.all([
      db
        .collection("bookings")
        .find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .toArray(),
      db.collection("bookings").countDocuments(filter),
    ]);

    return Response.json({
      success: true,
      bookings,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("POS Bookings GET error:", error);
    return Response.json(
      { success: false, error: "Failed to fetch POS bookings" },
      { status: 500 },
    );
  }
}
