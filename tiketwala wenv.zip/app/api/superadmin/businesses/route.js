import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";
import {
  getBusinessAllowedTypes,
  getBusinessListingLimit,
  normalizeCategory,
  slugifyName,
} from "@/lib/listingUtils";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * GET /api/superadmin/businesses
 * Superadmins get all businesses.
 * Owners receive only the businesses they are allowed to manage.
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin", "owner"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const city = searchParams.get("city");
    const type = normalizeCategory(searchParams.get("type"));
    const active = searchParams.get("active");

    const db = await getDb();
    const filter = {};

    if (city) {
      filter["location.city"] = { $regex: new RegExp(city, "i") };
    }

    if (type) {
      filter.allowedListingTypes = type;
    }

    if (active !== null && active !== undefined && active !== "") {
      filter.active = active === "true";
    }

    if (auth.user.role === "owner") {
      if (!Array.isArray(auth.businessIds) || auth.businessIds.length === 0) {
        return Response.json({ businesses: [] });
      }
      filter._id = { $in: auth.businessIds };
    }

    const businesses = await db
      .collection("businesses")
      .find(filter)
      .sort({ createdAt: -1 })
      .toArray();

    const ownerIds = [
      ...new Set(
        businesses.flatMap((business) =>
          Array.isArray(business.ownerIds) ? business.ownerIds : [],
        ),
      ),
    ];

    const owners = ownerIds.length
      ? await db
          .collection("users")
          .find({ _id: { $in: ownerIds } })
          .project({ _id: 1, name: 1, email: 1 })
          .toArray()
      : [];

    const ownerMap = Object.fromEntries(
      owners.map((owner) => [owner._id, owner]),
    );

    const enriched = await Promise.all(
      businesses.map(async (business) => {
        const [propertyCount, bookingStats] = await Promise.all([
          db.collection("properties").countDocuments({ businessId: business._id }),
          db
            .collection("bookings")
            .aggregate([
              { $match: { businessId: business._id, status: "confirmed" } },
              {
                $group: {
                  _id: null,
                  totalRevenue: { $sum: "$totalAmount" },
                  platformFee: { $sum: "$platformFee" },
                  bookingCount: { $sum: 1 },
                },
              },
            ])
            .toArray(),
        ]);

        const ownersForBusiness = (business.ownerIds || [])
          .map((ownerId) => ownerMap[ownerId])
          .filter(Boolean);
        const primaryOwner = ownersForBusiness[0] || null;
        const stats = bookingStats[0] || {
          totalRevenue: 0,
          platformFee: 0,
          bookingCount: 0,
        };

        return {
          ...business,
          ownerName:
            primaryOwner?.name ||
            business.ownerName ||
            business.contact?.name ||
            "",
          ownerEmail:
            primaryOwner?.email ||
            business.ownerEmail ||
            business.contact?.email ||
            "",
          allowedListingTypes: getBusinessAllowedTypes(business),
          listingLimit: getBusinessListingLimit(business),
          workerLimit:
            Number(business.workerLimit) > 0
              ? Number(business.workerLimit)
              : 2,
          propertyCount,
          ...stats,
        };
      }),
    );

    return Response.json({ businesses: enriched });
  } catch (error) {
    console.error("Superadmin businesses error:", error);
    return Response.json(
      { error: "Failed to fetch businesses" },
      { status: 500 },
    );
  }
}

/**
 * POST /api/superadmin/businesses
 * Create a new business and optionally create an owner user for it.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const {
      name,
      slug,
      type,
      ownerEmail,
      ownerName,
      location,
      contact,
      platformFeePercent,
      gstin,
      allowedListingTypes,
      listingLimit,
      workerLimit,
    } = body;

    if (!name || !ownerEmail) {
      return Response.json(
        { error: "name and ownerEmail are required" },
        { status: 400 },
      );
    }

    const allowedTypes = getBusinessAllowedTypes({
      allowedListingTypes,
    });
    const primaryType = normalizeCategory(type) || allowedTypes[0];
    const normalizedSlug = slugifyName(slug || name);

    if (!normalizedSlug) {
      return Response.json(
        { error: "A valid business slug could not be generated" },
        { status: 400 },
      );
    }

    const db = await getDb();

    const existing = await db
      .collection("businesses")
      .findOne({ slug: normalizedSlug });
    if (existing) {
      return Response.json(
        { error: "Business slug already taken" },
        { status: 409 },
      );
    }

    let owner = await db.collection("users").findOne({ email: ownerEmail });
    if (!owner) {
      const bcrypt = await import("bcryptjs");
      const tempPass = "owner" + Date.now().toString(36);
      const passwordHash = await bcrypt.hash(tempPass, 10);
      const nowIso = new Date().toISOString();
      owner = {
        _id:
          "usr_" +
          Date.now().toString(36) +
          Math.random().toString(36).slice(2, 6),
        email: ownerEmail,
        name: ownerName || ownerEmail.split("@")[0],
        role: "owner",
        passwordHash,
        phone: contact?.phone || null,
        location: location || {},
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      await db.collection("users").insertOne(owner);
    }

    const now = new Date().toISOString();
    const business = {
      _id: crypto.randomUUID().replace(/-/g, "").slice(0, 24),
      name,
      slug: normalizedSlug,
      type: primaryType,
      ownerIds: [owner._id],
      ownerName: owner.name,
      ownerEmail,
      location: location || {},
      contact: {
        ...(contact || {}),
        email: contact?.email || ownerEmail,
      },
      payout: {},
      razorpayAccountId: null,
      gstin: String(gstin || "").trim(),
      allowedListingTypes: allowedTypes,
      listingLimit: getBusinessListingLimit({ listingLimit }) || 10,
      workerLimit:
        Number(workerLimit) > 0 ? Math.floor(Number(workerLimit)) : 2,
      platformFeePercent: Number(platformFeePercent) || 10,
      active: true,
      createdAt: now,
      updatedAt: now,
    };

    await db.collection("businesses").insertOne(business);

    return Response.json(
      {
        business,
        owner: { id: owner._id, email: owner.email, name: owner.name },
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Superadmin create business error:", error);
    return Response.json(
      { error: "Failed to create business" },
      { status: 500 },
    );
  }
}

/**
 * PATCH /api/superadmin/businesses
 * Update business controls and metadata.
 */
export async function PATCH(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { businessId, ...updates } = body;

    if (!businessId) {
      return Response.json(
        { error: "businessId is required" },
        { status: 400 },
      );
    }

    const db = await getDb();

    delete updates._id;
    delete updates.ownerIds;

    if (updates.allowedListingTypes) {
      updates.allowedListingTypes = getBusinessAllowedTypes({
        allowedListingTypes: updates.allowedListingTypes,
      });
    }

    if (updates.listingLimit !== undefined) {
      updates.listingLimit = getBusinessListingLimit(updates);
    }

    if (updates.workerLimit !== undefined) {
      updates.workerLimit =
        Number(updates.workerLimit) > 0
          ? Math.floor(Number(updates.workerLimit))
          : 2;

      const activeWorkers = await db.collection("users").countDocuments({
        role: "worker",
        businessId,
        active: { $ne: false },
      });
      if (updates.workerLimit < activeWorkers) {
        return Response.json(
          {
            error: `This business already has ${activeWorkers} active workers. Deactivate workers before lowering the limit below that number.`,
          },
          { status: 409 },
        );
      }
    }

    if (updates.gstin !== undefined) {
      updates.gstin = String(updates.gstin || "").trim();
    }

    if (updates.type) {
      updates.type = normalizeCategory(updates.type) || updates.type;
    }

    updates.updatedAt = new Date().toISOString();

    const result = await db
      .collection("businesses")
      .updateOne({ _id: businessId }, { $set: updates });

    if (result.matchedCount === 0) {
      return Response.json({ error: "Business not found" }, { status: 404 });
    }

    return Response.json({ success: true, modified: result.modifiedCount });
  } catch (error) {
    console.error("Superadmin update business error:", error);
    return Response.json(
      { error: "Failed to update business" },
      { status: 500 },
    );
  }
}
