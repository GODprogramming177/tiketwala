import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";

/**
 * GET /api/superadmin/payouts
 * List all payouts with optional status filter.
 */
export async function GET(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const businessId = searchParams.get("businessId");

    const db = await getDb();
    const filter = {};
    if (status) filter.status = status;
    if (businessId) filter.businessId = businessId;

    const payouts = await db
      .collection("payouts")
      .find(filter)
      .sort({ createdAt: -1 })
      .toArray();

    return Response.json({ payouts });
  } catch (error) {
    console.error("Superadmin payouts error:", error);
    return Response.json({ error: "Failed to fetch payouts" }, { status: 500 });
  }
}

/**
 * POST /api/superadmin/payouts
 * Create a payout record for a business (aggregates pending revenue).
 */
export async function POST(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { businessId, periodFrom, periodTo } = body;

    if (!businessId || !periodFrom || !periodTo) {
      return Response.json(
        { error: "businessId, periodFrom, and periodTo are required" },
        { status: 400 },
      );
    }

    const db = await getDb();

    // Fetch business info
    const business = await db
      .collection("businesses")
      .findOne({ _id: businessId });
    if (!business) {
      return Response.json({ error: "Business not found" }, { status: 404 });
    }

    // Aggregate bookings in the period
    const bookings = await db
      .collection("bookings")
      .aggregate([
        {
          $match: {
            businessId,
            status: "confirmed",
            createdAt: { $gte: periodFrom, $lte: periodTo + "T23:59:59Z" },
          },
        },
        {
          $group: {
            _id: null,
            totalAmount: { $sum: "$totalAmount" },
            platformFee: { $sum: "$platformFee" },
            businessAmount: { $sum: "$businessAmount" },
            bookingCount: { $sum: 1 },
          },
        },
      ])
      .toArray();

    const agg = bookings[0] || {
      totalAmount: 0,
      platformFee: 0,
      businessAmount: 0,
      bookingCount: 0,
    };

    if (agg.bookingCount === 0) {
      return Response.json(
        { error: "No bookings found in the specified period" },
        { status: 400 },
      );
    }

    const now = new Date().toISOString();
    const payout = {
      _id: crypto.randomUUID().replace(/-/g, "").slice(0, 24),
      businessId,
      businessName: business.name,
      amount: agg.totalAmount,
      platformFee: agg.platformFee,
      netPayout: agg.businessAmount,
      bookingCount: agg.bookingCount,
      period: { from: periodFrom, to: periodTo },
      status: "pending",
      razorpayPayoutId: null,
      razorpayTransferId: null,
      processedAt: null,
      createdAt: now,
      updatedAt: now,
    };

    await db.collection("payouts").insertOne(payout);

    return Response.json({ payout }, { status: 201 });
  } catch (error) {
    console.error("Superadmin create payout error:", error);
    return Response.json({ error: "Failed to create payout" }, { status: 500 });
  }
}

/**
 * PATCH /api/superadmin/payouts
 * Mark a payout as processed/completed.
 */
export async function PATCH(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const {
      payoutId,
      status: newStatus,
      razorpayPayoutId,
      razorpayTransferId,
    } = body;

    if (!payoutId || !newStatus) {
      return Response.json(
        { error: "payoutId and status are required" },
        { status: 400 },
      );
    }

    if (!["pending", "processing", "completed", "failed"].includes(newStatus)) {
      return Response.json(
        { error: "status must be: pending, processing, completed, or failed" },
        { status: 400 },
      );
    }

    const db = await getDb();
    const now = new Date().toISOString();

    const updateFields = {
      status: newStatus,
      updatedAt: now,
    };
    if (newStatus === "completed") updateFields.processedAt = now;
    if (razorpayPayoutId) updateFields.razorpayPayoutId = razorpayPayoutId;
    if (razorpayTransferId)
      updateFields.razorpayTransferId = razorpayTransferId;

    const result = await db
      .collection("payouts")
      .updateOne({ _id: payoutId }, { $set: updateFields });

    if (result.matchedCount === 0) {
      return Response.json({ error: "Payout not found" }, { status: 404 });
    }

    return Response.json({ success: true, modified: result.modifiedCount });
  } catch (error) {
    console.error("Superadmin update payout error:", error);
    return Response.json({ error: "Failed to update payout" }, { status: 500 });
  }
}
