import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";

/**
 * GET /api/superadmin/revenue
 * Platform-wide revenue analytics with breakdown by business, city, and type.
 * Query params: from, to (date range), businessId, city, type
 */
export async function GET(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const businessId = searchParams.get("businessId");

    const db = await getDb();

    // Base match for confirmed bookings
    const match = { status: "confirmed" };
    if (from || to) {
      match.createdAt = {};
      if (from) match.createdAt.$gte = from;
      if (to) match.createdAt.$lte = to + "T23:59:59Z";
    }
    if (businessId) match.businessId = businessId;

    // Revenue per business
    const perBusiness = await db
      .collection("bookings")
      .aggregate([
        { $match: match },
        {
          $group: {
            _id: "$businessId",
            totalRevenue: { $sum: "$totalAmount" },
            platformFee: { $sum: "$platformFee" },
            businessAmount: { $sum: "$businessAmount" },
            bookings: { $sum: 1 },
          },
        },
        {
          $lookup: {
            from: "businesses",
            localField: "_id",
            foreignField: "_id",
            as: "business",
          },
        },
        { $unwind: { path: "$business", preserveNullAndEmptyArrays: true } },
        {
          $project: {
            businessId: "$_id",
            businessName: "$business.name",
            businessType: "$business.type",
            city: "$business.location.city",
            totalRevenue: 1,
            platformFee: 1,
            businessAmount: 1,
            bookings: 1,
          },
        },
        { $sort: { totalRevenue: -1 } },
      ])
      .toArray();

    // Totals
    const totals = perBusiness.reduce(
      (acc, b) => ({
        totalRevenue: acc.totalRevenue + b.totalRevenue,
        platformFee: acc.platformFee + b.platformFee,
        businessAmount: acc.businessAmount + b.businessAmount,
        bookings: acc.bookings + b.bookings,
      }),
      { totalRevenue: 0, platformFee: 0, businessAmount: 0, bookings: 0 },
    );

    // Revenue by day (for chart)
    const daily = await db
      .collection("bookings")
      .aggregate([
        { $match: match },
        {
          $addFields: {
            dateStr: { $substr: ["$createdAt", 0, 10] },
          },
        },
        {
          $group: {
            _id: "$dateStr",
            revenue: { $sum: "$totalAmount" },
            platformFee: { $sum: "$platformFee" },
            bookings: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ])
      .toArray();

    return Response.json({
      totals,
      perBusiness,
      daily,
    });
  } catch (error) {
    console.error("Superadmin revenue error:", error);
    return Response.json(
      { error: "Failed to fetch revenue data" },
      { status: 500 },
    );
  }
}
