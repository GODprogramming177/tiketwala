import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";
import { ObjectId } from "mongodb";

/**
 * GET /api/superadmin/users
 * List all users with optional role filter.
 */
export async function GET(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const role = searchParams.get("role");
    const email = searchParams.get("email");

    const db = await getDb();
    const filter = {};
    if (role) filter.role = role;
    if (email) filter.email = { $regex: new RegExp(email, "i") };

    const users = await db
      .collection("users")
      .find(filter)
      .project({ passwordHash: 0 }) // Exclude sensitive fields
      .sort({ createdAt: -1 })
      .toArray();

    return Response.json({ users });
  } catch (error) {
    console.error("Superadmin users error:", error);
    return Response.json({ error: "Failed to fetch users" }, { status: 500 });
  }
}

/**
 * POST /api/superadmin/users
 * Create a new user (owner or customer).
 */
export async function POST(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { name, email, password, role, phone, location } = body;

    if (!name || !email || !password || !role) {
      return Response.json(
        { error: "name, email, password, and role are required" },
        { status: 400 },
      );
    }

    if (!["owner", "customer"].includes(role)) {
      return Response.json(
        { error: "role must be 'owner' or 'customer'" },
        { status: 400 },
      );
    }

    const db = await getDb();

    const existing = await db.collection("users").findOne({ email });
    if (existing) {
      return Response.json(
        { error: "User with this email already exists" },
        { status: 409 },
      );
    }

    const bcrypt = await import("bcryptjs");
    const passwordHash = await bcrypt.hash(password, 10);
    const now = new Date().toISOString();

    const newUser = {
      name,
      email,
      passwordHash,
      role,
      phone: phone || null,
      location: location || {},
      createdAt: now,
      updatedAt: now,
    };

    const result = await db.collection("users").insertOne(newUser);

    return Response.json(
      {
        user: {
          id: result.insertedId,
          name,
          email,
          role,
        },
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Superadmin create user error:", error);
    return Response.json({ error: "Failed to create user" }, { status: 500 });
  }
}

/**
 * PATCH /api/superadmin/users
 * Update a user's role or info.
 */
export async function PATCH(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const { userId, ...updates } = body;

    if (!userId) {
      return Response.json({ error: "userId is required" }, { status: 400 });
    }

    const db = await getDb();

    // Prevent overwriting sensitive fields
    delete updates._id;
    delete updates.passwordHash;
    delete updates.email; // Email changes need separate flow
    updates.updatedAt = new Date().toISOString();

    const query = ObjectId.isValid(userId)
      ? { $or: [{ _id: userId }, { _id: new ObjectId(userId) }] }
      : { _id: userId };

    const result = await db
      .collection("users")
      .updateOne(query, { $set: updates });

    if (result.matchedCount === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({ success: true, modified: result.modifiedCount });
  } catch (error) {
    console.error("Superadmin update user error:", error);
    return Response.json({ error: "Failed to update user" }, { status: 500 });
  }
}

/**
 * DELETE /api/superadmin/users
 * Delete a user account permanently.
 */
export async function DELETE(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return Response.json({ error: "userId is required" }, { status: 400 });
    }

    const db = await getDb();

    const query = ObjectId.isValid(userId)
      ? { $or: [{ _id: userId }, { _id: new ObjectId(userId) }] }
      : { _id: userId };

    // Check if the user exists
    const user = await db.collection("users").findOne(query);
    if (!user) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    // Delete user
    await db.collection("users").deleteOne(query);

    return Response.json({ success: true, message: "User account deleted successfully" });
  } catch (error) {
    console.error("Superadmin delete user error:", error);
    return Response.json({ error: "Failed to delete user" }, { status: 500 });
  }
}
