import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";

/**
 * GET /api/superadmin/dashboard
 * Platform-wide statistics for the superadmin dashboard.
 */
export async function GET(request) {
  try {
    const auth = await requireRole(request, ["superadmin", "super_admin"]);
    if (auth.error) {
      return auth.error;
    }

    const db = await getDb();

    const [
      totalUsers,
      totalBusinesses,
      totalProperties,
      totalBookings,
      totalOrders,
      pendingPayouts,
    ] = await Promise.all([
      db.collection("users").countDocuments({}),
      db.collection("businesses").countDocuments({}),
      db.collection("properties").countDocuments({}),
      db.collection("bookings").countDocuments({}),
      db.collection("orders").countDocuments({}),
      db.collection("payouts").countDocuments({ status: "pending" }),
    ]);

    // Revenue aggregation
    const revenueAgg = await db
      .collection("bookings")
      .aggregate([
        { $match: { status: "confirmed" } },
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: "$totalAmount" },
            platformRevenue: { $sum: "$platformFee" },
            businessRevenue: { $sum: "$businessAmount" },
          },
        },
      ])
      .toArray();

    const revenue = revenueAgg[0] || {
      totalRevenue: 0,
      platformRevenue: 0,
      businessRevenue: 0,
    };

    // Revenue by city
    const cityRevenue = await db
      .collection("bookings")
      .aggregate([
        { $match: { status: "confirmed" } },
        {
          $lookup: {
            from: "businesses",
            localField: "businessId",
            foreignField: "_id",
            as: "business",
          },
        },
        { $unwind: "$business" },
        {
          $group: {
            _id: "$business.location.city",
            total: { $sum: "$totalAmount" },
            platformFee: { $sum: "$platformFee" },
            bookings: { $sum: 1 },
          },
        },
        { $sort: { total: -1 } },
      ])
      .toArray();

    // Revenue by business type
    const typeRevenue = await db
      .collection("bookings")
      .aggregate([
        { $match: { status: "confirmed" } },
        {
          $lookup: {
            from: "businesses",
            localField: "businessId",
            foreignField: "_id",
            as: "business",
          },
        },
        { $unwind: "$business" },
        {
          $group: {
            _id: "$business.type",
            total: { $sum: "$totalAmount" },
            platformFee: { $sum: "$platformFee" },
            bookings: { $sum: 1 },
          },
        },
      ])
      .toArray();

    // Recent bookings
    const recentBookings = await db
      .collection("bookings")
      .find({})
      .sort({ createdAt: -1 })
      .limit(10)
      .toArray();

    // User breakdown
    const usersByRole = await db
      .collection("users")
      .aggregate([{ $group: { _id: "$role", count: { $sum: 1 } } }])
      .toArray();

    return Response.json({
      stats: {
        totalUsers,
        totalBusinesses,
        totalProperties,
        totalBookings,
        totalOrders,
        pendingPayouts,
        ...revenue,
      },
      cityRevenue,
      typeRevenue,
      usersByRole: Object.fromEntries(usersByRole.map((r) => [r._id, r.count])),
      recentBookings,
    });
  } catch (error) {
    console.error("Superadmin dashboard error:", error);
    return Response.json(
      { error: "Failed to fetch dashboard data" },
      { status: 500 },
    );
  }
}
