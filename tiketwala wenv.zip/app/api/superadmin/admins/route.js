import { getDb } from "@/lib/mongodb";
import { requireRole } from "@/lib/rbac";
import { enforceApiAccess } from "@/lib/apiAccess";

export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) return auth.error;

    const db = await getDb();
    
    // Aggregation pipeline to join users (role: owner) with their businesses
    const pipeline = [
      {
        $match: { role: "owner" }
      },
      {
        $lookup: {
          from: "businesses",
          localField: "_id",
          foreignField: "ownerIds",
          as: "businessDetails"
        }
      },
      {
        $project: {
          passwordHash: 0 // exclude sensitive info
        }
      },
      {
        $sort: { createdAt: -1 }
      }
    ];

    const admins = await db.collection("users").aggregate(pipeline).toArray();

    // Map the shape to a flatter structure for the UI
    const mappedAdmins = admins.map(user => {
      const business = user.businessDetails?.[0] || {};
      return {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone || "",
        role: user.role,
        createdAt: user.createdAt,
        businessId: business._id || null,
        businessName: business.name || "N/A",
        listingLimit: business.listingLimit || 0,
        workerLimit: business.workerLimit || 0,
        allowedListingTypes: business.allowedListingTypes || [],
        businessActive: business.active !== false
      };
    });

    return Response.json({ success: true, admins: mappedAdmins });
  } catch (error) {
    console.error("Fetch admins error:", error);
    return Response.json({ error: "Failed to fetch admins" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) return auth.error;

    const body = await request.json();
    const { userId, businessId, name, phone, businessName, listingLimit, workerLimit, allowedListingTypes, active } = body;

    if (!userId || !businessId) {
      return Response.json({ error: "Missing required IDs" }, { status: 400 });
    }

    const db = await getDb();

    const nextWorkerLimit = Number(workerLimit) || 1;
    const activeWorkers = await db.collection("users").countDocuments({
      role: "worker",
      businessId,
      active: { $ne: false },
    });
    if (nextWorkerLimit < activeWorkers) {
      return Response.json(
        {
          error: `This admin already has ${activeWorkers} active workers. Deactivate workers before lowering the limit.`,
        },
        { status: 409 },
      );
    }

    // Update user
    await db.collection("users").updateOne(
      { _id: userId },
      { $set: { name, phone: phone || "", updatedAt: new Date().toISOString() } }
    );

    // Build business update
    const businessUpdate = { 
      name: businessName,
      ownerName: name, // keep synced
      listingLimit: Number(listingLimit) || 1,
      workerLimit: nextWorkerLimit,
      allowedListingTypes: Array.isArray(allowedListingTypes) ? allowedListingTypes : [],
      updatedAt: new Date().toISOString()
    };

    // If active status is explicitly provided, include it
    if (typeof active === "boolean") {
      businessUpdate.active = active;
    }

    // Update business
    await db.collection("businesses").updateOne(
      { _id: businessId },
      { $set: businessUpdate }
    );

    return Response.json({ success: true });
  } catch (error) {
    console.error("Update admin error:", error);
    return Response.json({ error: "Failed to update admin" }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, ["superadmin"]);
    if (auth.error) return auth.error;

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const businessId = searchParams.get("businessId");

    if (!userId || !businessId) {
      return Response.json({ error: "Missing required IDs" }, { status: 400 });
    }

    const db = await getDb();

    // Hard delete user, business, and their nested listings
    await db.collection("users").deleteOne({ _id: userId });
    await db.collection("businesses").deleteOne({ _id: businessId });
    await db.collection("listings").deleteMany({ "businessId": businessId });
    // Also delete any slots created by this business/user
    await db.collection("slots").deleteMany({ "businessId": businessId });

    return Response.json({ success: true, message: "Admin fully deleted" });
  } catch (error) {
    console.error("Delete admin error:", error);
    return Response.json({ error: "Failed to delete admin" }, { status: 500 });
  }
}
