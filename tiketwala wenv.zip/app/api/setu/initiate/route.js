import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { getSetuToken } from "@/lib/setu";
import crypto from "crypto";

export async function POST(req) {
  try {
    const body = await req.json();
    const { amount, invoiceNo } = body;

    if (!amount || !invoiceNo) {
      return NextResponse.json({ error: "Amount and Invoice Number are required" }, { status: 400 });
    }

    const merchantId = process.env.SETU_MERCHANT_ID;
    const merchantVpa = process.env.SETU_MERCHANT_VPA;

    if (!merchantId || !merchantVpa) {
      return NextResponse.json({ error: "Setu merchant credentials not configured" }, { status: 500 });
    }

    // Generate transaction ID
    const transactionId = crypto.randomBytes(8).toString("hex");
    const merchantReferenceId = `POS-${transactionId}`;

    // Get access token
    const token = await getSetuToken();

    // Prepare payload
    // Note: Setu amount is typically in paise, meaning amount * 100
    // But verify the API documentation for precise denomination. Assuming paise as standard UPI behavior.
    const amountInPaise = Math.round(parseFloat(amount) * 100);

    const payload = {
      merchantVpa: merchantVpa,
      amount: amountInPaise,
      merchantReferenceId: merchantReferenceId,
      transactionNote: `Invoice ${invoiceNo}`,
      metadata: {
        invoiceNo: invoiceNo
      }
    };

    // Make request to Setu API
    const response = await fetch("https://umap.setu.co/api/v1/merchants/dqr", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
        "merchantId": merchantId
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Setu API error:", data);
      return NextResponse.json({ 
        error: "Failed to generate Setu QR", 
        details: data 
      }, { status: response.status });
    }

    // Save transaction in DB
    const db = await getDb();
    await db.collection("setu_transactions").insertOne({
      transactionId: transactionId,
      merchantReferenceId: merchantReferenceId,
      dqr_id: data.id || data.data?.id,
      invoiceNo,
      amount,
      intentLink: data.intentLink || data.data?.intentLink,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date()
    });

    return NextResponse.json({
      success: true,
      transactionId,
      intentLink: data.intentLink || data.data?.intentLink,
      dqr_id: data.id || data.data?.id
    });
  } catch (error) {
    console.error("Setu initiate error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
