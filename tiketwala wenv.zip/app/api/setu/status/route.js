import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { getSetuToken } from "@/lib/setu";

export async function POST(req) {
  try {
    const body = await req.json();
    const { transactionId } = body;

    if (!transactionId) {
      return NextResponse.json({ error: "Transaction ID is required" }, { status: 400 });
    }

    const merchantId = process.env.SETU_MERCHANT_ID;
    
    if (!merchantId) {
      return NextResponse.json({ error: "Setu merchant credentials not configured" }, { status: 500 });
    }

    const db = await getDb();
    
    // Fetch transaction from DB to get the dqr_id
    const transaction = await db.collection("setu_transactions").findOne({ transactionId });
    
    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    // If we already recorded it as success, return success directly
    if (transaction.status === "success" || transaction.status === "failed") {
      return NextResponse.json({ 
        success: transaction.status === "success", 
        status: transaction.status 
      });
    }

    if (!transaction.dqr_id) {
      return NextResponse.json({ error: "DQR ID not found for this transaction" }, { status: 400 });
    }

    // Get access token
    const token = await getSetuToken();

    // Check status with Setu
    const response = await fetch(`https://umap.setu.co/api/v1/merchants/dqr/${transaction.dqr_id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
        "merchantId": merchantId
      }
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Setu API status error:", data);
      return NextResponse.json({ error: "Failed to check status" }, { status: response.status });
    }

    // Setu DQR status values vary (e.g. SUCCESS, PENDING, EXPIRED, FAILED)
    const setuStatus = data.status || data.data?.status;
    let localStatus = "pending";
    let isSuccess = false;

    if (setuStatus === "SUCCESS" || setuStatus === "PAID") {
      localStatus = "success";
      isSuccess = true;
    } else if (setuStatus === "FAILED" || setuStatus === "EXPIRED") {
      localStatus = "failed";
    }

    // Update DB if status changed
    if (localStatus !== transaction.status) {
      await db.collection("setu_transactions").updateOne(
        { transactionId },
        { 
          $set: { 
            status: localStatus, 
            updatedAt: new Date(),
            setuResponse: data 
          } 
        }
      );
    }

    return NextResponse.json({
      success: isSuccess,
      status: localStatus
    });
  } catch (error) {
    console.error("Setu status error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
