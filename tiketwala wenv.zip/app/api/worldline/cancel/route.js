import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { encryptRequest, decryptResponse } from "@/lib/worldline";

export async function POST(req) {
  try {
    const body = await req.json();
    const { transactionId, terminalId = process.env.WORLDLINE_SOURCE || "629" } = body;

    if (!transactionId) {
      return NextResponse.json({ error: "Missing transactionId" }, { status: 400 });
    }

    const db = await getDb();
    const transaction = await db.collection("worldline_transactions").findOne({ _id: transactionId });

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    if (transaction.status === "success") {
      return NextResponse.json({ error: "Cannot cancel a successful transaction" }, { status: 400 });
    }

    // Prepare cancellation payload
    const payload = {
      CancelTransactionRequest: {
        transactionId,
        tid: process.env.WORLDLINE_TID,
        mid: process.env.WORLDLINE_MID
      }
    };

    const encryptedData = encryptRequest(JSON.stringify(payload));

    const cancelUrl = process.env.WORLDLINE_CANCEL_URL;

    const response = await fetch(cancelUrl, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain",
      },
      body: encryptedData
    });

    if (!response.ok) {
      throw new Error(`Worldline API error: ${response.status}`);
    }

    // Decrypt and process response if needed
    const responseText = await response.text();
    
    let responseDataToDecrypt = responseText;
    try {
      const parsed = JSON.parse(responseText);
      if (parsed && parsed.data) {
        responseDataToDecrypt = parsed.data;
      }
    } catch (e) {
      // Not JSON
    }
    
    let decryptedResponse;
    try {
      decryptedResponse = decryptResponse(responseDataToDecrypt);
    } catch (e) {
      console.warn("Could not decrypt cancel response", e);
      decryptedResponse = responseText;
    }

    // Update DB
    await db.collection("worldline_transactions").updateOne(
      { _id: transactionId },
      { 
        $set: { 
          status: "cancelled",
          rawCancelResponse: decryptedResponse,
          updatedAt: new Date().toISOString() 
        } 
      }
    );

    return NextResponse.json({ 
      success: true, 
      status: "cancelled" 
    });

  } catch (error) {
    console.error("Worldline Cancel Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
