import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { encryptRequest, decryptResponse } from "@/lib/worldline";
import crypto from "crypto";

export async function POST(req) {
  try {
    const body = await req.json();
    const { invoiceNo, amount, actionId = "1", terminalId = process.env.WORLDLINE_SOURCE || "629" } = body;

    if (!invoiceNo || !amount) {
      return NextResponse.json({ error: "Missing invoiceNo or amount" }, { status: 400 });
    }

    const db = await getDb();
    
    // Create transaction ID for reference
    const transactionId = crypto.randomUUID().replace(/-/g, "").substring(0, 16);

    // Save initial transaction state as pending
    const transaction = {
      _id: transactionId,
      invoiceNo,
      terminalId,
      amount: parseFloat(amount),
      status: "pending",
      paymentMode: "POS",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.collection("worldline_transactions").insertOne(transaction);

    // The exact JSON structure required by Worldline API
    const payload = {
      tid: process.env.WORLDLINE_TID,
      amount: amount.toString(), // amount seems to be in rupees based on "194" -> "194.00" in their response, but we'll use exact amount passed
      organization_code: "Retail",
      additional_attribute1: "",
      additional_attribute2: "",
      additional_attribute3: "",
      invoiceNumber: invoiceNo.replace(/\D/g, '').slice(-6) || "000000",
      rrn: "",
      type: "SALE",
      cb_amt: "",
      app_code: "",
      tokenisedValue: "",
      actionId: actionId,
      request_urn: transactionId
    };

    // Note: If Worldline expects the exact string parameters, format accordingly.
    // Encrypt the payload
    const encryptedData = encryptRequest(JSON.stringify(payload));

    const initUrl = process.env.WORLDLINE_INITIATE_URL;

    // Send the encrypted payload to Worldline endpoint as RAW string
    const response = await fetch(initUrl, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain",
      },
      body: encryptedData
    });

    if (!response.ok) {
      throw new Error(`Worldline API error: ${response.status}`);
    }

    const responseText = await response.text();
    
    // Worldline sometimes wraps successful responses in a JSON { data: "encryptedString" }
    let responseDataToDecrypt = responseText;
    try {
      const parsed = JSON.parse(responseText);
      if (parsed && parsed.data) {
        responseDataToDecrypt = parsed.data;
      }
    } catch (e) {
      // It's not JSON, so it might just be the raw encrypted string directly
    }

    // Assuming the response from POS initiation contains { encryptedResponse: "..." } or just the text
    let decryptedResponse;
    try {
      decryptedResponse = decryptResponse(responseDataToDecrypt);
    } catch (e) {
      console.warn("Could not decrypt immediate init response, might just be acknowledgment", e);
      decryptedResponse = responseText;
    }

    // Update rawRequest in DB
    await db.collection("worldline_transactions").updateOne(
      { _id: transactionId },
      { $set: { rawRequest: payload, rawInitResponse: decryptedResponse, updatedAt: new Date().toISOString() } }
    );

    // If worldline returns an error code (usually "1" is error, "0" or "00" is success)
    if (decryptedResponse && typeof decryptedResponse === 'object') {
      if (decryptedResponse.response_code === "1" || decryptedResponse.response_message === "POS Terminal not available") {
        return NextResponse.json({
          success: false,
          error: decryptedResponse.response_message || "Terminal not available"
        }, { status: 400 });
      }
    }

    return NextResponse.json({ 
      success: true, 
      transactionId, 
      message: "Payment initiated on terminal" 
    });

  } catch (error) {
    console.error("Worldline Initiate Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
