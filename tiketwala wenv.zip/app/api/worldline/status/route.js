import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";
import { encryptRequest, decryptResponse } from "@/lib/worldline";

export async function POST(req) {
  try {
    const body = await req.json();
    const { transactionId, terminalId = process.env.WORLDLINE_SOURCE || "629" } = body;

    if (!transactionId) {
      return NextResponse.json({ error: "Missing transactionId" }, { status: 400 });
    }

    const db = await getDb();
    const transaction = await db.collection("worldline_transactions").findOne({ _id: transactionId });

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    // Check status directly with Worldline
    const payload = {
      StatusCheckRequest: {
        transactionId,
        tid: process.env.WORLDLINE_TID,
        mid: process.env.WORLDLINE_MID
      }
    };

    const encryptedData = encryptRequest(JSON.stringify(payload));

    const statusUrl = process.env.WORLDLINE_STATUS_URL;

    const response = await fetch(statusUrl, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain",
      },
      body: encryptedData
    });

    if (!response.ok) {
      throw new Error(`Worldline API error: ${response.status}`);
    }

    const responseText = await response.text();
    
    let responseDataToDecrypt = responseText;
    try {
      const parsed = JSON.parse(responseText);
      if (parsed && parsed.data) {
        responseDataToDecrypt = parsed.data;
      }
    } catch (e) {
      // Not JSON
    }
    
    let decryptedResponse;
    try {
      decryptedResponse = decryptResponse(responseDataToDecrypt);
    } catch (e) {
      console.error("Failed to decrypt status response", e);
      return NextResponse.json({ status: "pending", error: "Decryption failed or invalid response" });
    }

    // Handle Worldline specific response code
    if (decryptedResponse && typeof decryptedResponse === 'object') {
      if (decryptedResponse.response_code === "1" || decryptedResponse.response_message === "POS Terminal not available") {
        return NextResponse.json({ 
          status: "failed", 
          error: decryptedResponse.response_message || "Terminal not available",
          worldlineResponse: decryptedResponse
        });
      }
    }

    // Parse status from decrypted response. The structure depends on Worldline's actual API.
    // Example format assumption:
    // { status: "SUCCESS", authCode: "123456", rrn: "987654321" }
    
    // Convert to lowercase to standardize our DB states ("success", "failed", "pending")
    const responseData = typeof decryptedResponse === 'string' ? JSON.parse(decryptedResponse) : decryptedResponse;
    const paymentStatus = responseData?.status?.toLowerCase() || "pending";
    const authCode = responseData?.authCode || null;
    const rrn = responseData?.rrn || null;

    if (paymentStatus !== transaction.status) {
      await db.collection("worldline_transactions").updateOne(
        { _id: transactionId },
        { 
          $set: { 
            status: paymentStatus, 
            authCode, 
            rrn,
            rawResponse: responseData,
            updatedAt: new Date().toISOString() 
          } 
        }
      );
    }

    return NextResponse.json({ 
      success: true, 
      status: paymentStatus,
      authCode,
      rrn
    });

  } catch (error) {
    console.error("Worldline Status Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
