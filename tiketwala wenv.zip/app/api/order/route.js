import { getDb } from "@/lib/mongodb";
import Razorpay from "razorpay";
import { calculateFees } from "@/lib/rbac";
import { requireRole, canAccessBusiness } from "@/lib/rbac";
import {
  calculatePropertyPricing,
  isAgePricingEnabled,
} from "@/lib/listingUtils";
import { enforceApiAccess } from "@/lib/apiAccess";

/**
 * POST /api/order
 * Create a booking order with pricing from the DB, fee calculation, and Razorpay Orders API.
 */
export async function POST(request) {
  try {
    const blocked = enforceApiAccess(request);
    if (blocked) return blocked;

    const auth = await requireRole(request, ["customer"]);
    if (auth.error) {
      return auth.error;
    }

    const body = await request.json();
    const {
      listingId,
      slot,
      quantity = 1,
      attendeeCounts = null,
      selectedSeats,
      selectedOffering,
      selectedAddOns,
      guestAges = [],
    } = body;

    if (!listingId || !slot) {
      return Response.json(
        { error: "Listing ID and slot are required" },
        { status: 400 },
      );
    }

    const requestedAdultCount = Math.max(
      0,
      Math.floor(Number(attendeeCounts?.adult) || 0),
    );
    const requestedChildCount = Math.max(
      0,
      Math.floor(Number(attendeeCounts?.child) || 0),
    );
    const requestedTotalCount = requestedAdultCount + requestedChildCount;

    const requestedQuantity = Number(quantity);
    const safeQuantity =
      requestedTotalCount > 0 ? requestedTotalCount : requestedQuantity;
    if (!Number.isFinite(safeQuantity) || safeQuantity < 1) {
      return Response.json(
        { error: "quantity must be at least 1" },
        { status: 400 },
      );
    }

    const normalizedAttendeeCounts =
      requestedTotalCount > 0
        ? {
            adult: requestedAdultCount,
            child: requestedChildCount,
          }
        : null;

    const db = await getDb();
    const property = await db
      .collection("properties")
      .findOne({ _id: listingId });

    if (!property) {
      return Response.json({ error: "Listing not found" }, { status: 404 });
    }

    const hasCompleteGuestAges =
      Array.isArray(guestAges) && guestAges.length >= safeQuantity;
    if (
      isAgePricingEnabled(property) &&
      !hasCompleteGuestAges &&
      !normalizedAttendeeCounts
    ) {
      return Response.json(
        { error: "Guest ages are required for this listing" },
        { status: 400 },
      );
    }

    const slotDoc = await db.collection("slots").findOne({
      propertyId: listingId,
      start: slot,
    });
    if (!slotDoc) {
      return Response.json({ error: "Slot not found" }, { status: 404 });
    }

    // Fetch the business for fee calculation
    const business = await db
      .collection("businesses")
      .findOne({ _id: property.businessId });

    const pricing = calculatePropertyPricing(property, {
      quantity: safeQuantity,
      attendeeCounts: normalizedAttendeeCounts,
      selectedSeats,
      selectedSubCategory: selectedOffering,
      selectedOffering,
      selectedAddOns,
      guestAges,
    });
    const totalAmount = pricing.totalAmount;

    if (totalAmount <= 0) {
      return Response.json({ error: "Invalid order amount" }, { status: 400 });
    }

    const totalAmountPaise = totalAmount * 100;
    const fees = calculateFees(totalAmount, business);

    // Initialize Razorpay
    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });

    // Create order in Razorpay
    const options = {
      amount: totalAmountPaise,
      currency: "INR",
      receipt: `rcpt_${Date.now()}_${listingId.substring(0, 5)}`,
    };

    const rzpOrder = await razorpay.orders.create(options);

    // Save order details to our MongoDB
    const order = {
      _id: crypto.randomUUID().replace(/-/g, "").slice(0, 24),
      orderId: `ORD${Date.now()}${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
      rzpOrderId: rzpOrder.id,
      propertyId: listingId,
      businessId: property.businessId,
      customerId: auth.user._id,
      customerEmail: auth.user.email,
      listingName: property.name,
      slot,
      quantity: safeQuantity,
      attendeeCounts: pricing.attendeeCounts,
      selectedSeats: pricing.selectedSeats,
      selectedOffering: pricing.selectedOffering,
      guestAges: pricing.guestAges,
      fareBreakdown: pricing.fareBreakdown,
      selectedAddOns: pricing.selectedAddOns,
      unitPrice: pricing.unitPrice,
      baseAmount: pricing.baseAmount,
      addOnAmount: pricing.addOnAmount,
      totalAmount,
      slotEnd: slotDoc.end,
      platformFee: fees.platformFee,
      businessAmount: fees.businessAmount,
      currency: "INR",
      status: "created",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.collection("orders").insertOne(order);

    return Response.json(order, { status: 201 });
  } catch (error) {
    console.error("Order create error:", error);
    return Response.json({ error: "Failed to create order" }, { status: 500 });
  }
}

/**
 * GET /api/order?id=<orderId>
 * Get order details from DB.
 */
export async function GET(request) {
  try {
    const blocked = enforceApiAccess(request, { requireClientHeader: false });
    if (blocked) return blocked;

    const auth = await requireRole(request, [
      "customer",
      "owner",
      "superadmin",
    ]);
    if (auth.error) {
      return auth.error;
    }

    const { searchParams } = new URL(request.url);
    const orderId = searchParams.get("id");

    if (!orderId) {
      return Response.json({ error: "Order ID is required" }, { status: 400 });
    }

    const db = await getDb();
    const order = await db.collection("orders").findOne({ orderId });

    if (!order) {
      return Response.json({ error: "Order not found" }, { status: 404 });
    }

    if (auth.user.role === "customer" && order.customerId !== auth.user._id) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    if (
      auth.user.role === "owner" &&
      !canAccessBusiness(auth, order.businessId)
    ) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    return Response.json(order);
  } catch (error) {
    console.error("Order GET error:", error);
    return Response.json({ error: "Failed to fetch order" }, { status: 500 });
  }
}
