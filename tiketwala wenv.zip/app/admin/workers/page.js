"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";

function buildEmptyWorker(businessId = "") {
  return {
    businessId,
    name: "",
    email: "",
    phone: "",
    password: "",
    posPermissions: ["pos", "scan"],
  };
}

export default function AdminWorkersPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    authHeaders,
    isSuperAdmin,
    getBusinessId,
  } = useAdminAuth();

  const [workers, setWorkers] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingWorker, setEditingWorker] = useState(null);
  const [formData, setFormData] = useState(buildEmptyWorker());

  useEffect(() => {
    if (!authLoading && !admin) {
      router.push("/admin/login");
    }
  }, [admin, authLoading, router]);

  useEffect(() => {
    if (admin) {
      fetchWorkers();
    }
  }, [admin]);

  const fetchWorkers = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/workers", {
        headers: authHeaders(),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to fetch workers");
      }

      const nextBusinesses = Array.isArray(data.businesses) ? data.businesses : [];
      const nextWorkers = Array.isArray(data.workers) ? data.workers : [];
      setBusinesses(nextBusinesses);
      setWorkers(nextWorkers);
      setFormData((prev) =>
        prev.businessId
          ? prev
          : buildEmptyWorker(getBusinessId() || nextBusinesses[0]?._id || ""),
      );
    } catch (error) {
      toast.error(error.message || "Unable to load workers");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEditingWorker(null);
    setShowModal(false);
    setFormData(buildEmptyWorker(getBusinessId() || businesses[0]?._id || ""));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!formData.businessId || !formData.name || !formData.email) {
      toast.error("Business, name, and email are required");
      return;
    }

    if (!editingWorker && !formData.password) {
      toast.error("Password is required for new workers");
      return;
    }

    setSaving(true);
    try {
      const response = await fetch("/api/admin/workers", {
        method: editingWorker ? "PATCH" : "POST",
        headers: authHeaders(),
        body: JSON.stringify(
          editingWorker
            ? {
                userId: editingWorker._id,
                name: formData.name,
                email: formData.email,
                phone: formData.phone,
                password: formData.password || undefined,
                posPermissions: formData.posPermissions,
              }
            : formData,
        ),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to save worker");
      }

      toast.success(editingWorker ? "Worker updated" : "Worker created");
      await fetchWorkers();
      resetForm();
    } catch (error) {
      toast.error(error.message || "Unable to save worker");
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (worker) => {
    setEditingWorker(worker);
    setFormData({
      businessId: worker.businessId || "",
      name: worker.name || "",
      email: worker.email || "",
      phone: worker.phone || "",
      password: "",
      posPermissions: Array.isArray(worker.posPermissions)
        ? worker.posPermissions
        : ["pos", "scan"],
    });
    setShowModal(true);
  };

  const handleDelete = async (workerId) => {
    if (!confirm("This will PERMANENTLY delete this worker and send a notification email to the business owner. Continue?")) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/workers?userId=${workerId}`, {
        method: "DELETE",
        headers: authHeaders(),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to delete worker");
      }
      toast.success("Worker permanently deleted. Notification sent.");
      await fetchWorkers();
    } catch (error) {
      toast.error(error.message || "Unable to remove worker");
    }
  };

  const handleDeactivate = async (worker) => {
    const willDeactivate = worker.active !== false;
    const msg = willDeactivate
      ? `Deactivate ${worker.name}? They will lose POS access and your worker slot will be freed.`
      : `Reactivate ${worker.name}? This will use one of your worker slots.`;
    if (!confirm(msg)) return;

    try {
      const response = await fetch("/api/admin/workers", {
        method: "PATCH",
        headers: authHeaders(),
        body: JSON.stringify({
          userId: worker._id,
          active: !willDeactivate,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to update worker status");
      }
      toast.success(willDeactivate ? "Worker deactivated" : "Worker reactivated");
      await fetchWorkers();
    } catch (error) {
      toast.error(error.message || "Unable to update worker");
    }
  };

  const businessUsage = businesses.map((business) => {
    return {
      ...business,
      currentWorkers:
        business.currentWorkers ??
        workers.filter(
          (worker) =>
            worker.businessId === business._id && worker.active !== false,
        ).length,
    };
  });
  const canManageWorkers = true; // both owners and superadmins can manage workers

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  if (!admin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-primary">
                {isSuperAdmin() ? "Worker Overview" : "Manage Workers"}
              </h1>
              <p className="text-gray-500 mt-2">
                {isSuperAdmin()
                  ? "Super admin sets worker limits for each admin and can review worker allocation here."
                  : "Workers get dedicated POS access for walk-in bookings. Super admin controls the worker cap for each admin."}
              </p>
            </div>
            {canManageWorkers ? (
              <button
                onClick={() => setShowModal(true)}
                className="inline-flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors"
              >
                <span className="material-symbols-outlined">person_add</span>
                Add Worker
              </button>
            ) : (
              <Link
                href="/admin/register"
                className="inline-flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors"
              >
                <span className="material-symbols-outlined">person_add</span>
                Add Admins
              </Link>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
            {businessUsage.map((business) => (
              <div
                key={business._id}
                className="bg-white rounded-2xl shadow-md p-6 border border-gray-100"
              >
                <p className="text-xs uppercase tracking-wide text-gray-400 font-semibold">
                  {isSuperAdmin() ? "Admin Business" : "Your Business"}
                </p>
                <h2 className="text-xl font-semibold text-primary mt-2">
                  {business.name}
                </h2>
                <p className="text-sm text-gray-500 mt-2">
                  Worker usage: {business.currentWorkers}/{business.workerLimit || 2}
                </p>
                <div className="mt-4 h-2 rounded-full bg-gray-100 overflow-hidden">
                  <div
                    className="h-full bg-primary"
                    style={{
                      width: `${Math.min(
                        100,
                        ((business.currentWorkers || 0) /
                          Math.max(1, business.workerLimit || 2)) *
                          100,
                      )}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            {loading ? (
              <div className="p-8 text-center">
                <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                  progress_activity
                </span>
                <p className="text-gray-500 mt-2">Loading workers...</p>
              </div>
            ) : workers.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[860px]">
                  <thead className="bg-accent">
                    <tr>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Worker
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Business
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Contact
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Access
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Status
                      </th>
                      {canManageWorkers && (
                        <th className="text-right py-3 px-4 font-semibold text-primary">
                          Actions
                        </th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {workers.map((worker) => (
                      <tr key={worker._id} className="hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium text-gray-800">
                              {worker.name}
                            </p>
                            <p className="text-sm text-gray-500">{worker.email}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-gray-700">
                          {worker.businessName || "Unassigned"}
                        </td>
                        <td className="py-3 px-4 text-gray-700">
                          {worker.phone || "Phone not added"}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex flex-wrap gap-1">
                            {(Array.isArray(worker.posPermissions) ? worker.posPermissions : ["pos", "scan"]).map((perm) => (
                              <span key={perm} className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium capitalize">
                                {perm}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          {worker.active === false ? (
                            <span className="px-3 py-1 rounded-full bg-red-50 text-red-600 text-sm font-medium">
                              Inactive
                            </span>
                          ) : (
                            <span className="px-3 py-1 rounded-full bg-green-50 text-green-700 text-sm font-medium">
                              Active
                            </span>
                          )}
                        </td>
                        {canManageWorkers && (
                          <td className="py-3 px-4">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleEdit(worker)}
                                className="p-2 text-primary hover:bg-accent rounded-lg transition-colors"
                                title="Edit"
                              >
                                <span className="material-symbols-outlined">edit</span>
                              </button>
                              <button
                                onClick={() => handleDeactivate(worker)}
                                className={`p-2 rounded-lg transition-colors ${
                                  worker.active === false
                                    ? "text-green-600 hover:bg-green-50"
                                    : "text-amber-500 hover:bg-amber-50"
                                }`}
                                title={worker.active === false ? "Reactivate" : "Deactivate"}
                              >
                                <span className="material-symbols-outlined">
                                  {worker.active === false ? "toggle_on" : "toggle_off"}
                                </span>
                              </button>
                              {isSuperAdmin() && (
                                <button
                                  onClick={() => handleDelete(worker._id)}
                                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                  title="Permanently Delete"
                                >
                                  <span className="material-symbols-outlined">delete_forever</span>
                                </button>
                              )}
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-10 text-center">
                <span className="material-symbols-outlined text-5xl text-gray-300">
                  groups
                </span>
                <p className="text-gray-500 mt-3">
                  {isSuperAdmin()
                    ? "No workers have been assigned under any admin yet"
                    : "No workers assigned yet"}
                </p>
              </div>
            )}
          </div>

          {showModal && canManageWorkers && (
            <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full">
                <div className="p-6 border-b flex items-start justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-semibold text-primary">
                      {editingWorker ? "Edit Worker" : "Add Worker"}
                    </h2>
                    <p className="text-sm text-gray-500 mt-1">
                      Workers can access only their assigned POS workspace.
                    </p>
                  </div>
                  <button
                    onClick={resetForm}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Business
                    </label>
                    <select
                      value={formData.businessId}
                      onChange={(event) =>
                        setFormData((prev) => ({
                          ...prev,
                          businessId: event.target.value,
                        }))
                      }
                      disabled={!isSuperAdmin()}
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 disabled:bg-gray-50"
                    >
                      {businesses.map((business) => (
                        <option key={business._id} value={business._id}>
                          {business.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <InputField
                      label="Full Name"
                      value={formData.name}
                      onChange={(value) =>
                        setFormData((prev) => ({ ...prev, name: value }))
                      }
                      required
                    />
                    <InputField
                      label="Phone"
                      value={formData.phone}
                      onChange={(value) =>
                        setFormData((prev) => ({ ...prev, phone: value }))
                      }
                    />
                    <InputField
                      label="Email"
                      type="email"
                      value={formData.email}
                      onChange={(value) =>
                        setFormData((prev) => ({ ...prev, email: value }))
                      }
                      required
                    />
                    <InputField
                      label={editingWorker ? "Reset Password" : "Password"}
                      type="password"
                      value={formData.password}
                      onChange={(value) =>
                        setFormData((prev) => ({ ...prev, password: value }))
                      }
                      placeholder={
                        editingWorker ? "Leave blank to keep current password" : ""
                      }
                    />
                  </div>

                  {/* POS Permissions */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      POS Permissions
                    </label>
                    <div className="flex gap-4">
                      {["pos", "scan"].map((perm) => (
                        <label key={perm} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formData.posPermissions?.includes(perm)}
                            onChange={() => {
                              setFormData((prev) => {
                                const current = prev.posPermissions || [];
                                const next = current.includes(perm)
                                  ? current.filter((p) => p !== perm)
                                  : [...current, perm];
                                return { ...prev, posPermissions: next };
                              });
                            }}
                            className="h-4 w-4 accent-primary"
                          />
                          <span className="text-sm capitalize font-medium text-gray-700">
                            {perm === "pos" ? "POS Terminal" : "Scan Tickets"}
                          </span>
                        </label>
                      ))}
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      Controls which buttons the worker sees on login
                    </p>
                  </div>

                  <div className="flex gap-3 pt-4 border-t">
                    <button
                      type="button"
                      onClick={resetForm}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-60"
                    >
                      {saving
                        ? "Saving..."
                        : editingWorker
                          ? "Update Worker"
                          : "Create Worker"}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InputField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  ...rest
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
        {...rest}
      />
    </div>
  );
}
