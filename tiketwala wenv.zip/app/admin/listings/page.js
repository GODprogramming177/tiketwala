"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import {
  CATEGORY_ORDER,
  CATEGORY_SUGGESTED_SUBCATEGORIES,
  getCategoryLabel,
  slugifyName,
} from "@/lib/listingUtils";
import { getTypeIcon } from "@/lib/typeIcons";
import { getCategoryConfig } from "@/lib/categoryConfig";
import { downloadStyledQR } from "@/components/StyledQR";
import SeatMatrixBuilder from "@/components/SeatMatrixBuilder";

function generateId() {
  return (
    "id_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
  );
}

function createEmptyAddOn() {
  return {
    id: generateId(),
    name: "",
    description: "",
    price: "",
    chargeType: "per_booking",
    optional: true,
  };
}

function createAgeFareTier({
  id = generateId(),
  label = "",
  minAge = "",
  maxAge = "",
  fare = "",
  isFree = false,
} = {}) {
  return {
    id,
    label: String(label || ""),
    minAge: String(minAge ?? ""),
    maxAge: maxAge === null || maxAge === undefined ? "" : String(maxAge),
    fare: isFree ? "0" : String(fare ?? ""),
    isFree: Boolean(isFree),
  };
}

function createDefaultFareRules() {
  return {
    enabled: false,
    freeBelowAge: 5,
    adultAgeFrom: 18,
    ageTiers: [
      createAgeFareTier({
        label: "Under 5",
        minAge: 0,
        maxAge: 4,
        fare: 0,
        isFree: true,
      }),
      createAgeFareTier({
        label: "Child",
        minAge: 5,
        maxAge: 17,
        fare: "",
      }),
      createAgeFareTier({
        label: "Adult",
        minAge: 18,
        maxAge: "",
        fare: "",
      }),
    ],
  };
}

function createEmptySubCategory() {
  return {
    id: generateId(),
    name: "",
    price: "",
    childPrice: "",
    description: "",
    addOns: [createEmptyAddOn()],
  };
}

function createEmptyImages() {
  return [""];
}

function parseAge(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.floor(parsed) : null;
}

function sanitizeAgeTiers(rawAgeTiers = []) {
  if (!Array.isArray(rawAgeTiers)) {
    return [];
  }

  return rawAgeTiers
    .map((tier, index) => {
      const minAge = parseAge(tier?.minAge);
      if (minAge === null || minAge < 0) {
        return null;
      }

      const hasMaxAge =
        tier?.maxAge !== null &&
        tier?.maxAge !== undefined &&
        tier?.maxAge !== "";
      const maxAge = hasMaxAge ? parseAge(tier?.maxAge) : null;
      if (hasMaxAge && (maxAge === null || maxAge < minAge)) {
        return null;
      }

      const isFree = Boolean(tier?.isFree);
      const fareValue = Number(tier?.fare);
      if (!isFree && (!Number.isFinite(fareValue) || fareValue < 0)) {
        return null;
      }

      return {
        id:
          String(tier?.id || `tier_${index + 1}`).trim() || `tier_${index + 1}`,
        label: String(tier?.label || "").trim(),
        minAge,
        maxAge: hasMaxAge ? maxAge : null,
        fare: isFree ? 0 : Math.round(fareValue),
        isFree,
      };
    })
    .filter(Boolean)
    .sort((a, b) => {
      if (a.minAge !== b.minAge) {
        return a.minAge - b.minAge;
      }
      if (a.maxAge === null && b.maxAge !== null) {
        return 1;
      }
      if (a.maxAge !== null && b.maxAge === null) {
        return -1;
      }
      return (a.maxAge ?? 0) - (b.maxAge ?? 0);
    });
}

function deriveLegacyBounds(ageTiers = []) {
  if (!Array.isArray(ageTiers) || ageTiers.length === 0) {
    return { freeBelowAge: 5, adultAgeFrom: 18 };
  }

  const freeTier = ageTiers.find(
    (tier) => tier.isFree && tier.minAge === 0 && Number.isFinite(tier.maxAge),
  );
  const adultTier =
    [...ageTiers].reverse().find((tier) => tier.maxAge === null) ||
    ageTiers[ageTiers.length - 1];

  const freeBelowAge = freeTier ? Number(freeTier.maxAge) + 1 : 5;
  const adultAgeFrom = Math.max(freeBelowAge + 1, adultTier?.minAge ?? 18);

  return { freeBelowAge, adultAgeFrom };
}

function sanitizeSubCategories(rawSubCategories = []) {
  if (!Array.isArray(rawSubCategories)) {
    return [];
  }

  return rawSubCategories
    .map((sub) => {
      const name = String(sub?.name || "").trim();
      const price = Number(sub?.price);
      const childPrice = Number(sub?.childPrice);
      const description = String(sub?.description || "").trim();

      if (!name || !Number.isFinite(price) || price < 0) {
        return null;
      }

      const addOns = Array.isArray(sub?.addOns)
        ? sub.addOns
            .map((addOn) => {
              const addOnName = String(addOn?.name || "").trim();
              const addOnPrice = Number(addOn?.price);
              if (
                !addOnName ||
                !Number.isFinite(addOnPrice) ||
                addOnPrice < 0
              ) {
                return null;
              }
              return {
                id: addOn?.id || generateId(),
                name: addOnName,
                description: String(addOn?.description || "").trim(),
                price: Math.round(addOnPrice),
                chargeType:
                  addOn?.chargeType === "per_person"
                    ? "per_person"
                    : "per_booking",
                optional: addOn?.optional !== false,
              };
            })
            .filter(Boolean)
        : [];

      return {
        id: sub?.id || generateId(),
        name,
        image: String(sub?.image || "").trim(),
        price: Math.round(price),
        childPrice:
          Number.isFinite(childPrice) && childPrice >= 0
            ? Math.round(childPrice)
            : null,
        description,
        addOns,
      };
    })
    .filter(Boolean);
}

function computeStartingPrice(subCategories = [], fallback = 0) {
  const prices = (Array.isArray(subCategories) ? subCategories : [])
    .map((sub) => Number(sub?.price))
    .filter((price) => Number.isFinite(price) && price >= 0);
  if (prices.length === 0) {
    return Math.max(0, Number(fallback) || 0);
  }
  return Math.min(...prices);
}

export default function AdminListingsPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    isSuperAdmin,
    authHeaders,
    getBusinessId,
  } = useAdminAuth();

  const [listings, setListings] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingListing, setEditingListing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    businessId: "",
    name: "",
    type: "park",
    location: "",
    description: "",
    price: "",
    images: createEmptyImages(),
    fareRules: createDefaultFareRules(),
    subCategories: [createEmptySubCategory()],
    seating: null,
    hasSeatMatrix: false,
  });

  useEffect(() => {
    if (!authLoading && !admin) {
      router.push("/admin/login");
    }
  }, [admin, authLoading, router]);

  useEffect(() => {
    if (!admin) return;
    fetchBusinesses();
    fetchListings();
  }, [admin]);

  const selectedBusiness = useMemo(
    () => businesses.find((business) => business._id === formData.businessId),
    [businesses, formData.businessId],
  );

  const allowedTypes = useMemo(() => {
    const configured = selectedBusiness?.allowedListingTypes;
    if (Array.isArray(configured) && configured.length > 0) {
      return configured.filter((type) => CATEGORY_ORDER.includes(type));
    }
    return CATEGORY_ORDER;
  }, [selectedBusiness]);

  const startingPricePreview = useMemo(
    () => computeStartingPrice(formData.subCategories, formData.price),
    [formData.subCategories, formData.price],
  );

  const previewImages = useMemo(
    () => formData.images.map((image) => image.trim()).filter(Boolean),
    [formData.images],
  );

  const previewAgeTierSummary = useMemo(() => {
    const tiers = sanitizeAgeTiers(formData.fareRules?.ageTiers || []);
    if (tiers.length === 0) {
      return "Add at least one valid age range.";
    }
    return tiers
      .map((tier) => {
        const range =
          tier.maxAge === null
            ? `${tier.minAge}+`
            : `${tier.minAge}-${tier.maxAge}`;
        return `${tier.label || range}: ${tier.isFree ? "Free" : `₹${tier.fare}`}`;
      })
      .join(" | ");
  }, [formData.fareRules?.ageTiers]);

  useEffect(() => {
    if (allowedTypes.length === 0) return;
    if (!allowedTypes.includes(formData.type)) {
      setFormData((prev) => ({ ...prev, type: allowedTypes[0] }));
    }
  }, [allowedTypes, formData.type]);

  const getDefaultBusinessId = () =>
    isSuperAdmin()
      ? businesses[0]?._id || ""
      : getBusinessId() || businesses[0]?._id || "";

  const resetForm = () => {
    setShowModal(false);
    setEditingListing(null);
    setFormData({
      businessId: getDefaultBusinessId(),
      name: "",
      type: allowedTypes[0] || "park",
      location: "",
      description: "",
      price: "",
      images: createEmptyImages(),
      fareRules: createDefaultFareRules(),
      subCategories: [createEmptySubCategory()],
      seating: null,
      hasSeatMatrix: false,
    });
  };

  const openCreateModal = () => {
    setEditingListing(null);
    setFormData({
      businessId: getDefaultBusinessId(),
      name: "",
      type: allowedTypes[0] || "park",
      location: "",
      description: "",
      price: "",
      images: createEmptyImages(),
      fareRules: createDefaultFareRules(),
      subCategories: [createEmptySubCategory()],
      seating: null,
      hasSeatMatrix: false,
    });
    setShowModal(true);
  };

  const fetchBusinesses = async () => {
    try {
      const response = await fetch("/api/superadmin/businesses", {
        headers: authHeaders(),
      });
      const data = await response.json();
      const items = Array.isArray(data.businesses) ? data.businesses : [];
      setBusinesses(items);

      const defaultBusinessId = isSuperAdmin()
        ? items[0]?._id || ""
        : getBusinessId() || items[0]?._id || "";

      setFormData((prev) => ({
        ...prev,
        businessId: prev.businessId || defaultBusinessId,
      }));
    } catch (error) {
      console.error("Failed to fetch businesses:", error);
    }
  };

  const fetchListings = async () => {
    try {
      let url = "/api/listings";
      if (!isSuperAdmin() && admin?.id) {
        url += `?ownerId=${admin.id}`;
      }
      const response = await fetch(url, { headers: authHeaders() });
      const data = await response.json();
      setListings(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch listings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const subCategories = sanitizeSubCategories(formData.subCategories);
    if (subCategories.length === 0) {
      toast.error("Add at least one valid sub-category with a base price");
      return;
    }

    const ageTiers = sanitizeAgeTiers(formData.fareRules?.ageTiers);
    if (Boolean(formData.fareRules?.enabled) && ageTiers.length === 0) {
      toast.error("Add at least one valid age fare range");
      return;
    }

    const { freeBelowAge, adultAgeFrom } = deriveLegacyBounds(ageTiers);
    const payload = {
      businessId: formData.businessId || getDefaultBusinessId(),
      name: String(formData.name || "").trim(),
      type: formData.type,
      address: String(formData.location || "").trim(),
      shortDesc: String(formData.description || "").trim(),
      price: computeStartingPrice(subCategories, formData.price),
      images: formData.images.map((image) => image.trim()).filter(Boolean),
      fareRules: {
        enabled: Boolean(formData.fareRules?.enabled),
        freeBelowAge,
        adultAgeFrom,
        ageTiers,
      },
      subCategories,
      addOns: [],
      seating: formData.hasSeatMatrix ? formData.seating : { rows: 0, cols: 0, seats: [] },
    };

    if (!payload.businessId) {
      toast.error("No business selected for this listing");
      return;
    }

    setSaving(true);
    try {
      const response = await fetch("/api/listings", {
        method: editingListing ? "PUT" : "POST",
        headers: authHeaders(),
        body: JSON.stringify(
          editingListing ? { id: editingListing.id, ...payload } : payload,
        ),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to save listing");
      }

      toast.success(editingListing ? "Listing updated" : "Listing created");
      await fetchListings();
      resetForm();
    } catch (error) {
      toast.error(error.message || "Unable to save listing");
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (listing) => {
    const rawSubCategories =
      Array.isArray(listing.subCategories) && listing.subCategories.length > 0
        ? listing.subCategories
        : [
            {
              id: generateId(),
              name: `${getCategoryLabel(listing.category || listing.type)} Entry`,
              price: listing.price || 0,
              childPrice: listing.pricing?.child || 0,
              description: listing.description || "",
              addOns: Array.isArray(listing.addOns) ? listing.addOns : [],
            },
          ];

    const subCategories = rawSubCategories.map((sub) => ({
      id: sub.id || generateId(),
      name: sub.name || "",
      image: sub.image || "",
      price: String(sub.price ?? ""),
      childPrice:
        sub.childPrice === null || sub.childPrice === undefined
          ? ""
          : String(sub.childPrice),
      description: sub.description || "",
      addOns:
        Array.isArray(sub.addOns) && sub.addOns.length > 0
          ? sub.addOns.map((addOn) => ({
              id: addOn.id || generateId(),
              name: addOn.name || "",
              description: addOn.description || "",
              price: String(addOn.price ?? ""),
              chargeType:
                addOn.chargeType === "per_person"
                  ? "per_person"
                  : "per_booking",
              optional: addOn.optional !== false,
            }))
          : [createEmptyAddOn()],
    }));

    const ageTiers =
      Array.isArray(listing.fareRules?.ageTiers) &&
      listing.fareRules.ageTiers.length > 0
        ? listing.fareRules.ageTiers.map((tier) =>
            createAgeFareTier({
              id: tier.id || generateId(),
              label: tier.label || "",
              minAge: tier.minAge,
              maxAge: tier.maxAge,
              fare: tier.isFree ? 0 : tier.fare,
              isFree: Boolean(tier.isFree),
            }),
          )
        : createDefaultFareRules().ageTiers;

    setEditingListing(listing);
    setFormData({
      businessId: listing.businessId || getDefaultBusinessId(),
      name: listing.name || "",
      type: listing.category || listing.type?.toLowerCase() || "park",
      location: listing.location || "",
      description: listing.description || "",
      price: String(listing.price || ""),
      images:
        Array.isArray(listing.storedImages) && listing.storedImages.length > 0
          ? listing.storedImages
          : Array.isArray(listing.images) && listing.images.length > 0
            ? listing.images
            : listing.image
              ? [listing.image]
              : createEmptyImages(),
      fareRules: {
        enabled: Boolean(listing.fareRules?.enabled),
        freeBelowAge: Number(listing.fareRules?.freeBelowAge) || 5,
        adultAgeFrom: Number(listing.fareRules?.adultAgeFrom) || 18,
        ageTiers,
      },
      subCategories,
      seating: listing.seating || null,
      hasSeatMatrix: Boolean(listing.seating && listing.seating.rows > 0),
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this listing?")) {
      return;
    }

    try {
      const response = await fetch(`/api/listings?id=${id}`, {
        method: "DELETE",
        headers: authHeaders(),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to delete listing");
      }
      toast.success("Listing deleted");
      await fetchListings();
    } catch (error) {
      toast.error(error.message || "Unable to delete listing");
    }
  };

  const handleCopyPublicBookingLink = async (listing) => {
    const publicUrl = `${window.location.origin}/booking/${listing.id}`;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(publicUrl);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = publicUrl;
        textArea.style.position = "fixed";
        textArea.style.opacity = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
      }
      toast.success("Public booking link copied");
    } catch {
      toast.error("Unable to copy booking link");
    }
  };

  const handleDownloadPublicQr = async (listing) => {
    try {
      const publicUrl = `${window.location.origin}/booking/${listing.id}`;
      const baseName = slugifyName(listing.name) || "listing";
      await downloadStyledQR(publicUrl, `${baseName}-public-qr.png`, {
        size: 900,
        showLogo: true,
        dotsColor: "#111827",
        cornerSquareColor: "#111827",
        cornerDotColor: "#111827",
        dotsType: "square",
        imageSize: 0.16,
      });
      toast.success("Public booking QR downloaded");
    } catch {
      toast.error("Unable to download public QR");
    }
  };

  const updateField = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const updateSubCategory = (subIndex, key, value) => {
    setFormData((prev) => ({
      ...prev,
      subCategories: prev.subCategories.map((sub, index) =>
        index === subIndex ? { ...sub, [key]: value } : sub,
      ),
    }));
  };

  const addSubCategory = () => {
    setFormData((prev) => ({
      ...prev,
      subCategories: [...prev.subCategories, createEmptySubCategory()],
    }));
  };

  const removeSubCategory = (subIndex) => {
    setFormData((prev) => ({
      ...prev,
      subCategories:
        prev.subCategories.length === 1
          ? [createEmptySubCategory()]
          : prev.subCategories.filter((_, index) => index !== subIndex),
    }));
  };

  const updateSubCategoryAddOn = (subIndex, addOnIndex, key, value) => {
    setFormData((prev) => ({
      ...prev,
      subCategories: prev.subCategories.map((sub, index) => {
        if (index !== subIndex) {
          return sub;
        }
        return {
          ...sub,
          addOns: sub.addOns.map((addOn, addOnPos) =>
            addOnPos === addOnIndex ? { ...addOn, [key]: value } : addOn,
          ),
        };
      }),
    }));
  };

  const addSubCategoryAddOn = (subIndex) => {
    setFormData((prev) => ({
      ...prev,
      subCategories: prev.subCategories.map((sub, index) =>
        index === subIndex
          ? { ...sub, addOns: [...sub.addOns, createEmptyAddOn()] }
          : sub,
      ),
    }));
  };

  const removeSubCategoryAddOn = (subIndex, addOnIndex) => {
    setFormData((prev) => ({
      ...prev,
      subCategories: prev.subCategories.map((sub, index) => {
        if (index !== subIndex) {
          return sub;
        }
        const nextAddOns = sub.addOns.filter((_, pos) => pos !== addOnIndex);
        return {
          ...sub,
          addOns: nextAddOns.length > 0 ? nextAddOns : [createEmptyAddOn()],
        };
      }),
    }));
  };

  const updateAgeTier = (tierIndex, key, value) => {
    setFormData((prev) => ({
      ...prev,
      fareRules: {
        ...prev.fareRules,
        ageTiers: (prev.fareRules?.ageTiers || []).map((tier, index) => {
          if (index !== tierIndex) {
            return tier;
          }
          if (key === "isFree") {
            return {
              ...tier,
              isFree: Boolean(value),
              fare: Boolean(value) ? "0" : tier.fare,
            };
          }
          return {
            ...tier,
            [key]: value,
          };
        }),
      },
    }));
  };

  const addAgeTier = () => {
    setFormData((prev) => ({
      ...prev,
      fareRules: {
        ...prev.fareRules,
        ageTiers: [...(prev.fareRules?.ageTiers || []), createAgeFareTier()],
      },
    }));
  };

  const removeAgeTier = (tierIndex) => {
    setFormData((prev) => {
      const nextAgeTiers = (prev.fareRules?.ageTiers || []).filter(
        (_, index) => index !== tierIndex,
      );
      return {
        ...prev,
        fareRules: {
          ...prev.fareRules,
          ageTiers:
            nextAgeTiers.length > 0 ? nextAgeTiers : [createAgeFareTier()],
        },
      };
    });
  };

  const updateImage = (imageIndex, value) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.map((image, index) =>
        index === imageIndex ? value : image,
      ),
    }));
  };

  const addImage = () => {
    setFormData((prev) => ({
      ...prev,
      images: [...prev.images, ""],
    }));
  };

  const removeImage = (imageIndex) => {
    setFormData((prev) => ({
      ...prev,
      images:
        prev.images.length === 1
          ? createEmptyImages()
          : prev.images.filter((_, index) => index !== imageIndex),
    }));
  };

  const loadSuggestedSubCategories = () => {
    const suggested = CATEGORY_SUGGESTED_SUBCATEGORIES[formData.type] || [];
    if (suggested.length === 0) {
      return;
    }

    setFormData((prev) => ({
      ...prev,
      subCategories: suggested.map((item) => ({
        id: generateId(),
        name: item.name,
        price: String(item.price ?? ""),
        childPrice: String(
          Math.max(0, Math.round((Number(item.price) || 0) * 0.6)),
        ),
        description: item.description || "",
        addOns:
          Array.isArray(item.addOns) && item.addOns.length > 0
            ? item.addOns.map((addOn) => ({
                id: generateId(),
                name: addOn.name,
                description: "",
                price: String(addOn.price ?? ""),
                chargeType:
                  addOn.chargeType === "per_person"
                    ? "per_person"
                    : "per_booking",
                optional: true,
              }))
            : [createEmptyAddOn()],
      })),
    }));
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  if (!admin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-primary">
                Manage Listings
              </h1>
              <p className="text-gray-500 mt-1">
                Configure your listing fare scheme with sub-categories, child
                fares, and add-ons.
              </p>
            </div>
            <button
              onClick={openCreateModal}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
            >
              <span className="material-symbols-outlined">add</span>
              Add Listing
            </button>
          </div>

          {selectedBusiness && (
            <div className="mb-6 bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
                <InfoPill
                  icon="business"
                  label="Business"
                  value={selectedBusiness.name || "-"}
                />
                <InfoPill
                  icon="inventory_2"
                  label="Allowed Types"
                  value={
                    (selectedBusiness.allowedListingTypes || [])
                      .map((type) => getCategoryLabel(type))
                      .join(", ") || "All"
                  }
                />
                <InfoPill
                  icon="format_list_numbered"
                  label="Listing Limit"
                  value={
                    selectedBusiness.listingLimit
                      ? `${selectedBusiness.propertyCount || 0}/${selectedBusiness.listingLimit}`
                      : "Unlimited"
                  }
                />
              </div>
            </div>
          )}

          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            {loading ? (
              <div className="p-8 text-center">
                <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                  progress_activity
                </span>
                <p className="text-gray-500 mt-2">Loading listings...</p>
              </div>
            ) : listings.length === 0 ? (
              <div className="p-8 text-center">
                <span className="material-symbols-outlined text-6xl text-gray-300">
                  inventory_2
                </span>
                <p className="text-xl text-gray-500 mt-4">No listings yet</p>
                <p className="text-gray-400">Create your first listing.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-245">
                  <thead className="bg-accent">
                    <tr>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Name
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Type
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Location
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Pricing Scheme
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Starting Price
                      </th>
                      <th className="text-right py-3 px-4 font-semibold text-primary">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {listings.map((listing) => (
                      <tr key={listing.id} className="hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={listing.images?.[0] || listing.image}
                              alt={listing.name}
                              className="w-12 h-12 rounded-xl object-cover"
                            />
                            <div>
                              <p className="font-medium text-gray-800">
                                {listing.name}
                              </p>
                              <p className="text-xs text-gray-500 truncate max-w-64">
                                {listing.description}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-1 bg-accent rounded text-sm text-primary inline-flex items-center gap-1">
                            <span className="material-symbols-outlined text-base">
                              {getTypeIcon(listing.type)}
                            </span>
                            {listing.type}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {listing.location}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-700">
                          <p>
                            {Array.isArray(listing.subCategories)
                              ? `${listing.subCategories.length} sub-categories`
                              : "No sub-categories"}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {listing.fareRules?.enabled
                              ? "Age-tier pricing enabled"
                              : "Flat pricing"}
                          </p>
                        </td>
                        <td className="py-3 px-4 text-primary font-semibold">
                          ₹{listing.price}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() =>
                                handleCopyPublicBookingLink(listing)
                              }
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg transition-colors"
                            >
                              <span className="material-symbols-outlined text-base">
                                link
                              </span>
                              Copy Link
                            </button>
                            <button
                              onClick={() => handleDownloadPublicQr(listing)}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
                            >
                              <span className="material-symbols-outlined text-base">
                                qr_code_2
                              </span>
                              Public QR
                            </button>
                            <button
                              onClick={() => handleEdit(listing)}
                              className="p-2 text-primary hover:bg-accent rounded-lg transition-colors"
                            >
                              <span className="material-symbols-outlined">
                                edit
                              </span>
                            </button>
                            <button
                              onClick={() => handleDelete(listing.id)}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <span className="material-symbols-outlined">
                                delete
                              </span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {showModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[92vh] overflow-y-auto">
                <div className="p-6 border-b sticky top-0 bg-white z-10 rounded-t-2xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-xl font-semibold text-primary">
                        {editingListing ? "Edit Listing" : "Add New Listing"}
                      </h2>
                      <p className="text-sm text-gray-500 mt-1">
                        Configure the fare scheme for each sub-category.
                      </p>
                    </div>
                    <button
                      onClick={resetForm}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <span className="material-symbols-outlined">close</span>
                    </button>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Business
                      </label>
                      <select
                        required
                        value={formData.businessId}
                        onChange={(event) =>
                          updateField("businessId", event.target.value)
                        }
                        disabled={!isSuperAdmin()}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 disabled:bg-gray-50 disabled:text-gray-500"
                      >
                        {businesses.map((business) => (
                          <option key={business._id} value={business._id}>
                            {business.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Primary Category
                      </label>
                      <select
                        value={formData.type}
                        onChange={(event) =>
                          updateField("type", event.target.value)
                        }
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
                      >
                        {allowedTypes.map((type) => (
                          <option key={type} value={type}>
                            {getCategoryLabel(type)}
                          </option>
                        ))}
                      </select>
                    </div>

                    <InputField
                      label="Listing Name"
                      value={formData.name}
                      onChange={(value) => updateField("name", value)}
                      placeholder="Enter listing name"
                      required
                    />

                    <InputField
                      label="Location"
                      value={formData.location}
                      onChange={(value) => updateField("location", value)}
                      placeholder="City, State"
                      required
                    />
                  </div>

                  {formData.type && (
                    <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                      <div className="flex gap-3">
                        <span className="material-symbols-outlined text-amber-600 shrink-0">
                          {getCategoryConfig(formData.type)?.icon || "info"}
                        </span>
                        <div className="text-sm">
                          <p className="font-semibold text-amber-900">
                            {getCategoryConfig(formData.type)?.name}
                          </p>
                          <p className="text-amber-700 text-xs mt-1">
                            {getCategoryConfig(formData.type)?.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      required
                      value={formData.description}
                      onChange={(event) =>
                        updateField("description", event.target.value)
                      }
                      rows={3}
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
                      placeholder="Brief description"
                    />
                  </div>

                  {(formData.type === "cinema" || formData.type === "event") && (
                    <div className="rounded-2xl border border-gray-200 p-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-base font-semibold text-primary">
                            Seat Matrix Configuration
                          </h3>
                          <p className="text-sm text-gray-500 mt-1">
                            Configure the interactive seating layout for customers.
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => updateField("hasSeatMatrix", !formData.hasSeatMatrix)}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            formData.hasSeatMatrix ? "bg-primary" : "bg-gray-300"
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              formData.hasSeatMatrix ? "translate-x-6" : "translate-x-1"
                            }`}
                          />
                        </button>
                      </div>
                      
                      {formData.hasSeatMatrix && (
                        <SeatMatrixBuilder
                          initialSeating={formData.seating}
                          onChange={(seating) => updateField("seating", seating)}
                        />
                      )}
                    </div>
                  )}

                  <div className="rounded-2xl border border-gray-200 p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-base font-semibold text-primary">
                          {formData.type === "cinema" ? "Movies Configuration" : "Fare Scheme"}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {formData.type === "cinema" 
                            ? "Add movies and set their base fares." 
                            : "Set base fare and child fare per ticket type."}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        {(CATEGORY_SUGGESTED_SUBCATEGORIES[formData.type] || [])
                          .length > 0 && (
                          <button
                            type="button"
                            onClick={loadSuggestedSubCategories}
                            className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-amber-50 text-amber-700 border border-amber-200 rounded-lg hover:bg-amber-100 transition-colors"
                          >
                            <span className="material-symbols-outlined text-base">
                              auto_fix_high
                            </span>
                            Load Suggestions
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={addSubCategory}
                          className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-primary/10 text-primary rounded-lg hover:bg-primary/15 transition-colors"
                        >
                          <span className="material-symbols-outlined text-base">
                            add
                          </span>
                          {formData.type === "cinema" ? "Add Movie" : "Add Sub-Category"}
                        </button>
                      </div>
                    </div>

                    <div className="rounded-xl border border-primary/10 bg-primary/5 px-4 py-3 text-sm text-primary">
                      Starting listing price will be auto-calculated from the
                      lowest sub-category base fare: ₹{startingPricePreview}
                    </div>

                    <div className="space-y-4">
                      {formData.subCategories.map((sub, subIndex) => (
                        <div
                          key={sub.id || `sub-${subIndex}`}
                          className="rounded-2xl border border-gray-200 overflow-hidden"
                        >
                          <div className="px-4 py-3 bg-accent/50 flex items-center justify-between">
                            <p className="text-sm font-semibold text-primary">
                              {formData.type === "cinema" ? "Movie" : "Sub-Category"} {subIndex + 1}
                            </p>
                            <button
                              type="button"
                              onClick={() => removeSubCategory(subIndex)}
                              className="text-red-500 hover:text-red-700 text-sm inline-flex items-center gap-1"
                            >
                              <span className="material-symbols-outlined text-base">
                                delete
                              </span>
                              Remove
                            </button>
                          </div>

                          <div className="p-4 space-y-4">
                            <div className={`grid grid-cols-1 sm:grid-cols-2 ${formData.type === "cinema" ? "lg:grid-cols-5" : "lg:grid-cols-4"} gap-3`}>
                              <InputField
                                label={formData.type === "cinema" ? "Movie Name" : "Name"}
                                value={sub.name}
                                onChange={(value) =>
                                  updateSubCategory(subIndex, "name", value)
                                }
                                placeholder={formData.type === "cinema" ? "e.g. Avengers: Endgame" : "e.g. Entry Ticket"}
                                required
                              />
                              {formData.type === "cinema" && (
                                <InputField
                                  label="Image URL"
                                  value={sub.image || ""}
                                  onChange={(value) =>
                                    updateSubCategory(subIndex, "image", value)
                                  }
                                  placeholder="https://..."
                                />
                              )}
                              <InputField
                                label="Base Fare (₹)"
                                type="number"
                                value={sub.price}
                                onChange={(value) =>
                                  updateSubCategory(subIndex, "price", value)
                                }
                                min="0"
                                placeholder="80"
                                required
                              />
                              <InputField
                                label="Child Fare (₹)"
                                type="number"
                                value={sub.childPrice}
                                onChange={(value) =>
                                  updateSubCategory(
                                    subIndex,
                                    "childPrice",
                                    value,
                                  )
                                }
                                min="0"
                                placeholder="40"
                              />
                              <InputField
                                label="Description"
                                value={sub.description}
                                onChange={(value) =>
                                  updateSubCategory(
                                    subIndex,
                                    "description",
                                    value,
                                  )
                                }
                                placeholder="Brief description"
                              />
                            </div>

                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <p className="text-sm font-medium text-gray-600">
                                  Add-ons for {sub.name || "this sub-category"}
                                </p>
                                <button
                                  type="button"
                                  onClick={() => addSubCategoryAddOn(subIndex)}
                                  className="text-sm text-primary hover:text-primary/80 inline-flex items-center gap-1"
                                >
                                  <span className="material-symbols-outlined text-base">
                                    add
                                  </span>
                                  Add-on
                                </button>
                              </div>

                              {sub.addOns.map((addOn, addOnIndex) => (
                                <div
                                  key={addOn.id || `addon-${addOnIndex}`}
                                  className="grid grid-cols-1 sm:grid-cols-[1fr_120px_150px_auto] gap-2 bg-gray-50 rounded-xl p-3"
                                >
                                  <InputField
                                    label="Add-on Name"
                                    value={addOn.name}
                                    onChange={(value) =>
                                      updateSubCategoryAddOn(
                                        subIndex,
                                        addOnIndex,
                                        "name",
                                        value,
                                      )
                                    }
                                    placeholder="e.g. Parking"
                                  />
                                  <InputField
                                    label="Price"
                                    type="number"
                                    value={addOn.price}
                                    onChange={(value) =>
                                      updateSubCategoryAddOn(
                                        subIndex,
                                        addOnIndex,
                                        "price",
                                        value,
                                      )
                                    }
                                    min="0"
                                    placeholder="50"
                                  />
                                  <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">
                                      Charge Type
                                    </label>
                                    <select
                                      value={addOn.chargeType || "per_booking"}
                                      onChange={(event) =>
                                        updateSubCategoryAddOn(
                                          subIndex,
                                          addOnIndex,
                                          "chargeType",
                                          event.target.value,
                                        )
                                      }
                                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
                                    >
                                      <option value="per_booking">
                                        Per Booking
                                      </option>
                                      <option value="per_person">
                                        Per Person
                                      </option>
                                    </select>
                                  </div>
                                  <div className="flex items-end">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        removeSubCategoryAddOn(
                                          subIndex,
                                          addOnIndex,
                                        )
                                      }
                                      className="w-full px-3 py-2 border border-red-200 text-red-600 rounded-lg hover:bg-red-50 transition-colors text-sm"
                                    >
                                      Remove
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-base font-semibold text-primary">
                          Gallery
                        </h3>
                        <p className="text-sm text-gray-500">
                          Optional image URLs.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={addImage}
                        className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-primary/10 text-primary rounded-lg hover:bg-primary/15 transition-colors"
                      >
                        <span className="material-symbols-outlined text-base">
                          add_photo_alternate
                        </span>
                        Add Image
                      </button>
                    </div>

                    <div className="space-y-3">
                      {formData.images.map((image, index) => (
                        <div
                          key={`image-${index}`}
                          className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-3"
                        >
                          <InputField
                            label={`Image URL ${index + 1}`}
                            type="url"
                            value={image}
                            onChange={(value) => updateImage(index, value)}
                            placeholder="https://images.unsplash.com/..."
                          />
                          <div className="flex items-end">
                            <button
                              type="button"
                              onClick={() => removeImage(index)}
                              className="w-full sm:w-auto px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {previewImages.length > 0 && (
                      <div className="rounded-2xl border border-gray-200 overflow-hidden">
                        <div className="px-4 py-3 bg-gray-50 text-sm font-medium text-gray-600">
                          Gallery Preview
                        </div>
                        <div className="grid grid-cols-2 gap-3 p-4">
                          {previewImages.slice(0, 4).map((image, index) => (
                            <img
                              key={`${image}-${index}`}
                              src={image}
                              alt={`Preview ${index + 1}`}
                              className="w-full h-40 object-cover rounded-xl"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-3 pt-4 border-t">
                    <button
                      type="button"
                      onClick={resetForm}
                      className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="flex-1 px-4 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors inline-flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {saving ? (
                        <>
                          <span className="material-symbols-outlined text-lg animate-spin">
                            progress_activity
                          </span>
                          Saving...
                        </>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-lg">
                            save
                          </span>
                          {editingListing ? "Update Listing" : "Create Listing"}
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InfoPill({ icon, label, value }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 bg-accent/50 rounded-xl">
      <span className="material-symbols-outlined text-primary text-xl">
        {icon}
      </span>
      <div>
        <p className="text-xs text-gray-500">{label}</p>
        <p className="font-medium text-gray-800 text-sm">{value}</p>
      </div>
    </div>
  );
}

function InputField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  ...rest
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
        {...rest}
      />
    </div>
  );
}
