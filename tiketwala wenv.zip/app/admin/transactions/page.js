"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAdminAuth } from "@/lib/AdminAuthContext";

export default function PosTransactionsPage() {
  const router = useRouter();
  const { admin, loading: authLoading, authHeaders, isSuperAdmin, isOwner } = useAdminAuth();
  
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("");

  useEffect(() => {
    if (!authLoading && !admin) {
      router.replace("/admin/login");
      return;
    }
    // Optional: add authorization check (e.g. only superadmin or owner)
  }, [admin, authLoading, router]);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const url = new URL("/api/worldline/transactions", window.location.origin);
      if (statusFilter) url.searchParams.append("status", statusFilter);
      
      const res = await fetch(url.toString(), {
        headers: authHeaders()
      });
      const data = await res.json();
      if (data.success) {
        setTransactions(data.data);
      }
    } catch (error) {
      console.error("Error fetching transactions", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (admin) {
      fetchTransactions();
    }
  }, [admin, statusFilter]);

  const exportCSV = () => {
    if (!transactions.length) return;
    const headers = ["ID", "Invoice No", "Terminal", "Amount", "Mode", "Status", "Date"];
    const rows = transactions.map(t => [
      t._id,
      t.invoiceNo,
      t.terminalId,
      t.amount,
      t.paymentMode,
      t.status,
      new Date(t.createdAt).toLocaleString()
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n" 
      + rows.map(e => e.join(",")).join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `pos_transactions_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (authLoading || loading && !transactions.length) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6 lg:ml-64 pt-20 lg:pt-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">POS Transactions</h1>
            <p className="text-sm text-gray-500">Worldline POS Payment History</p>
          </div>
          
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              <option value="">All Statuses</option>
              <option value="success">Success</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
              <option value="cancelled">Cancelled</option>
            </select>
            
            <button 
              onClick={exportCSV}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">download</span>
              Export CSV
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-gray-600">
              <thead className="bg-gray-50 text-gray-700 font-medium border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4">Transaction ID</th>
                  <th className="px-6 py-4">Invoice No</th>
                  <th className="px-6 py-4">Terminal</th>
                  <th className="px-6 py-4">Amount</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {transactions.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                      No POS transactions found.
                    </td>
                  </tr>
                ) : (
                  transactions.map(t => (
                    <tr key={t._id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-gray-500">{t._id}</td>
                      <td className="px-6 py-4 font-medium">{t.invoiceNo}</td>
                      <td className="px-6 py-4">{t.terminalId}</td>
                      <td className="px-6 py-4 font-semibold text-gray-900">₹{t.amount}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-full text-[11px] font-medium uppercase tracking-wider
                          ${t.status === 'success' ? 'bg-green-100 text-green-700' : ''}
                          ${t.status === 'pending' ? 'bg-yellow-100 text-yellow-700' : ''}
                          ${t.status === 'failed' ? 'bg-red-100 text-red-700' : ''}
                          ${t.status === 'cancelled' ? 'bg-gray-100 text-gray-700' : ''}
                        `}>
                          {t.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-xs whitespace-nowrap">
                        {new Date(t.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
