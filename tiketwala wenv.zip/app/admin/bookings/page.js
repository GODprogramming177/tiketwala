"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";

export default function AdminBookingsPage() {
  const router = useRouter();
  const { admin, loading: authLoading, authHeaders, isSuperAdmin } = useAdminAuth();

  const [loading, setLoading] = useState(true);
  const [bookings, setBookings] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchBookings = useCallback(async () => {
    try {
      setLoading(true);
      // We can reuse the reports endpoint to get all recent bookings
      // using a wide date range for now, or just the current month
      const d = new Date();
      d.setMonth(d.getMonth() - 1);
      const startDate = d.toISOString().slice(0, 10);
      
      const future = new Date();
      future.setFullYear(future.getFullYear() + 1);
      const endDate = future.toISOString().slice(0, 10);

      const params = new URLSearchParams({ startDate, endDate });
      const res = await fetch(`/api/admin/reports?${params}`, {
        headers: authHeaders(),
      });
      const data = await res.json();
      if (data.success) {
        setBookings(data.bookings || []);
      }
    } catch (err) {
      console.error("Failed to fetch bookings:", err);
    } finally {
      setLoading(false);
    }
  }, [authHeaders]);

  useEffect(() => {
    if (!authLoading && !admin) {
      router.push("/admin/login");
    } else if (admin) {
      fetchBookings();
    }
  }, [admin, authLoading, router, fetchBookings]);

  const filteredBookings = bookings.filter((b) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      b.bookingId?.toLowerCase().includes(q) ||
      b.customerEmail?.toLowerCase().includes(q) ||
      b.listingName?.toLowerCase().includes(q) ||
      b.bookingDateIso?.includes(q)
    );
  });

  if (authLoading || !admin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">
                confirmation_number
              </span>
              Bookings
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {isSuperAdmin() ? "Manage platform-wide bookings" : "Manage bookings for your listings"}
            </p>
          </div>

          <div className="relative">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
              search
            </span>
            <input
              type="text"
              placeholder="Search ID, email, listing..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 border rounded-xl text-sm w-[260px] focus:ring-2 focus:ring-primary/40 focus:outline-none"
            />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[800px]">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="py-3 px-4 text-left font-medium text-gray-600">ID</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-600">Customer</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-600">Listing</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-600">Date/Time</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-600">Qty</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-600">Amount</th>
                    <th className="py-3 px-4 text-center font-medium text-gray-600">Channel</th>
                    <th className="py-3 px-4 text-center font-medium text-gray-600">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBookings.map((b) => (
                    <tr key={b.bookingId} className="border-b last:border-0 hover:bg-gray-50">
                      <td className="py-3 px-4 font-mono text-xs text-primary">{b.bookingId}</td>
                      <td className="py-3 px-4 font-medium">{b.customerEmail}</td>
                      <td className="py-3 px-4">{b.listingName}</td>
                      <td className="py-3 px-4">
                        {b.bookingDateIso}
                        <br />
                        <span className="text-xs text-gray-400">{b.slot}</span>
                      </td>
                      <td className="py-3 px-4 text-right">{b.quantity}</td>
                      <td className="py-3 px-4 text-right font-semibold">
                        ₹{b.totalAmount}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider ${
                          b.channel === "pos"
                            ? "bg-purple-100 text-purple-700"
                            : "bg-blue-100 text-blue-700"
                        }`}>
                          {b.channel || "online"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider ${
                          (b.ticketStatus || "valid") === "valid"
                            ? "bg-emerald-100 text-emerald-700"
                            : (b.ticketStatus || "valid") === "active"
                              ? "bg-green-100 text-green-700"
                              : (b.ticketStatus || "valid") === "used"
                                ? "bg-slate-100 text-slate-700"
                                : "bg-red-100 text-red-700"
                        }`}>
                          {b.ticketStatus || "valid"}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredBookings.length === 0 && (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-gray-500">
                        <span className="material-symbols-outlined text-4xl mb-2 text-gray-300">receipt_long</span>
                        <br />
                        No bookings found matching your search.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
