"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import QRScanner from "@/components/QRScanner";
import { useAdminAuth } from "@/lib/AdminAuthContext";

/**
 * Admin Dashboard Page
 * Overview of listings and quick stats
 */
export default function AdminDashboard() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    logout,
    isSuperAdmin,
    authHeaders,
  } = useAdminAuth();
  const [listings, setListings] = useState([]);
  const [recentBookings, setRecentBookings] = useState([]);
  const [bulkRequests, setBulkRequests] = useState([]);
  const [stats, setStats] = useState({
    totalListings: 0,
    temples: 0,
    parks: 0,
    events: 0,
    cinemas: 0,
    totalBookings: 0,
    bulkBookingRequests: 0,
    totalRevenue: 0,
    platformRevenue: 0,
    businessRevenue: 0,
  });
  const [loading, setLoading] = useState(true);
  const [showScanner, setShowScanner] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [allowedTypes, setAllowedTypes] = useState(["park", "event", "cinema", "temple"]);

  useEffect(() => {
    if (!authLoading && !admin) {
      router.push("/admin/login");
      return;
    }
    // Workers should never see the admin dashboard — send them to POS
    if (!authLoading && admin && admin.role === "worker") {
      router.replace("/worker/pos");
    }
  }, [admin, authLoading, router]);

  useEffect(() => {
    if (admin) {
      fetchDashboardData();
    }
  }, [admin]);

  const fetchDashboardData = async () => {
    try {
      const url = isSuperAdmin()
        ? "/api/admin/dashboard"
        : `/api/admin/dashboard?ownerId=${admin.id}`;

      const response = await fetch(url, { headers: authHeaders() });
      const data = await response.json();

      if (data.stats) setStats(data.stats);
      if (data.recentBookings) setRecentBookings(data.recentBookings);
      if (data.bulkRequests) setBulkRequests(data.bulkRequests);
      if (data.allowedListingTypes) setAllowedTypes(data.allowedListingTypes);
      if (data.listings) {
        // The API returns raw properties, let's map them for the UI briefly
        const mappedListings = data.listings.map((p) => ({
          id: p._id,
          name: p.name,
          type: p.category
            ? p.category.charAt(0).toUpperCase() + p.category.slice(1)
            : "Temple",
          location: p.address || "Unknown",
          price: p.pricing?.adult || p.offerings?.[0]?.price || 0,
          rating: 4.8, // Mock rating since DB doesn't have it
        }));
        setListings(mappedListings);
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleScanResult = (result) => {
    setScanResult(result);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  if (!admin || admin.role === "worker") {
    return null;
  }

  // Stats are already calculated and provided by backend now

  const statCards = [
    {
      label: "Total Listings",
      value: stats.totalListings,
      icon: "list",
      color: "bg-primary",
      alwaysShow: true,
    },
    {
      label: "Tickets Sold",
      value: stats.totalBookings,
      icon: "confirmation_number",
      color: "bg-blue-500",
      alwaysShow: true,
    },
    {
      label: "Revenue",
      value: `₹${(stats.totalRevenue || 0).toLocaleString("en-IN")}`,
      icon: "payments",
      color: "bg-green-600",
      alwaysShow: true,
    },

    {
      label: "Temples",
      value: stats.temples,
      icon: "temple_hindu",
      color: "bg-orange-500",
      type: "temple",
    },
    { label: "Parks", value: stats.parks, icon: "park", color: "bg-green-500", type: "park" },
    {
      label: "Events",
      value: stats.events,
      icon: "celebration",
      color: "bg-purple-500",
      type: "event",
    },
    {
      label: "Cinemas",
      value: stats.cinemas,
      icon: "movie",
      color: "bg-slate-700",
      type: "cinema",
    },
  ];

  const filteredStatCards = statCards.filter(
    card => card.alwaysShow || allowedTypes.includes(card.type)
  );

  const quickActions = [
    {
      label: "Scan Tickets",
      href: "#scanner",
      icon: "qr_code_scanner",
      description: "Validate customer tickets via QR code",
      isScanner: true,
    },
    {
      label: "Manage Listings",
      href: "/admin/listings",
      icon: "edit_note",
      description: "Add, edit, or remove listings",
    },
    {
      label: "Manage Slots",
      href: "/admin/slots",
      icon: "schedule",
      description: "Configure time slots for bookings",
    },
    {
      label: "View Public Site",
      href: "/",
      icon: "visibility",
      description: "See how customers see your site",
    },
  ];

  if (isSuperAdmin()) {
    quickActions.splice(3, 0,
      {
        label: "Manage Admins",
        href: "/admin/admins",
        icon: "manage_accounts",
        description: "View, edit, or delete admin accounts",
      },
      {
        label: "All Businesses",
        href: "/admin/listings",
        icon: "storefront",
        description: "Access and manage any admin's listing panel",
      },
    );
  } else {
    quickActions.splice(3, 0, {
      label: "Manage Workers",
      href: "/admin/workers",
      icon: "groups",
      description: "Assign workers and control POS access",
    });
  }

  return (
    <>
      <Navbar isAdmin />
      {showScanner && (
        <QRScanner
          onScan={handleScanResult}
          onClose={() => setShowScanner(false)}
        />
      )}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold text-primary">
                  Admin Dashboard
                </h1>
                {isSuperAdmin() && (
                  <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs font-semibold rounded">
                    SUPER ADMIN
                  </span>
                )}
              </div>
              <p className="text-gray-500 mt-1">
                Welcome back, {admin.name}!{" "}


                {isSuperAdmin()
                  ? "You have full access."
                  : "Manage your listings."}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowScanner(true)}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors shadow-md"
              >
                <span className="material-symbols-outlined">
                  qr_code_scanner
                </span>
                <span className="hidden sm:inline">Scan Ticket</span>
              </button>
              <button
                onClick={logout}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <span className="material-symbols-outlined">logout</span>
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>

          {/* Scan Result Alert */}
          {scanResult && (() => {
            const scanType = scanResult.scanType;
            const colorMap = {
              entry: { bg: "bg-green-50", border: "border-green-200", icon: "login", iconColor: "text-green-600", titleColor: "text-green-800", textColor: "text-green-600", closeColor: "text-green-600 hover:text-green-800", title: "Entry Scan — Welcome!" },
              exit: { bg: "bg-blue-50", border: "border-blue-200", icon: "logout", iconColor: "text-blue-600", titleColor: "text-blue-800", textColor: "text-blue-600", closeColor: "text-blue-600 hover:text-blue-800", title: "Exit Scan — Goodbye!" },
              expired: { bg: "bg-red-50", border: "border-red-200", icon: "block", iconColor: "text-red-600", titleColor: "text-red-800", textColor: "text-red-600", closeColor: "text-red-600 hover:text-red-800", title: "Ticket Expired" },
            };
            const fallback = scanResult.status === "valid"
              ? { bg: "bg-green-50", border: "border-green-200", icon: "verified", iconColor: "text-green-600", titleColor: "text-green-800", textColor: "text-green-600", closeColor: "text-green-600 hover:text-green-800", title: "Ticket Validated" }
              : { bg: "bg-red-50", border: "border-red-200", icon: "cancel", iconColor: "text-red-600", titleColor: "text-red-800", textColor: "text-red-600", closeColor: "text-red-600 hover:text-red-800", title: "Validation Failed" };
            const colors = colorMap[scanType] || fallback;

            return (
              <div className={`mb-6 p-4 border rounded-xl ${colors.bg} ${colors.border}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className={`material-symbols-outlined text-2xl ${colors.iconColor}`}>
                      {colors.icon}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className={`font-semibold ${colors.titleColor}`}>
                          {colors.title}
                        </p>
                        {scanType && (
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${colors.bg} ${colors.titleColor} border ${colors.border}`}>
                            {scanType}
                          </span>
                        )}
                      </div>
                      <p className={`text-sm ${colors.textColor}`}>
                        {scanResult.message}
                        {scanResult.bookingId &&
                          ` — Booking: ${scanResult.bookingId}`}
                        {scanResult.listingName && ` - ${scanResult.listingName}`}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setScanResult(null)}
                    className={colors.closeColor}
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>
              </div>
            );
          })()}

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            {filteredStatCards.map((stat, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">{stat.label}</p>
                    <p className="text-3xl font-bold text-primary mt-1">
                      {loading ? "-" : stat.value}
                    </p>
                  </div>
                  <div className={`${stat.color} p-3 rounded-xl`}>
                    <span className="material-symbols-outlined text-2xl text-white">
                      {stat.icon}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
            <div className="bg-white rounded-2xl shadow-md p-6 lg:col-span-2">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-primary/10 text-primary">
                  <span className="material-symbols-outlined text-2xl">
                    admin_panel_settings
                  </span>
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-primary">
                    TiketWala Control Center
                  </h2>
                  <p className="text-sm text-gray-500 mt-2">
                    Super admin keeps full control on what each admin can list,
                    how many listings they can publish, and how many workers
                    they can assign to POS duty.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6">
              <p className="text-sm text-gray-500">Operations snapshot</p>
              <p className="text-2xl font-bold text-primary mt-2">
                {stats.totalBookings} tickets sold
              </p>
              <p className="text-sm text-gray-500 mt-2">
                Keep track of sales and performance on your platform.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-primary mb-4">
              Quick Actions
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {quickActions.map((action, index) =>
                action.isScanner ? (
                  <button
                    key={index}
                    onClick={() => setShowScanner(true)}
                    className="bg-green-50 border-2 border-green-200 rounded-xl p-6 hover:bg-green-100 hover:border-green-300 transition-all group text-left"
                  >
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-green-500 rounded-xl text-white">
                        <span className="material-symbols-outlined text-2xl">
                          {action.icon}
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-green-800">
                          {action.label}
                        </h3>
                        <p className="text-sm text-green-600 mt-1">
                          {action.description}
                        </p>
                      </div>
                    </div>
                  </button>
                ) : (
                  <Link
                    key={index}
                    href={action.href}
                    className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow group"
                  >
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-accent rounded-xl group-hover:bg-primary group-hover:text-white transition-colors">
                        <span className="material-symbols-outlined text-2xl text-primary group-hover:text-white">
                          {action.icon}
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-primary group-hover:text-primary/80">
                          {action.label}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {action.description}
                        </p>
                      </div>
                    </div>
                  </Link>
                ),
              )}
            </div>
          </div>

          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-primary">
                Bulk Booking Requests
              </h2>
              <span className="text-sm text-gray-500">
                Minimum 48-hour advance notice
              </span>
            </div>

            <div className="bg-white rounded-2xl shadow-md overflow-hidden">
              {loading ? (
                <div className="p-8 text-center">
                  <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                    progress_activity
                  </span>
                  <p className="text-gray-500 mt-2">Loading requests...</p>
                </div>
              ) : bulkRequests.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[860px]">
                    <thead className="bg-accent">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Customer
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Listing
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Visit Date
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Quantity
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Contact
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {bulkRequests.map((request) => (
                        <tr key={request._id} className="hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div>
                              <p className="font-medium text-gray-800">
                                {request.customerName}
                              </p>
                              <p className="text-xs text-gray-500">
                                {request.customerEmail}
                              </p>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div>
                              <p className="font-medium">{request.listingName}</p>
                              <p className="text-xs text-gray-500 capitalize">
                                {request.listingType}
                              </p>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-gray-700">
                            {request.visitDate}
                          </td>
                          <td className="py-3 px-4 text-gray-700">
                            {request.quantity} guests
                          </td>
                          <td className="py-3 px-4 text-gray-700">
                            {request.customerPhone || "Phone not shared"}
                          </td>
                          <td className="py-3 px-4">
                            <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-sm capitalize">
                              {request.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-8 text-center">
                  <span className="material-symbols-outlined text-5xl text-gray-300">
                    groups_3
                  </span>
                  <p className="text-gray-500 mt-3">
                    No bulk booking requests yet
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Recent Listings */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-primary">
                Recent Listings
              </h2>
              <Link
                href="/admin/listings"
                className="text-primary hover:underline flex items-center gap-1 text-sm"
              >
                View all
                <span className="material-symbols-outlined text-lg">
                  arrow_forward
                </span>
              </Link>
            </div>

            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              {loading ? (
                <div className="p-8 text-center">
                  <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                    progress_activity
                  </span>
                  <p className="text-gray-500 mt-2">Loading listings...</p>
                </div>
              ) : listings.length > 0 ? (
                <table className="w-full">
                  <thead className="bg-accent">
                    <tr>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Name
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Type
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Location
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Price
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-primary">
                        Rating
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {listings.slice(0, 5).map((listing) => (
                      <tr key={listing.id} className="hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center overflow-hidden">
                              {listing.image ? (
                                <img
                                  src={listing.image}
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <span className="material-symbols-outlined text-primary">
                                  {listing.type === "Temple"
                                    ? "temple_hindu"
                                    : listing.type === "Park"
                                      ? "park"
                                      : "celebration"}
                                </span>
                              )}
                            </div>
                            <span className="font-medium">{listing.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-1 bg-accent rounded text-sm text-primary">
                            {listing.type}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {listing.location}
                        </td>
                        <td className="py-3 px-4 font-medium">
                          ₹{listing.price}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-1">
                            <span className="material-symbols-outlined text-yellow-500 text-lg">
                              star
                            </span>
                            {listing.rating}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="p-8 text-center">
                  <span className="material-symbols-outlined text-4xl text-gray-300">
                    inbox
                  </span>
                  <p className="text-gray-500 mt-2">No listings found</p>
                </div>
              )}
            </div>
          </div>

          {/* Recent Bookings / Sold Tickets */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-primary">
                Sold Tickets
              </h2>
              <span className="text-sm text-gray-500">
                {stats.totalBookings} total bookings
              </span>
            </div>

            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              {loading ? (
                <div className="p-8 text-center">
                  <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                    progress_activity
                  </span>
                  <p className="text-gray-500 mt-2">Loading bookings...</p>
                </div>
              ) : recentBookings.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-accent">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Booking ID
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Customer
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Venue
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Time Slot
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Qty
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Amount
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Status
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">
                          Scanned
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {recentBookings.map((b) => (
                        <tr key={b.bookingId} className="hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <span className="font-mono text-sm text-primary">
                              {b.bookingId}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <div>
                              <p className="font-medium text-gray-800">
                                {b.customerEmail}
                              </p>
                              {b.customerId && (
                                <p className="text-xs text-gray-400">
                                  {b.customerId}
                                </p>
                              )}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div>
                              <p className="font-medium">{b.listingName}</p>
                              <p className="text-xs text-gray-500">
                                {b.listingType}
                              </p>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-sm text-gray-600">
                            {b.slot}
                          </td>
                          <td className="py-3 px-4 text-center">
                            {b.quantity}
                          </td>
                          <td className="py-3 px-4 font-medium">
                            ₹{(b.totalAmount || 0).toLocaleString("en-IN")}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-1 rounded text-xs font-semibold ${
                                b.status === "confirmed"
                                  ? "bg-green-100 text-green-700"
                                  : b.status === "cancelled"
                                    ? "bg-red-100 text-red-700"
                                    : "bg-gray-100 text-gray-700"
                              }`}
                            >
                              {b.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            {b.scanned ? (
                              <span className="material-symbols-outlined text-green-600 text-lg">
                                check_circle
                              </span>
                            ) : (
                              <span className="material-symbols-outlined text-gray-300 text-lg">
                                radio_button_unchecked
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-8 text-center">
                  <span className="material-symbols-outlined text-4xl text-gray-300">
                    confirmation_number
                  </span>
                  <p className="text-gray-500 mt-2">No bookings yet</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
