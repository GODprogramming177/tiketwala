"use client";

import { useEffect, useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";

export default function SuperadminUsersPage() {
  const router = useRouter();
  const { admin, loading: authLoading, authHeaders, isSuperAdmin } = useAdminAuth();

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    if (!authLoading && (!admin || !isSuperAdmin())) {
      router.replace("/admin/login");
    }
  }, [admin, authLoading, isSuperAdmin, router]);

  useEffect(() => {
    if (admin && isSuperAdmin()) {
      fetchUsers();
    }
  }, [admin, isSuperAdmin]);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/superadmin/users", {
        headers: authHeaders(),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to fetch users");
      }
      setUsers(data.users || []);
    } catch (error) {
      toast.error(error.message || "Unable to load users");
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      // Role Filter
      if (roleFilter !== "all") {
        const uRole = (u.role || "").toLowerCase();
        if (roleFilter === "superadmin") {
          if (uRole !== "superadmin" && uRole !== "super_admin") return false;
        } else if (uRole !== roleFilter) {
          return false;
        }
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const name = (u.name || "").toLowerCase();
        const email = (u.email || "").toLowerCase();
        const phone = (u.phone || "").toLowerCase();
        return name.includes(q) || email.includes(q) || phone.includes(q);
      }

      return true;
    });
  }, [users, roleFilter, searchQuery]);

  const stats = useMemo(() => {
    const counts = {
      total: users.length,
      superadmin: 0,
      owner: 0,
      worker: 0,
      customer: 0,
    };
    users.forEach((u) => {
      const role = (u.role || "").toLowerCase();
      if (role === "superadmin" || role === "super_admin") counts.superadmin++;
      else if (role === "owner") counts.owner++;
      else if (role === "worker") counts.worker++;
      else if (role === "customer") counts.customer++;
    });
    return counts;
  }, [users]);

  const handleExportCSV = () => {
    if (filteredUsers.length === 0) {
      toast.error("No users available to export");
      return;
    }

    const headers = ["ID", "Name", "Email", "Phone", "Role", "Created At"];
    const rows = filteredUsers.map((u) => [
      u._id || "",
      u.name || "",
      u.email || "",
      u.phone || "",
      u.role || "",
      u.createdAt ? new Date(u.createdAt).toISOString() : "",
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(",")
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `users_export_${new Date().toISOString().split("T")[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("CSV file downloaded successfully");
  };

  const handleDelete = async (user) => {
    if (user._id === admin._id) {
      toast.error("You cannot delete your own logged-in account!");
      return;
    }

    if (!confirm(`Are you sure you want to PERMANENTLY delete user "${user.name}" (${user.email})? This action is irreversible.`)) {
      return;
    }

    try {
      setDeletingId(user._id);
      const response = await fetch(`/api/superadmin/users?userId=${user._id}`, {
        method: "DELETE",
        headers: authHeaders(),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to delete user");
      }

      toast.success("User account deleted successfully");
      if (selectedUser?._id === user._id) {
        setSelectedUser(null);
      }
      await fetchUsers();
    } catch (error) {
      toast.error(error.message || "Unable to delete user");
    } finally {
      setDeletingId(null);
    }
  };

  const getRoleBadgeClass = (role = "") => {
    const r = role.toLowerCase();
    if (r === "superadmin" || r === "super_admin") {
      return "bg-purple-100 text-purple-700 border-purple-200";
    }
    if (r === "owner") {
      return "bg-blue-100 text-blue-700 border-blue-200";
    }
    if (r === "worker") {
      return "bg-amber-100 text-amber-700 border-amber-200";
    }
    return "bg-emerald-100 text-emerald-700 border-emerald-200";
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  if (!admin || !isSuperAdmin()) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar isAdmin />
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Header */}
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-3xl font-bold text-primary">Manage Users</h1>
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold">
                  {users.length} total
                </span>
              </div>
              <p className="text-gray-500 mt-2">
                Monitor and manage all user accounts in the platform. Review details or delete accounts.
              </p>
            </div>
            
            <div className="flex items-center gap-3 flex-wrap">
              {/* Search Bar */}
              <div className="relative">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">
                  search
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search users..."
                  className="pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/30 bg-white w-[240px] text-sm transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <span className="material-symbols-outlined text-lg">close</span>
                  </button>
                )}
              </div>
              
              <button
                onClick={handleExportCSV}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all shadow-md hover:shadow-lg font-medium"
              >
                <span className="material-symbols-outlined text-xl">download</span>
                Export CSV
              </button>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-6">
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Total Users</p>
              <p className="text-2xl font-bold text-primary mt-1">{stats.total}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold text-purple-600">Super Admins</p>
              <p className="text-2xl font-bold text-purple-700 mt-1">{stats.superadmin}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold text-blue-600">Owners (Admins)</p>
              <p className="text-2xl font-bold text-blue-700 mt-1">{stats.owner}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold text-amber-600">Workers</p>
              <p className="text-2xl font-bold text-amber-700 mt-1">{stats.worker}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold text-emerald-600">Customers</p>
              <p className="text-2xl font-bold text-emerald-700 mt-1">{stats.customer}</p>
            </div>
          </div>

          {/* Role filter Tabs */}
          <div className="flex border-b border-gray-200 mb-6 overflow-x-auto gap-2 py-1">
            {[
              { id: "all", label: "All Users" },
              { id: "superadmin", label: "Super Admins" },
              { id: "owner", label: "Owners" },
              { id: "worker", label: "Workers" },
              { id: "customer", label: "Customers" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setRoleFilter(tab.id)}
                className={`px-4 py-2 text-sm font-semibold rounded-lg whitespace-nowrap transition-all duration-200 ${
                  roleFilter === tab.id
                    ? "bg-primary text-white shadow-sm"
                    : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Table list */}
          <div className="bg-white rounded-2xl shadow-md overflow-hidden border border-gray-100">
            {loading ? (
              <div className="p-12 text-center">
                <span className="material-symbols-outlined text-5xl text-gray-300 animate-spin">
                  progress_activity
                </span>
                <p className="text-gray-500 mt-3">Loading users...</p>
              </div>
            ) : filteredUsers.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[960px]">
                  <thead className="bg-gradient-to-r from-primary/5 to-primary/10">
                    <tr>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">#</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">User Details</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Role</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Contact Number</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Registered At</th>
                      <th className="text-right py-4 px-5 font-semibold text-primary text-sm">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredUsers.map((u, idx) => (
                      <tr key={u._id} className="hover:bg-gray-50/80 transition-colors group">
                        <td className="py-4 px-5">
                          <span className="text-gray-400 text-sm font-mono">{idx + 1}</span>
                        </td>
                        <td className="py-4 px-5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                              <span className="text-primary font-bold text-sm">
                                {u.name?.charAt(0)?.toUpperCase() || "U"}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-800">{u.name || "N/A"}</p>
                              <p className="text-sm text-gray-500">{u.email || "No email"}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-5">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${getRoleBadgeClass(u.role)}`}>
                            {u.role === "super_admin" ? "Super Admin" : u.role || "unknown"}
                          </span>
                        </td>
                        <td className="py-4 px-5 text-gray-700 text-sm">
                          {u.phone ? (
                            <div className="flex items-center gap-1.5">
                              <span className="material-symbols-outlined text-[16px] text-gray-400">phone</span>
                              {u.phone}
                            </div>
                          ) : (
                            <span className="text-gray-400 italic">None</span>
                          )}
                        </td>
                        <td className="py-4 px-5 text-gray-700 text-sm">
                          {u.createdAt ? (
                            <div className="flex items-center gap-1.5">
                              <span className="material-symbols-outlined text-[16px] text-gray-400">calendar_month</span>
                              {new Date(u.createdAt).toLocaleDateString()}
                            </div>
                          ) : (
                            <span className="text-gray-400 italic">Unknown</span>
                          )}
                        </td>
                        <td className="py-4 px-5">
                          <div className="flex items-center justify-end gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => setSelectedUser(u)}
                              className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                              title="View Details"
                            >
                              <span className="material-symbols-outlined text-xl">visibility</span>
                            </button>
                            <button
                              onClick={() => handleDelete(u)}
                              disabled={deletingId === u._id}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                              title="Delete Account"
                            >
                              {deletingId === u._id ? (
                                <span className="material-symbols-outlined text-xl animate-spin">progress_activity</span>
                              ) : (
                                <span className="material-symbols-outlined text-xl">delete</span>
                              )}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-12 text-center">
                <span className="material-symbols-outlined text-5xl text-gray-300">
                  search_off
                </span>
                <p className="text-gray-500 mt-3">No user records found matching current query/filters.</p>
              </div>
            )}
          </div>

          {/* Details Modal */}
          {selectedUser && (
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
                <div className="p-6 border-b flex items-start justify-between gap-4 sticky top-0 bg-white z-10 rounded-t-2xl">
                  <div>
                    <h2 className="text-xl font-semibold text-primary">User Account Details</h2>
                    <p className="text-sm text-gray-500 mt-1">Full system records for the selected account.</p>
                  </div>
                  <button
                    onClick={() => setSelectedUser(null)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <div className="p-6 space-y-6">
                  {/* Avatar / Summary */}
                  <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
                    <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center text-white text-xl font-bold shrink-0 shadow-md">
                      {selectedUser.name?.charAt(0)?.toUpperCase() || "U"}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">{selectedUser.name || "N/A"}</h3>
                      <p className="text-sm text-gray-500">{selectedUser.email || "No email"}</p>
                    </div>
                  </div>

                  {/* Detail Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <DetailItem label="User ID (Database)" value={selectedUser._id} isMono />
                    <DetailItem label="Role" value={selectedUser.role === "super_admin" ? "Super Admin" : selectedUser.role || "N/A"} />
                    <DetailItem label="Contact Phone" value={selectedUser.phone || "Not provided"} />
                    <DetailItem label="Location / Metadata" value={selectedUser.location ? JSON.stringify(selectedUser.location) : "None"} isMono />
                    <DetailItem label="Created Timestamp" value={selectedUser.createdAt ? new Date(selectedUser.createdAt).toLocaleString() : "Unknown"} />
                    <DetailItem label="Last Updated" value={selectedUser.updatedAt ? new Date(selectedUser.updatedAt).toLocaleString() : "Unknown"} />
                  </div>

                  {/* Actions Area */}
                  <div className="pt-6 border-t flex gap-3">
                    <button
                      onClick={() => setSelectedUser(null)}
                      className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-medium text-center"
                    >
                      Close Details
                    </button>
                    <button
                      onClick={() => handleDelete(selectedUser)}
                      disabled={deletingId === selectedUser._id}
                      className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl transition-colors font-medium flex items-center justify-center gap-2"
                    >
                      <span className="material-symbols-outlined text-lg">delete</span>
                      Delete Account
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

function DetailItem({ label, value, isMono = false }) {
  return (
    <div className="space-y-1">
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-wider">{label}</p>
      <p className={`text-sm text-gray-800 font-medium break-all bg-gray-50/50 p-2.5 rounded-lg border border-gray-100/50 ${isMono ? "font-mono text-xs" : ""}`}>
        {value}
      </p>
    </div>
  );
}
