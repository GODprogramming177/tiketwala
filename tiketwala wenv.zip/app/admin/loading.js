export default function AdminLoading() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
        <p className="text-gray-500 text-sm font-medium">
          Loading admin panel…
        </p>
      </div>
    </div>
  );
}
