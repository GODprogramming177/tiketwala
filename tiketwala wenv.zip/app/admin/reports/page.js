"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";

function getOneYearFutureIso() {
  const d = new Date();
  d.setFullYear(d.getFullYear() + 1);
  return d.toISOString().slice(0, 10);
}

function getMonthAgoIso() {
  const d = new Date();
  d.setMonth(d.getMonth() - 1);
  return d.toISOString().slice(0, 10);
}

export default function AdminReportsPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    authHeaders,
    isSuperAdmin,
  } = useAdminAuth();

  const [loading, setLoading] = useState(true);
  const [reportData, setReportData] = useState(null);
  const [startDate, setStartDate] = useState(getMonthAgoIso());
  const [endDate, setEndDate] = useState(getOneYearFutureIso());
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [activeTab, setActiveTab] = useState("summary");

  useEffect(() => {
    if (!authLoading && !admin) {
      router.push("/admin/login");
    }
  }, [admin, authLoading, router]);

  const fetchReport = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({ startDate, endDate });
      if (startTime) params.set("startTime", startTime);
      if (endTime) params.set("endTime", endTime);
      const res = await fetch(`/api/admin/reports?${params}`, {
        headers: authHeaders(),
      });
      const data = await res.json();
      if (data.success) {
        setReportData(data);
      }
    } catch (err) {
      console.error("Failed to fetch report:", err);
    } finally {
      setLoading(false);
    }
  }, [authHeaders, endDate, endTime, startDate, startTime]);

  useEffect(() => {
    if (admin) {
      fetchReport();
    }
  }, [admin, fetchReport]);

  const exportCSV = () => {
    if (!reportData?.bookings?.length) return;

    const headers = [
      "Booking ID",
      "Customer Email",
      "Booked By",
      "Business",
      "Listing",
      "Type",
      "Date",
      "Slot",
      "Qty",
      "Total",
      "Platform Fee",
      "Business Amt",
      "Channel",
      "Created At",
    ];
    const rows = reportData.bookings.map((b) => [
      b.bookingId,
      b.customerEmail,
      b.bookedByName,
      b.businessName,
      b.listingName,
      b.listingType,
      b.bookingDateIso,
      b.slot,
      b.quantity,
      b.totalAmount,
      b.platformFee,
      b.businessAmount,
      b.channel,
      b.createdAt,
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((cell) => `"${String(cell || "").replace(/"/g, '""')}"`).join(","),
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `tiketwala-report-${startDate}-to-${endDate}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading || !admin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const summary = reportData?.summary || {};
  const tabs = [
    { id: "summary", label: "Summary", icon: "bar_chart" },
    { id: "daily", label: "Daily", icon: "calendar_month" },
    { id: "listings", label: "By Listing", icon: "category" },
    ...(isSuperAdmin()
      ? [{ id: "businesses", label: "By Business", icon: "storefront" }]
      : []),
    { id: "bookings", label: "All Bookings", icon: "receipt_long" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-6xl mx-auto w-full px-4 py-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">
                analytics
              </span>
              Reports
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {isSuperAdmin() ? "Consolidated park and sales analytics" : "Your sales analytics and money inflow"}
            </p>
          </div>

          <button
            onClick={exportCSV}
            disabled={!reportData?.bookings?.length}
            className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 border border-green-200 rounded-lg hover:bg-green-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="material-symbols-outlined text-lg">download</span>
            Export CSV
          </button>
        </div>

        {/* Date Filters */}
        <div className="bg-white rounded-xl border p-4 mb-6 flex flex-wrap items-end gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">From</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-primary/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">To</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-primary/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">From Time</label>
            <input
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-primary/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">To Time</label>
            <input
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-primary/50 focus:outline-none"
            />
          </div>
          <button
            onClick={fetchReport}
            className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium"
          >
            Apply
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {[
                { label: "Total Bookings", value: summary.totalBookings || 0, icon: "confirmation_number", color: "text-primary" },
                { label: "Money Inflow", value: `₹${(summary.totalRevenue || 0).toLocaleString("en-IN")}`, icon: "payments", color: "text-green-600" },
                { label: "Platform Fee", value: `₹${(summary.platformFee || 0).toLocaleString("en-IN")}`, icon: "account_balance", color: "text-amber-600" },
                { label: "Total Visitors", value: summary.totalQuantity || 0, icon: "group", color: "text-blue-600" },
              ].map((card) => (
                <div key={card.label} className="bg-white rounded-xl border p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`material-symbols-outlined text-lg ${card.color}`}>{card.icon}</span>
                    <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">{card.label}</span>
                  </div>
                  <p className="text-xl font-bold text-gray-900">{card.value}</p>
                </div>
              ))}
            </div>

            {/* Tabs */}
            <div className="flex gap-1 mb-4 bg-white rounded-xl border p-1 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                    activeTab === tab.id
                      ? "bg-primary text-white"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <span className="material-symbols-outlined text-lg">{tab.icon}</span>
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="bg-white rounded-xl border overflow-hidden">
              {activeTab === "summary" && (
                <div className="p-6 text-center text-gray-500">
                  <span className="material-symbols-outlined text-5xl text-gray-300 mb-3 block">
                    bar_chart
                  </span>
                  <p className="text-lg font-semibold text-gray-700">
                    {summary.totalBookings || 0} bookings across{" "}
                    {reportData?.listingBreakdown?.length || 0} listings
                  </p>
                  <p className="text-sm mt-1">
                    From {startDate} to {endDate}
                  </p>
                </div>
              )}

              {activeTab === "daily" && (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Date</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Bookings</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Visitors</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Revenue</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reportData?.dailyBreakdown || []).map((day) => (
                        <tr key={day.date} className="border-b last:border-0 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{day.date}</td>
                          <td className="py-3 px-4 text-right">{day.bookings}</td>
                          <td className="py-3 px-4 text-right">{day.visitors}</td>
                          <td className="py-3 px-4 text-right font-semibold">
                            ₹{day.revenue.toLocaleString("en-IN")}
                          </td>
                        </tr>
                      ))}
                      {(!reportData?.dailyBreakdown?.length) && (
                        <tr><td colSpan={4} className="py-8 text-center text-gray-400">No data for this period</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === "listings" && (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Listing</th>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Type</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Bookings</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Visitors</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Revenue</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reportData?.listingBreakdown || []).map((item) => (
                        <tr key={item.listingId} className="border-b last:border-0 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{item.listingName}</td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 rounded bg-gray-100 text-xs font-medium">
                              {item.listingType}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right">{item.bookings}</td>
                          <td className="py-3 px-4 text-right">{item.visitors}</td>
                          <td className="py-3 px-4 text-right font-semibold">
                            ₹{item.revenue.toLocaleString("en-IN")}
                          </td>
                        </tr>
                      ))}
                      {(!reportData?.listingBreakdown?.length) && (
                        <tr><td colSpan={5} className="py-8 text-center text-gray-400">No listing data</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === "businesses" && isSuperAdmin() && (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Business</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Bookings</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Revenue</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Platform Fee</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Business Amt</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reportData?.businessBreakdown || []).map((biz) => (
                        <tr key={biz.businessId} className="border-b last:border-0 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{biz.businessName}</td>
                          <td className="py-3 px-4 text-right">{biz.bookings}</td>
                          <td className="py-3 px-4 text-right font-semibold">
                            ₹{biz.revenue.toLocaleString("en-IN")}
                          </td>
                          <td className="py-3 px-4 text-right text-amber-600">
                            ₹{biz.platformFee.toLocaleString("en-IN")}
                          </td>
                          <td className="py-3 px-4 text-right text-green-600">
                            ₹{biz.businessAmount.toLocaleString("en-IN")}
                          </td>
                        </tr>
                      ))}
                      {(!reportData?.businessBreakdown?.length) && (
                        <tr><td colSpan={5} className="py-8 text-center text-gray-400">No business data</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === "bookings" && (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">ID</th>
                        {isSuperAdmin() && (
                          <th className="py-3 px-4 text-left font-medium text-gray-600">Business</th>
                        )}
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Customer</th>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Booked By</th>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Listing</th>
                        <th className="py-3 px-4 text-left font-medium text-gray-600">Date</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Qty</th>
                        <th className="py-3 px-4 text-right font-medium text-gray-600">Amount</th>
                        <th className="py-3 px-4 text-center font-medium text-gray-600">Channel</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reportData?.bookings || []).map((b) => (
                        <tr key={b.bookingId} className="border-b last:border-0 hover:bg-gray-50">
                          <td className="py-3 px-4 font-mono text-xs">{b.bookingId}</td>
                          {isSuperAdmin() && (
                            <td className="py-3 px-4 text-sm">{b.businessName || "-"}</td>
                          )}
                          <td className="py-3 px-4 text-sm">{b.customerEmail}</td>
                          <td className="py-3 px-4 text-sm">{b.bookedByName || "-"}</td>
                          <td className="py-3 px-4 font-medium">{b.listingName}</td>
                          <td className="py-3 px-4">{b.bookingDateIso}</td>
                          <td className="py-3 px-4 text-right">{b.quantity}</td>
                          <td className="py-3 px-4 text-right font-semibold">
                            ₹{(b.totalAmount || 0).toLocaleString("en-IN")}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                              b.channel === "pos"
                                ? "bg-purple-50 text-purple-700"
                                : "bg-blue-50 text-blue-700"
                            }`}>
                              {b.channel || "online"}
                            </span>
                          </td>
                        </tr>
                      ))}
                      {(!reportData?.bookings?.length) && (
                        <tr><td colSpan={isSuperAdmin() ? 9 : 8} className="py-8 text-center text-gray-400">No bookings found</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
