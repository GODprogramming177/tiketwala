"use client";

import AdminSidebar from "@/components/AdminSidebar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import { usePathname } from "next/navigation";

/**
 * Admin Layout — Wraps all admin pages with sidebar navigation.
 * AdminAuthProvider is already in root layout — no duplicate wrapping needed.
 * Login page bypasses sidebar.
 */
export default function AdminLayout({ children }) {
  const pathname = usePathname();
  const { admin, loading } = useAdminAuth();

  // Login page: no sidebar
  const isLoginPage = pathname === "/admin/login";

  if (isLoginPage || loading || !admin) {
    return (
      <div className="min-h-screen bg-accent/30">{children}</div>
    );
  }

  return (
    <div className="min-h-screen bg-accent/30 flex">
      <AdminSidebar />
      <main className="flex-1 min-h-screen overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
