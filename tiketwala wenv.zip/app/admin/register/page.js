"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import {
  CATEGORY_ORDER,
  getCategoryLabel,
} from "@/lib/listingUtils";

const DEFAULT_TYPES = [...CATEGORY_ORDER];

export default function AdminRegisterPage() {
  const router = useRouter();
  const { admin, loading: authLoading, authHeaders, isSuperAdmin } =
    useAdminAuth();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    businessName: "",
    city: "",
    state: "Odisha",
    gstin: "",
    pan: "",
    listingLimit: "10",
    workerLimit: "2",
    allowedListingTypes: DEFAULT_TYPES,
  });
  const [panError, setPanError] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && !admin) {
      router.replace("/admin/login");
      return;
    }

    if (!authLoading && admin && !isSuperAdmin()) {
      router.replace("/admin");
    }
  }, [authLoading, admin, isSuperAdmin, router]);

  if (!authLoading && (!admin || !isSuperAdmin())) {
    return null;
  }

  const PAN_REGEX = /^[A-Z]{3}[PCFHATBLJG][A-Z]\d{4}[A-Z]$/;

  const handleChange = (event) => {
    const { name, value } = event.target;
    if (name === "pan") {
      const upper = value
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "")
        .slice(0, 10);
      setFormData((prev) => ({ ...prev, pan: upper }));
      // Real-time validation
      if (upper.length === 0) {
        setPanError("PAN is required");
      } else if (upper.length < 10) {
        setPanError("PAN must be 10 characters");
      } else if (!PAN_REGEX.test(upper)) {
        setPanError("Invalid PAN format. 4th char must be P/C/F/H/A/T/B/L/J/G");
      } else {
        setPanError("");
      }
      return;
    }
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const toggleListingType = (type) => {
    setFormData((prev) => {
      const current = prev.allowedListingTypes || [];
      const exists = current.includes(type);
      if (exists) {
        return {
          ...prev,
          allowedListingTypes: current.filter((item) => item !== type),
        };
      }
      return {
        ...prev,
        allowedListingTypes: [...current, type],
      };
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess(null);

    if (formData.allowedListingTypes.length === 0) {
      setError("Select at least one listing type for the admin.");
      return;
    }

    // PAN validation
    if (!formData.pan || !PAN_REGEX.test(formData.pan)) {
      setError("Valid PAN is required. Format: ABCPD1234E");
      setPanError("Invalid PAN format");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/admin/register", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
          ...formData,
          listingLimit: Number(formData.listingLimit),
          workerLimit: Number(formData.workerLimit),
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to create admin account");
      }

      setSuccess(data);
      setFormData({
        name: "",
        email: "",
        password: "",
        phone: "",
        businessName: "",
        city: "",
        state: "Odisha",
        gstin: "",
        pan: "",
        listingLimit: "10",
        workerLimit: "2",
        allowedListingTypes: DEFAULT_TYPES,
      });
      setPanError("");
    } catch (submissionError) {
      setError(submissionError.message || "Something went wrong.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar isAdmin />
      <div className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Link
              href="/admin"
              className="text-primary hover:underline flex items-center gap-1 text-sm mb-4"
            >
              <span className="material-symbols-outlined text-lg">
                arrow_back
              </span>
              Back to Dashboard
            </Link>
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-3xl font-bold text-primary">
                Register New Admin
              </h1>
              <span className="px-3 py-1 rounded-full bg-yellow-100 text-yellow-800 text-xs font-semibold tracking-wide">
                SUPER ADMIN CONTROL
              </span>
            </div>
            <p className="text-gray-500 mt-2">
              Create an admin account and define exactly how many listings they
              can manage and which listing types they are allowed to publish.
            </p>
          </div>

          {success && (
            <div className="mb-6 p-5 bg-green-50 border border-green-200 rounded-2xl">
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-green-600 text-2xl">
                  check_circle
                </span>
                <div className="space-y-1 text-sm text-green-800">
                  <p className="font-semibold text-base">
                    Admin account created successfully
                  </p>
                  <p>
                    <strong>Name:</strong> {success.user.name}
                  </p>
                  <p>
                    <strong>Email:</strong> {success.user.email}
                  </p>
                  <p>
                    <strong>Business:</strong> {success.business?.name}
                  </p>
                  <p>
                    <strong>GSTIN:</strong> {success.business?.gstin || "Not set"}
                  </p>
                  <p>
                    <strong>Listing limit:</strong> {success.business?.listingLimit}
                  </p>
                  <p>
                    <strong>Worker limit:</strong> {success.business?.workerLimit}
                  </p>
                  <p>
                    <strong>Allowed types:</strong>{" "}
                    {(success.business?.allowedListingTypes || [])
                      .map((type) => getCategoryLabel(type))
                      .join(", ")}
                  </p>
                  <button
                    onClick={() => setSuccess(null)}
                    className="mt-3 text-sm text-green-700 hover:text-green-900 underline"
                  >
                    Create another admin
                  </button>
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
              <span className="material-symbols-outlined text-red-500">
                error
              </span>
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {!success && (
            <form
              onSubmit={handleSubmit}
              className="bg-white rounded-2xl shadow-md p-6 sm:p-8 space-y-8"
            >
              <section className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">
                    person
                  </span>
                  <h2 className="text-lg font-semibold text-primary">
                    Admin Details
                  </h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field
                    label="Full Name *"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter full name"
                    required
                  />
                  <Field
                    label="Phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+91 9876543210"
                  />
                  <Field
                    label="Email *"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="admin@example.com"
                    required
                  />
                  <Field
                    label="Password *"
                    name="password"
                    type="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Minimum 6 characters"
                    required
                    minLength={6}
                  />
                </div>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">
                    business
                  </span>
                  <h2 className="text-lg font-semibold text-primary">
                    Business Controls
                  </h2>
                </div>
                <p className="text-sm text-gray-500">
                  Super admin settings here directly control what the admin can
                  list later in the manage listings section.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field
                    label="Business Name *"
                    name="businessName"
                    value={formData.businessName}
                    onChange={handleChange}
                    placeholder="My Business"
                    required
                  />
                  <div>
                    <Field
                      label="PAN *"
                      name="pan"
                      value={formData.pan}
                      onChange={handleChange}
                      placeholder="ABCPD1234E"
                      required
                      maxLength={10}
                      pattern="[A-Z]{3}[PCFHATBLJG][A-Z][0-9]{4}[A-Z]"
                    />
                    {formData.pan.length > 0 && (
                      <div className={`flex items-center gap-1 mt-1 text-xs ${panError ? "text-red-500" : "text-green-600"}`}>
                        <span className="material-symbols-outlined text-sm">
                          {panError ? "error" : "check_circle"}
                        </span>
                        {panError || "Valid PAN"}
                      </div>
                    )}
                  </div>
                  <Field
                    label="GSTIN (Optional)"
                    name="gstin"
                    value={formData.gstin}
                    onChange={handleChange}
                    placeholder="22AAAAA0000A1Z5"
                  />
                  <Field
                    label="City *"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    placeholder="e.g. Bhubaneswar"
                    required
                  />
                  <Field
                    label="State *"
                    name="state"
                    value={formData.state}
                    onChange={handleChange}
                    placeholder="e.g. Odisha"
                    required
                  />
                  <Field
                    label="Listing Limit *"
                    name="listingLimit"
                    type="number"
                    value={formData.listingLimit}
                    onChange={handleChange}
                    min="1"
                    required
                  />
                  <Field
                    label="Worker Limit *"
                    name="workerLimit"
                    type="number"
                    value={formData.workerLimit}
                    onChange={handleChange}
                    min="1"
                    required
                  />
                </div>
              </section>

              <section className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">
                    tune
                  </span>
                  <h2 className="text-lg font-semibold text-primary">
                    Allowed Listing Types
                  </h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {CATEGORY_ORDER.map((type) => {
                    const selected =
                      formData.allowedListingTypes.includes(type);
                    return (
                      <button
                        key={type}
                        type="button"
                        onClick={() => toggleListingType(type)}
                        className={`rounded-2xl border p-4 text-left transition-colors ${
                          selected
                            ? "border-primary bg-primary/5 shadow-sm"
                            : "border-gray-200 hover:border-primary/30 hover:bg-gray-50"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <span className="material-symbols-outlined text-primary">
                            {type === "park"
                              ? "park"
                              : type === "event"
                                ? "celebration"
                                : type === "cinema"
                                  ? "movie"
                                  : "temple_hindu"}
                          </span>
                          <span
                            className={`material-symbols-outlined ${
                              selected ? "text-primary" : "text-gray-300"
                            }`}
                          >
                            {selected ? "check_circle" : "radio_button_unchecked"}
                          </span>
                        </div>
                        <p className="font-semibold text-gray-800">
                          {getCategoryLabel(type)}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          Allow this admin to create and manage {type} listings.
                        </p>
                      </button>
                    );
                  })}
                </div>
              </section>

              <div className="flex gap-3 pt-4 border-t">
                <Link
                  href="/admin"
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-center"
                >
                  Cancel
                </Link>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <span className="material-symbols-outlined text-lg animate-spin">
                        progress_activity
                      </span>
                      Creating...
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-lg">
                        person_add
                      </span>
                      Create Admin Account
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  name,
  value,
  onChange,
  type = "text",
  placeholder,
  ...rest
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
        {...rest}
      />
    </div>
  );
}
