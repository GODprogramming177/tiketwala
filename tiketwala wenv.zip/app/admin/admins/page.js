"use client";

import { useEffect, useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import { CATEGORY_ORDER, getCategoryLabel } from "@/lib/listingUtils";

export default function SuperadminAdminsPage() {
  const router = useRouter();
  const { admin, loading: authLoading, authHeaders, isSuperAdmin } = useAdminAuth();

  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    businessName: "",
    listingLimit: "",
    workerLimit: "",
    allowedListingTypes: []
  });

  useEffect(() => {
    if (!authLoading && (!admin || !isSuperAdmin())) {
      router.replace("/admin/login");
    }
  }, [admin, authLoading, isSuperAdmin, router]);

  useEffect(() => {
    if (admin && isSuperAdmin()) {
      fetchAdmins();
    }
  }, [admin, isSuperAdmin]);

  const fetchAdmins = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/superadmin/admins", {
        headers: authHeaders(),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to fetch admins");
      }
      setAdmins(data.admins || []);
    } catch (error) {
      toast.error(error.message || "Unable to load admins");
    } finally {
      setLoading(false);
    }
  };

  const filteredAdmins = useMemo(() => {
    if (!searchQuery.trim()) return admins;
    const q = searchQuery.toLowerCase();
    return admins.filter(
      (a) =>
        a.name?.toLowerCase().includes(q) ||
        a.email?.toLowerCase().includes(q) ||
        a.businessName?.toLowerCase().includes(q) ||
        a.phone?.toLowerCase().includes(q)
    );
  }, [admins, searchQuery]);

  const resetForm = () => {
    setEditingAdmin(null);
    setShowModal(false);
    setFormData({
      name: "",
      phone: "",
      businessName: "",
      listingLimit: "",
      workerLimit: "",
      allowedListingTypes: []
    });
  };

  const handleEdit = (user) => {
    setEditingAdmin(user);
    setFormData({
      name: user.name || "",
      phone: user.phone || "",
      businessName: user.businessName || "",
      listingLimit: user.listingLimit || 1,
      workerLimit: user.workerLimit || 1,
      allowedListingTypes: user.allowedListingTypes || []
    });
    setShowModal(true);
  };

  const toggleListingType = (type) => {
    setFormData((prev) => {
      const current = prev.allowedListingTypes || [];
      if (current.includes(type)) {
        return { ...prev, allowedListingTypes: current.filter((t) => t !== type) };
      }
      return { ...prev, allowedListingTypes: [...current, type] };
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!formData.name || !formData.businessName) {
      toast.error("Name and Business Name are required");
      return;
    }
    if (formData.allowedListingTypes.length === 0) {
      toast.error("At least one listing type must be allowed");
      return;
    }

    setSaving(true);
    try {
      const response = await fetch("/api/superadmin/admins", {
        method: "PATCH",
        headers: authHeaders(),
        body: JSON.stringify({
          userId: editingAdmin._id,
          businessId: editingAdmin.businessId,
          name: formData.name,
          phone: formData.phone,
          businessName: formData.businessName,
          listingLimit: formData.listingLimit,
          workerLimit: formData.workerLimit,
          allowedListingTypes: formData.allowedListingTypes,
        }),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to update admin");
      }

      toast.success("Admin updated successfully");
      await fetchAdmins();
      resetForm();
    } catch (error) {
      toast.error(error.message || "Unable to update admin");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (user) => {
    if (!confirm(`Are you sure you want to permanently delete admin "${user.name}" and their business? This action cannot be undone.`)) {
      return;
    }

    try {
      const params = new URLSearchParams({ userId: user._id, businessId: user.businessId });
      const response = await fetch(`/api/superadmin/admins?${params.toString()}`, {
        method: "DELETE",
        headers: authHeaders(),
      });
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Failed to delete admin");
      }
      toast.success("Admin and business deleted permanently");
      await fetchAdmins();
    } catch (error) {
      toast.error(error.message || "Unable to delete admin");
    }
  };

  const handleToggleActive = async (user) => {
    const newStatus = !user.businessActive;
    try {
      const response = await fetch("/api/superadmin/admins", {
        method: "PATCH",
        headers: authHeaders(),
        body: JSON.stringify({
          userId: user._id,
          businessId: user.businessId,
          name: user.name,
          phone: user.phone,
          businessName: user.businessName,
          listingLimit: user.listingLimit,
          workerLimit: user.workerLimit,
          allowedListingTypes: user.allowedListingTypes,
          active: newStatus,
        }),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to update admin status");
      }

      toast.success(newStatus ? "Admin activated" : "Admin deactivated");
      await fetchAdmins();
    } catch (error) {
      toast.error(error.message || "Unable to update status");
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  if (!admin || !isSuperAdmin()) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar isAdmin />
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Header with search and add button */}
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-3xl font-bold text-primary">Manage Admins</h1>
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold">
                  {admins.length} total
                </span>
              </div>
              <p className="text-gray-500 mt-2">
                Add, update, and delete admin accounts. Control their business limits and permissions.
              </p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {/* Search Bar */}
              <div className="relative">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">
                  search
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search admins..."
                  className="pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/30 bg-white w-[240px] text-sm transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <span className="material-symbols-outlined text-lg">close</span>
                  </button>
                )}
              </div>
              <Link
                href="/admin/register"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all shadow-md hover:shadow-lg font-medium"
              >
                <span className="material-symbols-outlined text-xl">person_add</span>
                Add Admin
              </Link>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider">Total Admins</p>
              <p className="text-2xl font-bold text-primary mt-1">{admins.length}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider">Active</p>
              <p className="text-2xl font-bold text-green-600 mt-1">
                {admins.filter(a => a.businessActive).length}
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider">Inactive</p>
              <p className="text-2xl font-bold text-red-500 mt-1">
                {admins.filter(a => !a.businessActive).length}
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
              <p className="text-xs text-gray-500 uppercase tracking-wider">Search Results</p>
              <p className="text-2xl font-bold text-gray-700 mt-1">{filteredAdmins.length}</p>
            </div>
          </div>

          {/* Admin Cards/Table */}
          <div className="bg-white rounded-2xl shadow-md overflow-hidden border border-gray-100">
            {loading ? (
              <div className="p-12 text-center">
                <span className="material-symbols-outlined text-5xl text-gray-300 animate-spin">
                  progress_activity
                </span>
                <p className="text-gray-500 mt-3">Loading admins...</p>
              </div>
            ) : filteredAdmins.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[960px]">
                  <thead className="bg-gradient-to-r from-primary/5 to-primary/10">
                    <tr>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">#</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Admin</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Business</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Limits</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Contact</th>
                      <th className="text-left py-4 px-5 font-semibold text-primary text-sm">Status</th>
                      <th className="text-right py-4 px-5 font-semibold text-primary text-sm">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredAdmins.map((adminUser, idx) => (
                      <tr key={adminUser._id} className="hover:bg-gray-50/80 transition-colors group">
                        <td className="py-4 px-5">
                          <span className="text-gray-400 text-sm font-mono">{idx + 1}</span>
                        </td>
                        <td className="py-4 px-5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                              <span className="text-primary font-bold text-sm">
                                {adminUser.name?.charAt(0)?.toUpperCase() || "A"}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-800">{adminUser.name}</p>
                              <p className="text-sm text-gray-500">{adminUser.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-5">
                          <p className="text-gray-700 font-medium">{adminUser.businessName}</p>
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            {adminUser.allowedListingTypes?.slice(0, 3).map(type => (
                              <span key={type} className="px-2 py-0.5 bg-primary/5 text-xs text-primary rounded-full font-medium">
                                {getCategoryLabel(type)}
                              </span>
                            ))}
                            {adminUser.allowedListingTypes?.length > 3 && (
                              <span className="px-2 py-0.5 bg-gray-100 text-xs text-gray-500 rounded-full">
                                +{adminUser.allowedListingTypes.length - 3} more
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-5">
                          <div className="space-y-1">
                            <p className="text-sm text-gray-600 flex items-center gap-1.5">
                              <span className="material-symbols-outlined text-[16px] text-gray-400">list</span>
                              Listings: <span className="font-semibold text-gray-800">{adminUser.listingLimit}</span>
                            </p>
                            <p className="text-sm text-gray-600 flex items-center gap-1.5">
                              <span className="material-symbols-outlined text-[16px] text-gray-400">groups</span>
                              Workers: <span className="font-semibold text-gray-800">{adminUser.workerLimit}</span>
                            </p>
                          </div>
                        </td>
                        <td className="py-4 px-5 text-gray-700 text-sm">
                          {adminUser.phone ? (
                            <div className="flex items-center gap-1.5">
                              <span className="material-symbols-outlined text-[16px] text-gray-400">phone</span>
                              {adminUser.phone}
                            </div>
                          ) : (
                            <span className="text-gray-400 italic">Not provided</span>
                          )}
                        </td>
                        <td className="py-4 px-5">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
                            adminUser.businessActive 
                              ? "bg-green-50 text-green-700 border border-green-200" 
                              : "bg-red-50 text-red-600 border border-red-200"
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              adminUser.businessActive ? "bg-green-500" : "bg-red-500"
                            }`}></span>
                            {adminUser.businessActive ? "Active" : "Inactive"}
                          </span>
                        </td>
                        <td className="py-4 px-5">
                          <div className="flex items-center justify-end gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => handleEdit(adminUser)}
                              className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                              title="Edit Admin"
                            >
                              <span className="material-symbols-outlined text-xl">edit</span>
                            </button>
                            <button
                              onClick={() => handleToggleActive(adminUser)}
                              className={`p-2 rounded-lg transition-colors ${
                                adminUser.businessActive
                                  ? "text-amber-500 hover:bg-amber-50"
                                  : "text-green-600 hover:bg-green-50"
                              }`}
                              title={adminUser.businessActive ? "Deactivate" : "Activate"}
                            >
                              <span className="material-symbols-outlined text-xl">
                                {adminUser.businessActive ? "block" : "check_circle"}
                              </span>
                            </button>
                            <button
                              onClick={() => handleDelete(adminUser)}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete Admin"
                            >
                              <span className="material-symbols-outlined text-xl">delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-12 text-center">
                {searchQuery ? (
                  <>
                    <span className="material-symbols-outlined text-5xl text-gray-300">
                      search_off
                    </span>
                    <p className="text-gray-500 mt-3">No admins match "{searchQuery}"</p>
                    <button
                      onClick={() => setSearchQuery("")}
                      className="mt-3 text-primary hover:underline text-sm"
                    >
                      Clear search
                    </button>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-5xl text-gray-300">
                      groups
                    </span>
                    <p className="text-gray-500 mt-3">No admins have been created yet.</p>
                    <Link
                      href="/admin/register"
                      className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors text-sm"
                    >
                      <span className="material-symbols-outlined text-lg">person_add</span>
                      Create First Admin
                    </Link>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Edit Modal */}
          {showModal && (
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
                <div className="p-6 border-b flex items-start justify-between gap-4 sticky top-0 bg-white z-10 rounded-t-2xl">
                  <div>
                    <h2 className="text-xl font-semibold text-primary">Edit Admin Details</h2>
                    <p className="text-sm text-gray-500 mt-1">
                      Update {editingAdmin?.name}'s account and business limits.
                    </p>
                  </div>
                  <button onClick={resetForm} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <InputField
                      label="Admin Full Name"
                      value={formData.name}
                      onChange={(val) => setFormData((prev) => ({ ...prev, name: val }))}
                      required
                    />
                    <InputField
                      label="Admin Phone"
                      value={formData.phone}
                      onChange={(val) => setFormData((prev) => ({ ...prev, phone: val }))}
                    />
                    <InputField
                      label="Business Name"
                      value={formData.businessName}
                      onChange={(val) => setFormData((prev) => ({ ...prev, businessName: val }))}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <InputField
                      label="Listing Limit"
                      type="number"
                      min="1"
                      value={formData.listingLimit}
                      onChange={(val) => setFormData((prev) => ({ ...prev, listingLimit: val }))}
                      required
                    />
                    <InputField
                      label="Worker Limit"
                      type="number"
                      min="1"
                      value={formData.workerLimit}
                      onChange={(val) => setFormData((prev) => ({ ...prev, workerLimit: val }))}
                      required
                    />
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                       Allowed Categories
                    </label>
                    <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto border p-3 rounded-xl bg-gray-50/50">
                      {CATEGORY_ORDER.map((type) => {
                        const isSelected = formData.allowedListingTypes.includes(type);
                        return (
                          <div
                            key={type}
                            onClick={() => toggleListingType(type)}
                            className={`flex items-center gap-2 p-2.5 rounded-lg cursor-pointer transition-all border ${
                              isSelected
                                ? "bg-primary/5 border-primary text-primary shadow-sm"
                                : "hover:bg-white border-transparent hover:border-gray-200"
                            }`}
                          >
                            <span className="material-symbols-outlined text-[20px]">
                              {isSelected ? "check_box" : "check_box_outline_blank"}
                            </span>
                            <span className="text-sm font-medium select-none">
                              {getCategoryLabel(type)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-6 border-t mt-6">
                    <button
                      type="button"
                      onClick={resetForm}
                      className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="flex-1 px-4 py-2.5 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-60 font-medium flex items-center justify-center gap-2"
                    >
                      {saving ? (
                        <>
                          <span className="material-symbols-outlined text-lg animate-spin">progress_activity</span>
                          Saving...
                        </>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-lg">check</span>
                          Update Admin
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InputField({ label, value, onChange, type = "text", placeholder, ...rest }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/30 transition-all bg-white"
        {...rest}
      />
    </div>
  );
}
