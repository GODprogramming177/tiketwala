"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import { getTypeIcon } from "@/lib/typeIcons";

function buildEmptySlot() {
  return {
    startTime: "09:00",
    endTime: "10:00",
    capacity: 100,
    available: true,
  };
}

export default function AdminSlotsPage() {
  const router = useRouter();
  const {
    admin,
    loading: authLoading,
    isSuperAdmin,
    authHeaders,
  } = useAdminAuth();
  const [listings, setListings] = useState([]);
  const [selectedListing, setSelectedListing] = useState(null);
  const [slots, setSlots] = useState([]);
  const [defaultSlots, setDefaultSlots] = useState([]);
  const [selectedDate, setSelectedDate] = useState(
    new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 10),
  );
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState(null);
  const [editMode, setEditMode] = useState("template");
  const [loading, setLoading] = useState(true);
  const [slotLoading, setSlotLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showAddSlot, setShowAddSlot] = useState(false);
  const [newSlot, setNewSlot] = useState(buildEmptySlot());
  const [hasDateOverride, setHasDateOverride] = useState(false);

  useEffect(() => {
    if (!authLoading && !admin) {
      router.push("/admin/login");
    }
  }, [admin, authLoading, router]);

  useEffect(() => {
    if (admin) {
      fetchListings();
    }
  }, [admin]);

  useEffect(() => {
    if (selectedListing) {
      if (selectedListing.subCategories && selectedListing.subCategories.length > 0) {
        // Only set if not already set to a valid sub-category of this listing
        const exists = selectedListing.subCategories.some(sub => sub.id === selectedSubCategoryId);
        if (!exists) {
            setSelectedSubCategoryId(selectedListing.subCategories[0].id);
        }
      } else {
        setSelectedSubCategoryId(null);
      }
      // Ensure we don't fetch before the effect resolves subcategory
    }
  }, [selectedListing]);

  useEffect(() => {
    if (selectedListing) {
       // Avoid fetching if listing has subcategories but selectedSubCategoryId hasn't been set yet
       if (selectedListing.subCategories && selectedListing.subCategories.length > 0 && !selectedSubCategoryId) {
           return;
       }
       fetchSlotEditorState();
    }
  }, [selectedListing, editMode, selectedDate, selectedSubCategoryId]);

  const fetchListings = async () => {
    try {
      let url = "/api/listings";
      if (!isSuperAdmin() && admin?.id) {
        url += `?ownerId=${admin.id}`;
      }
      const response = await fetch(url, { headers: authHeaders() });
      const data = await response.json();
      const nextListings = Array.isArray(data) ? data : [];
      setListings(nextListings);
      if (nextListings.length > 0) {
        setSelectedListing(nextListings[0]);
      }
    } catch (error) {
      console.error("Failed to fetch listings:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSlotEditorState = async () => {
    if (!selectedListing) {
      return;
    }

    setSlotLoading(true);

    try {
      let modeQuery =
        editMode === "date"
          ? `?id=${selectedListing.id}&date=${selectedDate}&mode=template`
          : `?id=${selectedListing.id}&mode=template`;
          
      if (selectedSubCategoryId) {
          modeQuery += `&subCategoryId=${selectedSubCategoryId}`;
      }
      
      const response = await fetch(`/api/slots${modeQuery}`, {
        headers: authHeaders(),
      });
      const data = await response.json();

      const activeSlots =
        editMode === "date" ? data.slots || [] : data.defaultSlots || data.slots || [];

      setSlots(
        activeSlots.map((slot) => ({
          startTime: slot.startTime,
          endTime: slot.endTime,
          capacity: slot.capacity,
          available: slot.available !== false,
        })),
      );
      setDefaultSlots(data.defaultSlots || []);
      setHasDateOverride(Boolean(data.hasDateOverride));
    } catch (error) {
      console.error("Failed to fetch slots:", error);
      toast.error("Unable to load slot settings");
    } finally {
      setSlotLoading(false);
    }
  };

  const handleAddSlot = () => {
    if (!newSlot.startTime || !newSlot.endTime) {
      return;
    }

    setSlots((prev) =>
      [...prev, { ...newSlot, capacity: Number(newSlot.capacity) || 100 }]
        .sort((a, b) => a.startTime.localeCompare(b.startTime)),
    );
    setNewSlot(buildEmptySlot());
    setShowAddSlot(false);
  };

  const handleSave = async () => {
    if (!selectedListing) {
      return;
    }

    setSaving(true);
    try {
      const response = await fetch("/api/slots", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
          listingId: selectedListing.id,
          subCategoryId: selectedSubCategoryId,
          mode: editMode === "date" ? "date" : "template",
          date: editMode === "date" ? selectedDate : undefined,
          slots,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to save slots");
      }
      toast.success(
        editMode === "date"
          ? "Date-specific slots saved"
          : "Default slot schedule saved",
      );
      await fetchSlotEditorState();
    } catch (error) {
      toast.error(error.message || "Unable to save slots");
    } finally {
      setSaving(false);
    }
  };

  const updateSlot = (index, field, value) => {
    setSlots((prev) =>
      prev.map((slot, currentIndex) =>
        currentIndex === index
          ? {
              ...slot,
              [field]: field === "capacity" ? Number(value) || 1 : value,
            }
          : slot,
      ),
    );
  };

  const toggleSlotAvailability = (index) => {
    setSlots((prev) =>
      prev.map((slot, currentIndex) =>
        currentIndex === index
          ? { ...slot, available: !slot.available }
          : slot,
      ),
    );
  };

  const deleteSlot = (index) => {
    setSlots((prev) => prev.filter((_, currentIndex) => currentIndex !== index));
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-4xl text-primary animate-spin">
          progress_activity
        </span>
      </div>
    );
  }

  if (!admin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-primary">Manage Slots</h1>
            <p className="text-gray-500 mt-1">
              Save one default schedule for every day, then override specific
              dates only when needed.
            </p>
          </div>

          {loading ? (
            <div className="bg-white rounded-xl shadow-md p-8 text-center">
              <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                progress_activity
              </span>
              <p className="text-gray-500 mt-2">Loading...</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              <div className="md:col-span-1">
                <div className="bg-white rounded-2xl shadow-md overflow-hidden">
                  <div className="p-4 bg-accent border-b">
                    <h2 className="font-semibold text-primary">
                      Select Listing
                    </h2>
                  </div>
                  <div className="divide-y">
                    {listings.map((listing) => (
                      <button
                        key={listing.id}
                        onClick={() => setSelectedListing(listing)}
                        className={`w-full p-4 text-left flex items-center gap-3 transition-colors ${
                          selectedListing?.id === listing.id
                            ? "bg-primary/5 border-l-4 border-primary"
                            : "hover:bg-gray-50"
                        }`}
                      >
                        <div
                          className={`p-2 rounded-lg ${
                            selectedListing?.id === listing.id
                              ? "bg-primary text-white"
                              : "bg-accent text-primary"
                          }`}
                        >
                          <span className="material-symbols-outlined">
                            {getTypeIcon(listing.type)}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-gray-800">
                            {listing.name}
                          </p>
                          <p className="text-sm text-gray-500">
                            {listing.type}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="md:col-span-2">
                {selectedListing ? (
                  <div className="bg-white rounded-2xl shadow-md overflow-hidden">
                    <div className="p-5 border-b bg-accent/80 space-y-4">
                      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                        <div>
                          <h2 className="font-semibold text-xl text-primary">
                            {selectedListing.name}
                          </h2>
                          
                          {selectedListing.subCategories && selectedListing.subCategories.length > 0 && (
                            <div className="mt-2 mb-3">
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Sub-Category
                                </label>
                                <select
                                    value={selectedSubCategoryId || ""}
                                    onChange={(e) => setSelectedSubCategoryId(e.target.value)}
                                    className="w-full sm:w-auto px-3 py-1.5 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm"
                                >
                                    {selectedListing.subCategories.map((sub) => (
                                        <option key={sub.id} value={sub.id}>{sub.name}</option>
                                    ))}
                                </select>
                            </div>
                          )}

                          <p className="text-sm text-gray-500 mt-1">
                            {editMode === "template"
                              ? "This default schedule applies to every upcoming date."
                              : hasDateOverride
                                ? "You are editing a saved date-specific override."
                                : "This date currently follows the default schedule until you save an override."}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            onClick={() => setEditMode("template")}
                            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                              editMode === "template"
                                ? "bg-primary text-white"
                                : "bg-white text-gray-700 border border-gray-200"
                            }`}
                          >
                            Default Schedule
                          </button>
                          <button
                            onClick={() => setEditMode("date")}
                            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                              editMode === "date"
                                ? "bg-primary text-white"
                                : "bg-white text-gray-700 border border-gray-200"
                            }`}
                          >
                            Custom Date
                          </button>
                          {editMode === "date" && (
                            <input
                              type="date"
                              value={selectedDate}
                              onChange={(event) =>
                                setSelectedDate(event.target.value)
                              }
                              className="px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                            />
                          )}
                          <button
                            onClick={() => setShowAddSlot(true)}
                            className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                          >
                            <span className="material-symbols-outlined">add</span>
                            Add Slot
                          </button>
                          <button
                            onClick={handleSave}
                            disabled={saving}
                            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-60"
                          >
                            <span className="material-symbols-outlined">
                              save
                            </span>
                            {saving ? "Saving..." : "Save"}
                          </button>
                        </div>
                      </div>

                      {editMode === "date" && defaultSlots.length > 0 && (
                        <div className="rounded-2xl bg-white border border-gray-200 p-4">
                          <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">
                            Default Schedule Reference
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {defaultSlots.map((slot) => (
                              <span
                                key={`${slot.startTime}-${slot.endTime}`}
                                className="px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-sm"
                              >
                                {slot.time}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {slotLoading ? (
                      <div className="p-8 text-center">
                        <span className="material-symbols-outlined text-4xl text-gray-300 animate-spin">
                          progress_activity
                        </span>
                        <p className="text-gray-500 mt-2">
                          Loading slot editor...
                        </p>
                      </div>
                    ) : slots.length > 0 ? (
                      <div className="p-5 space-y-3">
                        {slots.map((slot, index) => (
                          <div
                            key={`${slot.startTime}-${slot.endTime}-${index}`}
                            className={`rounded-2xl border p-4 ${
                              slot.available
                                ? "border-green-200 bg-green-50/60"
                                : "border-red-200 bg-red-50/60"
                            }`}
                          >
                            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                              <InlineField
                                label="Start"
                                type="time"
                                value={slot.startTime}
                                onChange={(value) =>
                                  updateSlot(index, "startTime", value)
                                }
                              />
                              <InlineField
                                label="End"
                                type="time"
                                value={slot.endTime}
                                onChange={(value) =>
                                  updateSlot(index, "endTime", value)
                                }
                              />
                              <InlineField
                                label="Capacity"
                                type="number"
                                value={slot.capacity}
                                onChange={(value) =>
                                  updateSlot(index, "capacity", value)
                                }
                                min="1"
                              />
                              <div className="flex items-end gap-2">
                                <button
                                  type="button"
                                  onClick={() => toggleSlotAvailability(index)}
                                  className={`flex-1 px-3 py-2 rounded-lg border transition-colors ${
                                    slot.available
                                      ? "border-red-200 text-red-600 hover:bg-red-50"
                                      : "border-green-200 text-green-600 hover:bg-green-50"
                                  }`}
                                >
                                  {slot.available
                                    ? "Exclude"
                                    : "Include"}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => deleteSlot(index)}
                                  className="px-3 py-2 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 transition-colors"
                                  title="Delete slot"
                                >
                                  <span className="material-symbols-outlined">
                                    delete
                                  </span>
                                </button>
                              </div>
                            </div>
                            <div className="mt-3 flex items-center gap-2 text-sm">
                              <span
                                className={`material-symbols-outlined ${
                                  slot.available
                                    ? "text-green-600"
                                    : "text-red-500"
                                }`}
                              >
                                {slot.available ? "check_circle" : "remove_circle"}
                              </span>
                              <span
                                className={
                                  slot.available
                                    ? "text-green-700"
                                    : "text-red-600"
                                }
                              >
                                {slot.available
                                  ? "This slot will be available after save."
                                  : "This slot will be removed after save."}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-8 text-center">
                        <span className="material-symbols-outlined text-6xl text-gray-300">
                          schedule
                        </span>
                        <p className="text-xl text-gray-500 mt-4">
                          No slots configured
                        </p>
                        <p className="text-gray-400">
                          Click "Add Slot" and then save to publish this
                          schedule.
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="bg-white rounded-xl shadow-md p-8 text-center">
                    <span className="material-symbols-outlined text-6xl text-gray-300">
                      touch_app
                    </span>
                    <p className="text-xl text-gray-500 mt-4">
                      Select a listing
                    </p>
                    <p className="text-gray-400">
                      Choose a listing from the left to manage its slots.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {showAddSlot && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-2xl shadow-xl max-w-md w-full">
                <div className="p-6 border-b">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold text-primary">
                      Add New Slot
                    </h2>
                    <button
                      onClick={() => setShowAddSlot(false)}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <span className="material-symbols-outlined">close</span>
                    </button>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <InlineField
                    label="Start Time"
                    type="time"
                    value={newSlot.startTime}
                    onChange={(value) =>
                      setNewSlot((prev) => ({ ...prev, startTime: value }))
                    }
                  />
                  <InlineField
                    label="End Time"
                    type="time"
                    value={newSlot.endTime}
                    onChange={(value) =>
                      setNewSlot((prev) => ({ ...prev, endTime: value }))
                    }
                  />
                  <InlineField
                    label="Capacity"
                    type="number"
                    value={newSlot.capacity}
                    onChange={(value) =>
                      setNewSlot((prev) => ({
                        ...prev,
                        capacity: Number(value) || 1,
                      }))
                    }
                    min="1"
                  />

                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowAddSlot(false)}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddSlot}
                      className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                    >
                      Add Slot
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InlineField({ label, value, onChange, type = "text", ...rest }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
        {...rest}
      />
    </div>
  );
}
