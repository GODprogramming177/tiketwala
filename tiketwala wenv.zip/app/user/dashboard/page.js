"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";
import TicketQR from "@/components/TicketQR";

export default function CustomerDashboard() {
  const router = useRouter();
  const {
    customer,
    isAuthenticated,
    loading: authLoading,
    authHeaders,
  } = useCustomerAuth();

  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/booking/login");
    }
  }, [authLoading, isAuthenticated, router]);

  useEffect(() => {
    if (customer?.email) {
      fetchUserBookings();
    }
  }, [customer]);

  const fetchUserBookings = async () => {
    try {
      setLoading(true);
      const res = await fetch(
        `/api/bookings?customerEmail=${encodeURIComponent(customer.email)}`,
        {
          headers: authHeaders(),
        },
      );
      const data = await res.json();
      if (data.success) {
        setBookings(data.bookings);
      }
    } catch (error) {
      console.error("Failed to fetch user bookings:", error);
    } finally {
      setLoading(false);
    }
  };

  if (authLoading || (loading && bookings.length === 0)) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center">
            <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4"></div>
            <p className="text-gray-500">Loading your profile...</p>
          </div>
        </div>
      </div>
    );
  }

  // Split bookings into upcoming and past based on current date
  const todayIso = new Date().toISOString().slice(0, 10);
  const upcomingBookings = bookings.filter((b) => {
    const bookingDate = b.bookingDateIso || b.slot?.slice(0, 10) || "";
    return bookingDate >= todayIso;
  });
  const pastBookings = bookings.filter((b) => {
    const bookingDate = b.bookingDateIso || b.slot?.slice(0, 10) || "";
    return bookingDate && bookingDate < todayIso;
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      {/* Profile Header */}
      <div className="bg-primary text-white py-12 px-4 shadow-md">
        <div className="max-w-5xl mx-auto flex items-center gap-6">
          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center text-3xl font-bold uppercase backdrop-blur-sm border-2 border-white/30">
            {customer?.name?.charAt(0) || "U"}
          </div>
          <div>
            <h1 className="text-3xl font-bold">{customer?.name}</h1>
            <p className="text-white/80">{customer?.email}</p>
            <span className="inline-block mt-2 px-3 py-1 bg-white/10 text-xs font-medium rounded-full border border-white/20">
              Verified Customer Member
            </span>
          </div>
        </div>
      </div>

      {/* Main Content Dashboard */}
      <div className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span className="material-symbols-outlined text-primary">
            local_activity
          </span>
          My Tickets
        </h2>

        {bookings.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-gray-100">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-gray-100">
              <span className="material-symbols-outlined text-4xl text-gray-300">
                receipt_long
              </span>
            </div>
            <h3 className="text-lg font-bold text-gray-700">
              No Bookings Found
            </h3>
            <p className="text-gray-500 max-w-sm mx-auto mt-2">
              You haven&apos;t booked any experiences yet. Discover amazing
              parks, events, cinemas, and temples!
            </p>
            <button
              onClick={() => router.push("/")}
              className="mt-6 px-6 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors font-medium inline-flex items-center gap-2"
            >
              <span className="material-symbols-outlined text-sm">explore</span>
              Explore Experiences
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Upcoming Section */}
            {upcomingBookings.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-4 px-1">
                  Upcoming ({upcomingBookings.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {upcomingBookings.map((booking) => (
                    <BookingCard
                      key={booking._id}
                      booking={booking}
                      onViewTicket={() => setSelectedTicket(booking)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Past Section */}
            {pastBookings.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-500 mb-4 px-1">
                  Past Bookings
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 opacity-75">
                  {pastBookings.map((booking) => (
                    <BookingCard
                      key={booking._id}
                      booking={booking}
                      onViewTicket={() => setSelectedTicket(booking)}
                      isPast
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Ticket Modal */}
      {selectedTicket && (
        <TicketQR
          booking={selectedTicket}
          allowThermalPrint={false}
          onClose={() => setSelectedTicket(null)}
        />
      )}
    </div>
  );
}

function BookingCard({ booking, onViewTicket, isPast }) {
  const ticketStatus =
    booking.ticketStatus || (booking.scanned ? "used" : "valid");
  const isExpired = ticketStatus === "expired" || ticketStatus === "used";

  const statusConfig = {
    valid: {
      label: "Valid",
      bg: "bg-green-100",
      text: "text-green-700",
      icon: "check_circle",
    },
    active: {
      label: "Active (Inside)",
      bg: "bg-blue-100",
      text: "text-blue-700",
      icon: "login",
    },
    expired: {
      label: "Expired",
      bg: "bg-red-100",
      text: "text-red-700",
      icon: "block",
    },
    used: {
      label: "Used",
      bg: "bg-gray-200",
      text: "text-gray-600",
      icon: "done_all",
    },
  };

  const status = statusConfig[ticketStatus] || statusConfig.valid;

  return (
    <div
      className={`bg-white rounded-2xl p-5 shadow-sm border transition-shadow hover:shadow-md flex flex-col justify-between ${
        isExpired
          ? "border-red-100 opacity-75"
          : isPast
            ? "border-gray-100"
            : "border-primary/10"
      }`}
    >
      <div>
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2.5 py-1 bg-gray-100 text-gray-600 rounded-md uppercase tracking-wider">
              {booking.listingType}
            </span>
            <span
              className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${status.bg} ${status.text}`}
            >
              <span className="material-symbols-outlined text-[12px]">
                {status.icon}
              </span>
              {status.label}
            </span>
          </div>
          <span className="text-primary font-bold">₹{booking.totalAmount}</span>
        </div>

        <h4
          className="font-bold text-gray-800 text-lg leading-tight mb-1 line-clamp-1"
          title={booking.listingName}
        >
          {booking.listingName}
        </h4>

        <div className="space-y-1.5 mt-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span className="material-symbols-outlined text-[18px]">
              calendar_today
            </span>
            {booking.date}
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span className="material-symbols-outlined text-[18px]">
              schedule
            </span>
            {booking.slot}
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span className="material-symbols-outlined text-[18px]">group</span>
            {booking.quantity} {booking.quantity === 1 ? "Person" : "People"}
          </div>
          {Array.isArray(booking.selectedAddOns) &&
            booking.selectedAddOns.length > 0 && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span className="material-symbols-outlined text-[18px]">
                  add_circle
                </span>
                {booking.selectedAddOns.map((addOn) => addOn.name).join(", ")}
              </div>
            )}

          {/* Entry/Exit timestamps */}
          {booking.entryAt && (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <span className="material-symbols-outlined text-[18px]">
                login
              </span>
              Entry:{" "}
              {new Date(booking.entryAt).toLocaleString("en-IN", {
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
              })}
            </div>
          )}
          {booking.exitAt && (
            <div className="flex items-center gap-2 text-sm text-blue-600">
              <span className="material-symbols-outlined text-[18px]">
                logout
              </span>
              Exit:{" "}
              {new Date(booking.exitAt).toLocaleString("en-IN", {
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
              })}
            </div>
          )}
        </div>
      </div>

      {isExpired ? (
        <div className="w-full mt-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 bg-red-50 text-red-600 border border-red-200 cursor-not-allowed">
          <span className="material-symbols-outlined text-[20px]">block</span>
          Ticket Expired
        </div>
      ) : (
        <button
          onClick={onViewTicket}
          className={`w-full mt-5 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors ${
            isPast
              ? "bg-gray-100 text-gray-700 hover:bg-gray-200"
              : "bg-primary/10 text-primary hover:bg-primary hover:text-white border border-primary/20 hover:border-transparent"
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">qr_code</span>
          View E-Ticket
        </button>
      )}
    </div>
  );
}
