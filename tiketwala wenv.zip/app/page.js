"use client";

import { useEffect, useMemo, useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import AppFooter from "@/components/AppFooter";
import ListingCard, { ListingCardSkeleton } from "@/components/ListingCard";
import {
  getOrderedCategories,
  getCategoryLabel,
} from "@/lib/listingUtils";
import { getDefaultImage, getTypeIcon } from "@/lib/typeIcons";

const FALLBACK_HERO_SLIDES = [
  {
    id: "fallback-park",
    title: "Fresh park escapes for the weekend",
    subtitle: "Browse family-friendly parks and open-air experiences.",
    image: getDefaultImage("park"),
    type: "park",
    location: "Discover nearby parks",
  },
  {
    id: "fallback-temple",
    title: "Plan serene temple visits",
    subtitle: "Find peaceful darshan slots and spiritual destinations.",
    image: getDefaultImage("temple"),
    type: "temple",
    location: "Temples across Odisha",
  },
  {
    id: "fallback-cinema",
    title: "Find your next cinema outing",
    subtitle: "Book shows, add-ons, and walk-in seats in one flow.",
    image: getDefaultImage("cinema"),
    type: "cinema",
    location: "Cinema halls and multiplexes",
  },
];

export default function HomePage() {
  const router = useRouter();
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef(null);
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [userLocation, setUserLocation] = useState(null);
  const [isLocating, setIsLocating] = useState(false);
  const [activeSlide, setActiveSlide] = useState(0);

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Close suggestions on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await fetch("/api/locations");
      const data = await response.json();
      const nextLocations = data.success && data.locations ? data.locations : [];
      setLocations(nextLocations);
      requestLocation(nextLocations);
    } catch (error) {
      console.error("Failed to fetch locations:", error);
      setLocations([]);
      fetchListings(activeFilter, "", null);
    }
  };

  const fetchListings = async (type, location, coords) => {
    try {
      setLoading(true);

      let url = "/api/listings";
      const params = new URLSearchParams();

      if (type !== "all") {
        params.append("type", type);
      }
      if (location) {
        params.append("location", location);
      }
      if (coords) {
        params.append("lat", coords.lat);
        params.append("lng", coords.lng);
      }

      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const response = await fetch(url);
      const data = await response.json();

      if (coords && !location && Array.isArray(data) && data.length === 0) {
        const fallbackParams = new URLSearchParams();
        if (type !== "all") {
          fallbackParams.append("type", type);
        }
        const fallbackUrl = fallbackParams.toString()
          ? `/api/listings?${fallbackParams.toString()}`
          : "/api/listings";
        const fallbackResponse = await fetch(fallbackUrl);
        const fallbackData = await fallbackResponse.json();
        setListings(Array.isArray(fallbackData) ? fallbackData : []);
        return;
      }

      setListings(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to fetch listings:", error);
      setListings([]);
    } finally {
      setLoading(false);
    }
  };

  const requestLocation = (availableLocations) => {
    if (!navigator.geolocation) {
      fetchListings(activeFilter, selectedLocation, null);
      return;
    }

    setIsLocating(true);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setUserLocation(coords);
        setIsLocating(false);

        let bestCity = "";
        let minDistance = Infinity;

        availableLocations.forEach((location) => {
          const distance = getDistance(
            coords.lat,
            coords.lng,
            location.coords[1],
            location.coords[0],
          );
          if (distance < minDistance && distance <= 100) {
            minDistance = distance;
            bestCity = location.cityStr;
          }
        });

        setSelectedLocation(bestCity);
        fetchListings(activeFilter, bestCity || "", coords);
      },
      (error) => {
        console.warn("Geolocation unavailable:", error);
        setIsLocating(false);
        fetchListings(activeFilter, selectedLocation, null);
      },
      { timeout: 5000 },
    );
  };

  const getDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) *
        Math.cos(lat2 * (Math.PI / 180)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const filteredListings = listings.filter((listing) => {
    const lookup = debouncedQuery.toLowerCase();
    if (!lookup) return true;
    return (
      listing.name.toLowerCase().includes(lookup) ||
      listing.location.toLowerCase().includes(lookup) ||
      listing.type.toLowerCase().includes(lookup)
    );
  });

  // Live search suggestions (top 6 matches for autocomplete)
  const searchSuggestions = useMemo(() => {
    if (!debouncedQuery || debouncedQuery.length < 2) return [];
    const lookup = debouncedQuery.toLowerCase();
    return listings
      .filter(
        (listing) =>
          listing.name.toLowerCase().includes(lookup) ||
          listing.location.toLowerCase().includes(lookup) ||
          listing.type.toLowerCase().includes(lookup),
      )
      .slice(0, 6);
  }, [debouncedQuery, listings]);

  const availableCategories = getOrderedCategories(
    listings.map((listing) => listing.category || listing.type),
  );

  const filterOptions = [
    { id: "all", label: "All", icon: "apps" },
    ...availableCategories.map((category) => ({
      id: category,
      label: getCategoryLabel(category, true),
      icon: getTypeIcon(getCategoryLabel(category)),
    })),
  ];

  const groupedListings = availableCategories
    .map((category) => ({
      category,
      label: getCategoryLabel(category, true),
      items: filteredListings.filter((listing) => listing.category === category),
    }))
    .filter((group) => group.items.length > 0);

  const heading = userLocation
    ? "Recommendations Near You"
    : selectedLocation
      ? `Popular in ${selectedLocation}`
      : "Explore TiketWala";

  const clearFilters = () => {
    setActiveFilter("all");
    setSearchQuery("");
    setSelectedLocation("");
    setUserLocation(null);
    fetchListings("all", "", null);
  };

  const heroSlides = useMemo(() => {
    const latestParks = listings
      .filter((listing) => listing.category === "park")
      .slice(0, 3)
      .map((listing, index) => ({
        id: listing.id,
        title: listing.name,
        subtitle:
          listing.description ||
          "Fresh air, open skies, and bookable slots on TiketWala.",
        image: listing.images?.[0] || listing.image || getDefaultImage("park"),
        type: listing.category || "park",
        location: listing.location,
        accent: index,
      }));

    return latestParks.length > 0 ? latestParks : FALLBACK_HERO_SLIDES;
  }, [listings]);

  useEffect(() => {
    const slideCount = heroSlides.length;
    if (slideCount <= 1) {
      return;
    }

    const timer = window.setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slideCount);
    }, 5000);

    return () => window.clearInterval(timer);
  }, [heroSlides]);

  useEffect(() => {
    setActiveSlide((prev) => (prev >= heroSlides.length ? 0 : prev));
  }, [heroSlides.length]);

  const currentSlide = heroSlides[activeSlide] || FALLBACK_HERO_SLIDES[0];

  const searchContent = (
    <div className="grid grid-cols-1 xl:grid-cols-[200px_1fr_auto] gap-2">
      <div className="relative">
        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
          location_on
        </span>
        <select
          value={selectedLocation}
          onChange={(event) => {
            const nextLocation = event.target.value;
            setSelectedLocation(nextLocation);
            setUserLocation(null);
            fetchListings(activeFilter, nextLocation, null);
          }}
          className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 appearance-none"
        >
          <option value="">All Locations</option>
          {locations.map((location) => (
            <option key={location.cityStr} value={location.cityStr}>
              {location.cityStr}
            </option>
          ))}
        </select>
      </div>

      <div className="relative" ref={searchRef}>
        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
          search
        </span>
        <input
          type="text"
          value={searchQuery}
          onChange={(event) => {
            setSearchQuery(event.target.value);
            setShowSuggestions(true);
          }}
          onFocus={() => {
            if (debouncedQuery.length >= 2) setShowSuggestions(true);
          }}
          placeholder="Search parks, events, cinemas, temples..."
          className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
        />

        {/* Live search suggestions dropdown */}
        {showSuggestions && searchSuggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 z-50 max-h-80 overflow-y-auto">
            {searchSuggestions.map((suggestion) => (
              <button
                key={suggestion.id}
                type="button"
                onClick={() => {
                  setShowSuggestions(false);
                  setSearchQuery("");
                  router.push(`/booking/${suggestion.id}`);
                }}
                className="w-full px-4 py-3 flex items-center gap-3 hover:bg-accent/60 transition-colors text-left border-b border-gray-50 last:border-b-0"
              >
                <img
                  src={suggestion.images?.[0] || suggestion.image}
                  alt={suggestion.name}
                  className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-gray-800 text-sm truncate">
                    {suggestion.name}
                  </p>
                  <p className="text-xs text-gray-500 truncate">
                    {suggestion.type} • {suggestion.location}
                  </p>
                </div>
                <span className="text-xs text-primary font-medium flex-shrink-0">
                  ₹{suggestion.price}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={() => requestLocation(locations)}
        className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl border border-primary/15 bg-primary text-white hover:bg-primary/90 transition-colors text-sm"
      >
        <span
          className={`material-symbols-outlined text-lg ${isLocating ? "animate-spin" : ""}`}
        >
          {isLocating ? "progress_activity" : "my_location"}
        </span>
        <span className="hidden sm:inline">
          {isLocating ? "Locating..." : "Use My Location"}
        </span>
      </button>
    </div>
  );

  const renderCards = (items) => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
      {items.map((listing) => (
        <ListingCard key={listing.id} listing={listing} />
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar searchContent={searchContent} />

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-slate-950" />
        {loading ? (
          <div className="absolute inset-0 bg-slate-900 animate-pulse" />
        ) : (
          <div
            className="absolute inset-0 bg-cover bg-center transition-all duration-700"
            style={{
              backgroundImage: `linear-gradient(120deg, rgba(2,6,23,0.72), rgba(11,60,93,0.45)), url(${currentSlide.image})`,
            }}
          />
        )}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.2),transparent_30%),radial-gradient(circle_at_bottom_left,rgba(86,148,196,0.35),transparent_28%)]" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
          <div className="grid grid-cols-1 xl:grid-cols-[1.1fr_0.9fr] gap-8 items-end">
            <div className="text-white max-w-3xl">
              {loading ? (
                <>
                  <div className="h-4 w-48 bg-white/20 rounded animate-pulse"></div>
                  <div className="h-16 w-3/4 bg-white/20 rounded mt-3 animate-pulse"></div>
                  <div className="h-6 w-1/2 bg-white/20 rounded mt-4 animate-pulse"></div>
                  <div className="flex gap-3 mt-6">
                    <div className="h-10 w-32 bg-white/20 rounded-full animate-pulse"></div>
                    <div className="h-10 w-40 bg-white/20 rounded-full animate-pulse"></div>
                  </div>
                </>
              ) : (
                <>
                  <p className="text-sm font-semibold uppercase tracking-[0.24em] text-white/70">
                    Latest Park Highlights
                  </p>
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mt-3 leading-tight">
                    {currentSlide.title}
                  </h1>
                  <p className="text-base sm:text-lg text-white/80 mt-4 max-w-2xl">
                    {currentSlide.subtitle}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 mt-6">
                    <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 backdrop-blur-sm">
                      <span className="material-symbols-outlined text-lg">
                        {getTypeIcon(currentSlide.type)}
                      </span>
                      {getCategoryLabel(currentSlide.type)}
                    </span>
                    <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 backdrop-blur-sm">
                      <span className="material-symbols-outlined text-lg">
                        location_on
                      </span>
                      {currentSlide.location}
                    </span>
                  </div>
                </>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-[28px] p-5 sm:p-6 text-white">
              {loading ? (
                <>
                  <div className="flex items-center justify-between gap-3 mb-6">
                    <div>
                      <div className="h-4 w-24 bg-white/20 rounded animate-pulse mb-2"></div>
                      <div className="h-6 w-32 bg-white/20 rounded animate-pulse"></div>
                    </div>
                    <div className="h-8 w-24 bg-white/20 rounded-2xl animate-pulse"></div>
                  </div>
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="w-full flex items-center gap-3 p-3 rounded-2xl bg-white/8 animate-pulse">
                        <div className="w-16 h-16 rounded-xl bg-white/20"></div>
                        <div className="flex-1">
                          <div className="h-5 w-3/4 bg-white/20 rounded mb-2"></div>
                          <div className="h-4 w-1/2 bg-white/20 rounded"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-white/70">Now showing</p>
                      <p className="text-xl font-semibold mt-1">
                        {heroSlides.length} featured slides
                      </p>
                    </div>
                    <div className="inline-flex items-center gap-2 px-3 py-2 rounded-2xl bg-white/10 text-sm">
                      <span className="material-symbols-outlined text-base">park</span>
                      Fresh picks
                    </div>
                  </div>

                  <div className="mt-6 space-y-3">
                    {heroSlides.map((slide, index) => (
                      <button
                        key={slide.id}
                        onClick={() => setActiveSlide(index)}
                        className={`w-full flex items-center gap-3 p-3 rounded-2xl text-left transition-all ${
                          activeSlide === index
                            ? "bg-white text-primary shadow-lg"
                            : "bg-white/8 hover:bg-white/12"
                        }`}
                      >
                        <img
                          src={slide.image}
                          alt={slide.title}
                          className="w-16 h-16 rounded-xl object-cover"
                        />
                        <div className="min-w-0">
                          <p className="font-semibold truncate">{slide.title}</p>
                          <p
                            className={`text-sm truncate ${
                              activeSlide === index ? "text-primary/70" : "text-white/70"
                            }`}
                          >
                            {slide.location}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="py-5 sm:py-6 border-b border-gray-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto scrollbar-hide pb-1">
            {filterOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => {
                  setActiveFilter(option.id);
                  fetchListings(option.id, selectedLocation, userLocation);
                }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-full whitespace-nowrap transition-all text-sm sm:text-base font-medium ${
                  activeFilter === option.id
                    ? "bg-primary text-white shadow-md"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                <span className="material-symbols-outlined text-lg">
                  {option.icon}
                </span>
                {option.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-8 sm:py-12 flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6 sm:mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">
                {heading}
              </h2>
              <p className="text-sm text-gray-500 mt-1">
                {activeFilter === "all"
                  ? "Sections stay dynamic, with parks first, then events, cinemas, and temples."
                  : `Showing ${filterOptions.find((item) => item.id === activeFilter)?.label || "results"}.`}
              </p>
            </div>
            <span className="text-gray-500 text-sm sm:text-base">
              {filteredListings.length}{" "}
              {filteredListings.length === 1 ? "result" : "results"} found
            </span>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {[...Array(6)].map((_, index) => (
                <ListingCardSkeleton key={index} />
              ))}
            </div>
          ) : filteredListings.length > 0 ? (
            activeFilter === "all" ? (
              <div className="space-y-10">
                {groupedListings.map((group) => (
                  <div key={group.category}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="material-symbols-outlined text-primary text-2xl">
                          {getTypeIcon(getCategoryLabel(group.category))}
                        </span>
                        <div>
                          <h3 className="text-lg sm:text-xl font-semibold text-primary">
                            {group.label}
                          </h3>
                          <p className="text-sm text-gray-500">
                            {group.items.length} listings available
                          </p>
                        </div>
                      </div>
                    </div>
                    {renderCards(group.items)}
                  </div>
                ))}
              </div>
            ) : (
              renderCards(filteredListings)
            )
          ) : (
            <div className="text-center py-12 sm:py-16">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="material-symbols-outlined text-4xl text-gray-400">
                  search_off
                </span>
              </div>
              <p className="text-lg sm:text-xl text-gray-600 font-medium">
                No listings found
              </p>
              <p className="text-gray-400 mt-1">
                Try adjusting your search or location filter
              </p>
              <button
                onClick={clearFilters}
                className="mt-4 px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </section>

      <AppFooter />
    </div>
  );
}
