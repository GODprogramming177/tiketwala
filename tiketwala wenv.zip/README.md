# TicketWala Codebase Documentation

Welcome to the comprehensive documentation for the **TicketWala** application. This document is designed to give you a complete, file-by-file understanding of what your current code is doing, the architecture of the platform, and a roadmap for what you need next to scale this business.

---

## 🏗️ 1. Project Architecture & File Definitions

TicketWala is built using **Next.js 14+ (App Router)**, **React**, **Tailwind CSS**, and **MongoDB**. It uses **Razorpay** for payment processing and `html5-qrcode` for digital ticket scanning.

Here is a breakdown of every single file and what it is actually doing:

### The `app` Directory (Routing & Pages)
Next.js uses folder-based routing. Every `page.js` file represents a public URL route.

- `app/layout.js`: The Root Layout. It wraps your entire application in the `AdminAuthContext` and `CustomerAuthContext` providers so that every page knows who is logged in. It also imports the global fonts (Geist) and CSS.
- `app/page.js`: The Home Page (`/`). It requests the user's GPS coordinates on load, calculates the distance to the nearest mapped cities (via `lib/locations`), auto-selects the closest city in the dropdown, and displays a categorized, filtered grid of `ListingCard` components (Parks, Temples, Events).
- `app/globals.css`: Contains your Tailwind CSS directives and custom styling variables.
- `app/booking/[id]/page.js`: The dynamic Booking Checkout Page. When users click a property, this page loads its details, mounts the `SlotGrid` to pick a time, prompts unauthenticated users to Login, and mounts the `PaymentButton` to trigger the Razorpay popup.
- `app/booking/login/page.js`: The Customer Authentication Portal. Wraps a Login/Registration form in a React `<Suspense>` boundary. It securely hashes new passwords and logs users via the `CustomerAuthContext`.
- `app/user/dashboard/page.js`: The Customer Portal. Fetches all bookings tied to the logged-in user's email, splits them into "Upcoming" and "Past" tickets, and allows the user to pull up their `TicketQR` from anywhere.
- `app/admin/login/page.js`: The Admin/Business Login Portal. Checks credentials against the `users` collection for the `owner` or `superadmin` role.
- `app/admin/dashboard/page.js`: The Business Portal. A protected route that shows live revenue stats, recent global/property bookings, and most importantly, mounts the `QRScanner` component allowing staff to physically scan customer tickets at the gate.

### The `app/api` Directory (Backend Logic)
These are your secure serverless Node.js endpoints. They connect to MongoDB.

- `api/auth/login/route.js`: Authenticates both Admins and Customers by comparing password hashes using `bcryptjs`.
- `api/auth/register/route.js`: Creates new Customer accounts, encrypting their passwords before saving them to MongoDB.
- `api/bookings/route.js`: Handles `POST` (creating new tickets after successful Razorpay payments and sending Email receipts to Admins) and `GET` (fetching booking history filtered by Admin ID or Customer Email).
- `api/listings/route.js`: Fetches the properties (Parks/Temples) from the `businesses` collection. Supported by geolocation filters.
- `api/locations/route.js`: Scrapes the database for all available cities and returns their exact longitude/latitude coordinates so the frontend can calculate distances.
- `api/order/route.js`: Communicates securely with the Razorpay Node SDK to generate a unique `order_id` required before the checkout modal can open.
- `api/slots/route.js`: Generates a rolling 14-day calendar of operational hours associated with a specific property.
- `api/stats/route.js`: Aggregates live transaction revenue and total ticket volumes for the Admin Dashboard charts.
- `api/verify-payment/route.js`: After Razorpay processes a card, this route cryptographicly verifies the `razorpay_signature` to prevent hackers from spoofing free tickets.

### The `components` Directory (Reusable UI)
- `Navbar.js`: The top navigation bar. It intelligently swaps between "Login", "Logout", "Admin Portal", and "User Dashboard" buttons depending on the exact global Auth state of the visitor.
- `ListingCard.js`: The visual card on the homepage displaying a property's image, price, title, and location.
- `SlotGrid.js`: The interactive calendar UI allowing users to tap on dates and times to reserve their arrival slot.
- `PaymentButton.js`: The "Pay ₹X" button. It handles the complex Razorpay lifecycle: creating the order, opening the popup window, handling the success callback, verifying the signature, and dispatching the ultimate MongoDB booking request.
- `TicketQR.js`: The physical E-Ticket modal shown after purchase or in the dashboard. It encrypts the `bookingId` and user details into a visual QR code using the `qrcode.react` library.
- `QRScanner.js`: The Admin tool that requests Camera permissions via `html5-qrcode` and live-scans customer phones at the entry gate, matching them to MongoDB records.

### The `lib` Directory (Utilities & State)
- `AdminAuthContext.js`: React global state manager utilizing `localStorage` to keep business owners logged in.
- `CustomerAuthContext.js`: React global state manager keeping the public ticket-buyers logged in.
- `email.js`: Configures the `nodemailer` SMTP client. Contains the beautiful HTML email templates sent to property owners when a new ticket is sold.
- `mongodb.js`: The critical singleton connector that manages the persistent connection pool to your MongoDB Atlas cluster.
- `razorpay.js`: Instantiates the secure Razorpay instance using your hidden `.env.local` keys.
- `typeIcons.js`: A simple utility that maps 'Park' to a tree icon, 'Temple' to a temple icon, etc.

---

## ⚡ 2. What the Current Code is Doing (Current State)

You currently have a **fully functional, production-ready MVP (Minimum Viable Product)**. 

1. **Live Geolocation**: The moment a user visits, the site grabs their coordinates and filters everything seamlessly.
2. **Complete Checkout Pipeline**: Real users can register an account, log in, select a property time slot, and securely pay real money via Razorpay.
3. **Automated Ticketing**: Upon payment, the user gets a dynamic QR Code ticket tied to their account Dashboard, and the business owner gets an automated Email notifying them of the revenue.
4. **Physical Gate Validation**: Business owners can log into the Admin portal on a tablet or phone, open the camera, and physically scan the customer's QR code to let them into the park/temple.

---

## 🚀 3. What You Need Next (Future Recommendations)

While the core engine is robust, here is what you **need** to implement next to scale this into a massive, consumer-facing enterprise like BookMyShow:

### A. Customer-Facing Features You Need:
1. **Automated User Email Tickets**: Currently, only the Admin receives an email alert for a booking. You need to update `lib/email.js` to also email the **Customer** a PDF or HTML copy of their QR code so they don't have to log into the website if they lose their internet connection at the park.
2. **PDF Ticket Download**: Add a "Download PDF" button to the `TicketQR.js` component so users can save/print their tickets directly to their device.
3. **Password Reset Flow**: There is currently no "Forgot Password" functionality. You need a flow involving verification emails and unique reset tokens.

### B. Business / Admin Features You Need:
1. **Property Creation & Editing Portal**: The Admin Dashboard currently only shows stats and scans tickets. You need a dedicated "Manage Listings" page where Admins can upload new photos, change ticket prices, and update opening hours without requiring a database developer to insert them manually.
2. **Refunds & Cancellations**: Razorpay supports refunds via their API. You need a UI button for customers to cancel bookings (within an allowed window) and logic to automatically process that refund.
3. **Review & Rating System**: To build trust, allow customers who have *scanned* their tickets (proven they attended) to leave a 1-to-5 star rating and comment on the property.

### C. Technical & Deployment Needs:
1. **Production MongoDB Deployment**: Ensure you are using a dedicated MongoDB Atlas cluster with strict IP Access rules and database backups enabled.
2. **CDN for Images**: Currently, images are loaded from Unsplash URLs. You need to implement an AWS S3 bucket (or Cloudinary/Vercel Blob) so property owners can upload their own venue photos securely.
3. **Production Email Server**: Ensure your `SMTP_HOST` in `.env.local` uses a production service like SendGrid, AWS SES, or Resend to avoid emails going to Spam folders.
