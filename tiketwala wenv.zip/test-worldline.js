const crypto = require("crypto");
require("dotenv").config({ path: ".env.local" });

const ENCRYPTION_KEY = process.env.WORLDLINE_ENC_KEY;
const IV = process.env.WORLDLINE_IV;
const ALGORITHM = "aes-256-cbc";

function encryptRequest(data) {
  const jsonString = typeof data === "string" ? data : JSON.stringify(data);
  const cipher = crypto.createCipheriv(
    ALGORITHM,
    Buffer.from(ENCRYPTION_KEY, "utf8"),
    Buffer.from(IV, "utf8")
  );

  let encrypted = cipher.update(jsonString, "utf8", "base64");
  encrypted += cipher.final("base64");
  return encrypted;
}

function decryptResponse(encryptedText) {
  const decipher = crypto.createDecipheriv(
    ALGORITHM,
    Buffer.from(ENCRYPTION_KEY, "utf8"),
    Buffer.from(IV, "utf8")
  );

  let decrypted = decipher.update(encryptedText, "base64", "utf8");
  decrypted += decipher.final("utf8");

  try {
    return JSON.parse(decrypted);
  } catch (err) {
    return decrypted;
  }
}

async function test() {
  const amount = "10.00"; // 10 rupees
  const invoiceNo = `INV-${Date.now()}`;
  const transactionId = crypto.randomUUID().replace(/-/g, "").substring(0, 16);
  const terminalId = process.env.WORLDLINE_SOURCE || "629";
  const tid = process.env.WORLDLINE_TID;
  const mid = process.env.WORLDLINE_MID;

  const payloadStr = JSON.stringify({
    "tid":"2532419U",
    "amount":"194",
    "organization_code":"Retail",
    "additional_attribute1":"",
    "additional_attribute2":"",
    "additional_attribute3":"",
    "invoiceNumber":"",
    "rrn":"",
    "type":"SALE",
    "cb_amt":"",
    "app_code":"",
    "tokenisedValue":"",
    "actionId":"1",
    "request_urn":"1234567890abcdef"
  });
  console.log("Payload:", payloadStr);

  const encryptedData = encryptRequest(payloadStr);
  console.log("Encrypted:", encryptedData);

  const sampleEncrypted = "E7PTQ7APFTF3XCFC2Oz7pepaB/+m7u/SvCbdCACKZRoFNlOEibIexSXiJOq9Q/VFLhyC40NIT2rCfJLa6gOTFom/EPPD4ftK1u85Zr0AqwWLGa3w36kG9mtxlWaCHIm124SEP4HjR1PwYqj/CBHR/NMVzsVz3ADH5Pv8cwLRbMVTZrmHyXR8qbkoTeiaqG9htkiT18I7aUnSjj8RDQd8Cubl2PObyM7ksXG/Odm2w25YbYgKlkiVgjAsrULFGYgzABYbLfwKW2SiL2NTJOZvA1GSOGK5Mq/J6HoTMMAne7STUuv6BDCwEfLhqf97IM2InRFccjhppKZ5XijgsPv9Le4pwEn+3RoF1b1CDP9D6ht9vrHooH1rNxwbgTNPIZhionGGZUYf+Af3VXfwCwXAIQ==";

  const requestBody = new URLSearchParams({
    source: terminalId,
    request: sampleEncrypted
  });

  const initUrl = process.env.WORLDLINE_INITIATE_URL;

  console.log("Sending POST to:", initUrl);

  try {
    const response = await fetch(initUrl, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain"
      },
      body: encryptedData
    });

    const responseText = await response.text();
    console.log("HTTP Status:", response.status);
    console.log("Raw Response:", responseText);

    let decryptedResponse;
    try {
      const parsed = JSON.parse(responseText);
      const dataToDecrypt = parsed.data ? parsed.data : responseText;
      const dec = decryptResponse(dataToDecrypt);
      console.log("Decrypted Response:", dec);
    } catch(e) {
      console.log("Could not decrypt response.", e.message);
    }
  } catch(e) {
    console.error("Fetch failed", e);
  }

  try {
    const sampleDecrypted = decryptResponse(sampleEncrypted);
    console.log("Their Decrypted Sample:", sampleDecrypted);
  } catch(e) {
    console.log("Could not decrypt their sample:", e.message);
  }
}

test();
