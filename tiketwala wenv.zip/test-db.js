const { MongoClient } = require('mongodb');
require('dotenv').config({ path: '.env.local' });

async function run() {
  const client = new MongoClient(process.env.MONGODB_URI);
  await client.connect();
  const db = client.db();
  
  const slots = await db.collection('slots').find({
    propertyId: "cf0cf96486b54c38b3ab98b5"
  }).toArray();
  
  console.log("SLOTS FOR Raja Queen (cf0cf96486b54c38b3ab98b5):");
  for (let s of slots) {
     console.log(`- start: ${s.start} | end: ${s.end} | capacity: ${s.capacity} | booked: ${s.booked} | _id: ${s._id} | subCategoryId: ${s.subCategoryId}`);
  }

  await client.close();
}

run().catch(console.error);
