/**
 * ============================================================
 * Proxy — API Security & Rate Limiting
 * ============================================================
 * Blocks direct browser access to /api/* routes, enforces rate
 * limits, and allows legitimate SSR / XHR / prefetch requests.
 *
 * Exported as a standalone module so it can be unit-tested and
 * consumed by middleware.js at the project root.
 */

import { NextResponse } from "next/server";

/* ── Configuration ─────────────────────────────────────────── */

const ALLOWED_HOSTS = new Set([
  "localhost:3000",
  "tiketwala.com",
  "www.tiketwala.com",
]);

const MAX_API_REQUESTS = 120;
const WINDOW_MS = 60 * 1000; // 1 minute

/** In-memory rate-limit store (per-instance — resets on deploy). */
const rateLimits = new Map();

/* ── Helpers ───────────────────────────────────────────────── */

/**
 * Extract the host portion from a URL-like header value.
 * @param {string|null} value - origin or referer header
 * @returns {string}
 */
export function getHostFromHeader(value) {
  if (!value) return "";
  try {
    return new URL(value).host;
  } catch {
    return "";
  }
}

/**
 * Best-effort client IP from headers / runtime.
 * @param {import("next/server").NextRequest} request
 * @returns {string}
 */
export function getClientIp(request) {
  const forwarded = request.headers.get("x-forwarded-for");
  return (
    request.ip || (forwarded ? forwarded.split(",")[0].trim() : "127.0.0.1")
  );
}

/**
 * Decide whether a request should skip rate-limiting.
 * Prefetches, HEAD, OPTIONS, and non-API routes are skipped.
 * Contact / quote forms are excluded so they keep their own limits.
 */
export function shouldSkipRateLimit(request, pathname) {
  const purpose = request.headers.get("purpose");
  const isPrefetch =
    request.headers.get("next-router-prefetch") === "1" ||
    purpose === "prefetch";
  const method = request.method.toUpperCase();

  // Let contact / quote forms through without rate-limit
  if (pathname === "/api/contact" || pathname === "/api/quote") {
    return true;
  }

  return (
    !pathname.startsWith("/api/") ||
    isPrefetch ||
    method === "HEAD" ||
    method === "OPTIONS"
  );
}

/* ── Main Proxy Function ───────────────────────────────────── */

/**
 * Run security checks on an incoming request.
 *
 * 1. Always allow captcha, unusual-traffic, and access-denied pages.
 * 2. If the `verified_human` cookie is present, pass through.
 * 3. Block direct browser navigation to `/api/*`.
 * 4. Verify origin / referer against ALLOWED_HOSTS.
 * 5. Apply per-IP rate limiting on API calls.
 *
 * @param {import("next/server").NextRequest} request
 * @returns {import("next/server").NextResponse}
 */
export function proxy(request) {
  const pathname = request.nextUrl.pathname;

  /* ── 1. Always pass through whitelisted pages ────────── */
  if (
    pathname.startsWith("/api/captcha") ||
    pathname === "/unusual-traffic" ||
    pathname === "/access-denied"
  ) {
    return NextResponse.next();
  }

  /* ── 2. Verified-human cookie bypass ─────────────────── */
  if (request.cookies.has("verified_human")) {
    return NextResponse.next();
  }

  /* ── 3 & 4. API-route protection ─────────────────────── */
  if (pathname.startsWith("/api/")) {
    const fetchMode = request.headers.get("sec-fetch-mode");
    const accept = request.headers.get("accept") || "";

    // Block direct browser navigation (typing URL in address bar)
    if (fetchMode === "navigate" || accept.includes("text/html")) {
      return NextResponse.redirect(new URL("/access-denied", request.url));
    }

    const origin = request.headers.get("origin") || "";
    const referer = request.headers.get("referer") || "";
    const requestHost = request.headers.get("host") || "";
    const originHost = getHostFromHeader(origin);
    const refererHost = getHostFromHeader(referer);

    const hasAllowedDomain =
      (originHost &&
        (originHost === requestHost || ALLOWED_HOSTS.has(originHost))) ||
      (refererHost &&
        (refererHost === requestHost || ALLOWED_HOSTS.has(refererHost)));

    // Allow server-side rendering (SSR) internal requests
    const requestIp = getClientIp(request);
    const isLocalSSR =
      !origin &&
      !referer &&
      (requestIp === "::1" ||
        requestIp === "127.0.0.1" ||
        requestIp.includes("127.0.0.1") ||
        requestIp.includes("::ffff:127.0.0.1"));

    if (!hasAllowedDomain && !isLocalSSR) {
      return NextResponse.redirect(new URL("/access-denied", request.url));
    }
  }

  /* ── 5. Rate limiting ────────────────────────────────── */
  if (shouldSkipRateLimit(request, pathname)) {
    return NextResponse.next();
  }

  const now = Date.now();
  const windowStart = now - WINDOW_MS;
  const key = `${getClientIp(request)}:${request.method.toUpperCase()}:${pathname}`;
  let requestTimes = rateLimits.get(key) || [];

  // Drop timestamps outside the current window
  requestTimes = requestTimes.filter((ts) => ts > windowStart);

  if (requestTimes.length >= MAX_API_REQUESTS) {
    return NextResponse.json(
      {
        error: "unusual-traffic",
        message: "Rate limit exceeded. Please verify you are human.",
        redirectUrl: "/unusual-traffic",
      },
      { status: 429 },
    );
  }

  requestTimes.push(now);
  rateLimits.set(key, requestTimes);

  return NextResponse.next();
}
