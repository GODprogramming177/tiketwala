require("dotenv").config({ path: ".env.local" });

async function testSetu() {
  const clientId = process.env.SETU_CLIENT_ID;
  const secret = process.env.SETU_SECRET_KEY;
  const merchantId = process.env.SETU_MERCHANT_ID;
  const merchantVpa = process.env.SETU_MERCHANT_VPA;

  console.log("Client ID:", clientId);
  console.log("Merchant ID:", merchantId);
  console.log("Merchant VPA:", merchantVpa);

  try {
    console.log("1. Fetching token from PROD...");
    let response = await fetch("https://accountservice.setu.co/v1/users/login", {
      method: "POST",
      headers: { "Content-Type": "application/json", "client": "bridge" },
      body: JSON.stringify({ clientID: clientId, secret: secret, grant_type: "client_credentials" })
    });

    let data = await response.json();
    console.log("Prod Token Response:", data);
    
    let token = data.access_token;
    
    if (!token) {
        console.log("Trying sandbox token endpoint...");
        response = await fetch("https://sandbox.accountservice.setu.co/v1/users/login", {
          method: "POST",
          headers: { "Content-Type": "application/json", "client": "bridge" },
          body: JSON.stringify({ clientID: clientId, secret: secret, grant_type: "client_credentials" })
        });
        data = await response.json();
        console.log("Sandbox Token Response:", data);
        token = data.access_token;
    }

    if (!token) {
        console.log("Failed to get token");
        return;
    }

    console.log("2. Generating DQR...");
    const payload = {
      merchantVpa: merchantVpa,
      amount: 1000,
      merchantReferenceId: "TEST-" + Date.now(),
      transactionNote: "Test payment"
    };

    console.log("Payload:", payload);

    let dqrResponse = await fetch("https://umap.setu.co/api/v1/merchants/dqr", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
        "merchantId": merchantId,
        "x-product-instance-id": merchantId
      },
      body: JSON.stringify(payload)
    });

    let dqrData = await dqrResponse.json();
    console.log("Prod DQR Response:", dqrData);
    
    if (!dqrResponse.ok) {
        console.log("Trying sandbox DQR endpoint...");
        dqrResponse = await fetch("https://sandbox.umap.setu.co/api/v1/merchants/dqr", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
            "merchantId": merchantId
          },
          body: JSON.stringify(payload)
        });
        dqrData = await dqrResponse.json();
        console.log("Sandbox DQR Response:", dqrData);
    }

  } catch (error) {
    console.error("Test error:", error);
  }
}

testSetu();
