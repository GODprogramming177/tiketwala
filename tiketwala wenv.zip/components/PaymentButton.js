"use client";

import { useState } from "react";
import { createPaymentOptions, initiatePayment } from "@/lib/razorpay";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";

/**
 * PaymentButton component - Handles triggering the Razorpay checkout modal
 */
export default function PaymentButton({
  amount,
  listingName,
  listingId,
  quantity = 1,
  attendeeCounts = null,
  slot,
  customerEmail,
  guestAges = [],
  selectedOffering,
  selectedAddOns = [],
  selectedSeats = [],
  disabled = false,
  onSuccess,
  onError,
}) {
  const [loading, setLoading] = useState(false);
  const { authHeaders } = useCustomerAuth();

  const handlePaymentClick = async () => {
    if (disabled || loading) return;
    setLoading(true);

    try {
      // 0. Pre-payment lock for seats
      if (selectedSeats && selectedSeats.length > 0) {
        const lockRes = await fetch("/api/seats", {
          method: "POST",
          headers: authHeaders(),
          body: JSON.stringify({
            propertyId: listingId,
            slot,
            seats: selectedSeats,
          }),
        });
        const lockData = await lockRes.json();
        if (!lockRes.ok) {
          throw new Error(lockData.error || "Failed to lock seats. Some seats might be unavailable.");
        }
      }

      // 1. Create Order on our backend (which calls Razorpay Orders API)
      const orderRes = await fetch("/api/order", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
          listingId,
          slot,
          quantity,
          attendeeCounts,
          guestAges,
          selectedOffering,
          selectedAddOns,
          selectedSeats,
        }),
      });

      const orderData = await orderRes.json();

      if (!orderRes.ok) {
        throw new Error(orderData.error || "Failed to create order");
      }

      // 2. Prepare Razorpay Options
      const options = createPaymentOptions({
        amount: orderData.totalAmount * 100, // paise
        description: `Booking for ${listingName}`,
        listingName,
        onSuccess: async (rzpResponse) => {
          try {
            // 3. Verify payment and create booking atomically on backend.
            const verifyRes = await fetch("/api/verify-payment", {
              method: "POST",
              headers: authHeaders(),
              body: JSON.stringify({
                razorpay_order_id: rzpResponse.orderId,
                razorpay_payment_id: rzpResponse.paymentId,
                razorpay_signature: rzpResponse.signature,
              }),
            });

            const verifyData = await verifyRes.json();

            if (verifyData.success) {
              setLoading(false);
              // Pass the booking returned by backend.
              if (onSuccess)
                onSuccess({
                  ...rzpResponse,
                  bookingId: verifyData.booking?.bookingId,
                  booking: verifyData.booking,
                });
            } else {
              throw new Error(
                verifyData.error || "Payment verification failed",
              );
            }
          } catch (err) {
            console.error(err);
            setLoading(false);
            if (onError) onError({ message: "Payment verification failed" });
          }
        },
        onError: (err) => {
          setLoading(false);
          if (onError) onError(err);
        },
      });

      // Inject the dynamically generated order ID from our backend.
      options.order_id = orderData.rzpOrderId;

      // 4. Open Razorpay Checkout overlay.
      await initiatePayment(options);
    } catch (e) {
      console.error(e);
      setLoading(false);
      
      if (selectedSeats && selectedSeats.length > 0) {
        fetch("/api/seats", {
          method: "PUT",
          headers: authHeaders(),
          body: JSON.stringify({ propertyId: listingId, slot, seats: selectedSeats }),
        }).catch(console.error);
      }

      if (onError)
        onError({ message: e.message || "An error occurred during payment" });
    }
  };

  return (
    <button
      type="button"
      onClick={handlePaymentClick}
      disabled={disabled || loading}
      className={`
        w-full flex items-center justify-center gap-2 px-6 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg
        transition-all duration-200 shadow-lg
        ${
          disabled || loading
            ? "bg-gray-300 text-gray-500 cursor-not-allowed"
            : "bg-primary text-white hover:bg-primary/90 hover:shadow-xl hover:-translate-y-0.5"
        }
      `}
    >
      {loading ? (
        <>
          <span className="material-symbols-outlined animate-spin">
            progress_activity
          </span>
          Processing Securely...
        </>
      ) : (
        <>
          <span className="material-symbols-outlined">lock</span>
          Pay ₹{amount}
        </>
      )}
    </button>
  );
}
