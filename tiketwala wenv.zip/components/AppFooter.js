"use client";

import Image from "next/image";
import Link from "next/link";

export default function AppFooter() {
  return (
    <footer className="bg-slate-950 text-white py-10 sm:py-12 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
          <div className="xl:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <Image
                src="/logo.png"
                alt="TiketWala Logo"
                width={52}
                height={52}
                className="h-11 w-auto object-contain"
              />
              <div>
                <p className="text-2xl font-bold">TiketWala</p>
                <p className="text-sm text-slate-400">
                  Parks, events, cinemas, temples, and more in one place.
                </p>
              </div>
            </div>
            <p className="text-sm text-slate-400 max-w-xl leading-6">
              Discover destinations, accept walk-ins through POS, handle bulk
              booking leads, and manage every ticketed experience from one
              unified platform.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-white">Explore</h4>
            <div className="space-y-2 text-sm text-slate-400">
              <Link href="/" className="block hover:text-white transition-colors">
                Home
              </Link>
              <Link
                href="/about"
                className="block hover:text-white transition-colors"
              >
                About
              </Link>
              <span className="block">Parks</span>
              <span className="block">Events</span>
              <span className="block">Cinemas</span>
              <span className="block">Temples</span>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-white">Support</h4>
            <div className="space-y-3 text-sm text-slate-400">
              <a
                href="mailto:contact@tiketwala.com"
                className="flex items-center gap-2 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-base">mail</span>
                contact@tiketwala.com
              </a>
              <a
                href="tel:+919861555755"
                className="flex items-center gap-2 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-base">call</span>
                +91 98615 55755
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-slate-500">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-6">
            <p>© 2026 TiketWala. All rights reserved.</p>
            <Link href="/policies/terms-of-service" className="hover:text-slate-300 transition-colors">
              Terms of Service
            </Link>
          </div>
          <p>Built for ticketed destinations and on-ground booking teams.</p>
        </div>
      </div>
    </footer>
  );
}
