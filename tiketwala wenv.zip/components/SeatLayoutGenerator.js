"use client";
import { useState, useMemo, useCallback } from "react";

/**
 * SeatLayoutGenerator
 * Interactive seat grid for event/cinema properties.
 *
 * Props:
 *   seats              - Array of { row, col, label, tier, price }
 *   rows               - Number of rows (max row index + 1)
 *   cols               - Number of columns (max col index + 1)
 *   bookedSeats        - Array of label strings already booked (e.g. ["A1", "A2"])
 *   maxSelect          - Max seats a customer can select (default: 10)
 *   onSelect           - Callback(selectedLabels: string[]) when selection changes
 *   readOnly           - If true, disables selection (admin view)
 *   numberingDirection - 'ltr' or 'rtl' (default: 'rtl' for cinema standard)
 */
export default function SeatLayoutGenerator({
  seats = [],
  rows = 0,
  cols = 0,
  bookedSeats = [],
  maxSelect = 10,
  onSelect,
  readOnly = false,
  numberingDirection = "rtl",
}) {
  const [selected, setSelected] = useState([]);

  const bookedSet = useMemo(() => new Set(bookedSeats), [bookedSeats]);
  const seatMap = useMemo(() => {
    const m = new Map();
    seats.forEach((s) => m.set(s.label, s));
    return m;
  }, [seats]);

  const handleSeatClick = useCallback(
    (label) => {
      if (readOnly || bookedSet.has(label)) return;
      setSelected((prev) => {
        let next;
        if (prev.includes(label)) {
          next = prev.filter((l) => l !== label);
        } else {
          if (prev.length >= maxSelect) return prev;
          next = [...prev, label];
        }
        onSelect?.(next);
        return next;
      });
    },
    [readOnly, bookedSet, maxSelect, onSelect],
  );

  const totalPrice = useMemo(
    () =>
      selected.reduce((sum, label) => {
        const seat = seatMap.get(label);
        return sum + (seat?.price || 0);
      }, 0),
    [selected, seatMap],
  );

  // Group seats by tier, and then by row
  // We want to determine the display order of rows and tiers.
  const { tierGroups, maxColsInAnyRow } = useMemo(() => {
    if (!seats.length) return { tierGroups: [], maxColsInAnyRow: 0 };

    // Find the actual grid boundaries from the active seats
    let maxColIndex = 0;
    
    // 1. Group by Tier
    const tierMap = new Map(); // key -> { name, price, rows: Map<rowLabel, Array<Seat>> }
    
    // Sort seats by row index so tiers appear in top-to-bottom order
    const sortedSeats = [...seats].sort((a, b) => a.row - b.row || a.col - b.col);

    sortedSeats.forEach((seat) => {
      maxColIndex = Math.max(maxColIndex, seat.col);

      const tierKey = seat.tier || "standard";
      if (!tierMap.has(tierKey)) {
        tierMap.set(tierKey, {
          id: tierKey,
          name: tierKey.charAt(0).toUpperCase() + tierKey.slice(1),
          price: seat.price,
          rowsMap: new Map(), // rowLabel -> rowData
          firstRowIndex: seat.row, // To keep tiers in vertical order
        });
      }

      const tGroup = tierMap.get(tierKey);
      
      // We extract the row label from the seat label (e.g. "A1" -> "A")
      const safeLabel = seat.label || "";
      const rowLabelMatch = safeLabel.match(/^([A-Z]+)/);
      const rowLabel = rowLabelMatch ? rowLabelMatch[1] : String.fromCharCode(65 + (seat.row || 0));

      if (!tGroup.rowsMap.has(rowLabel)) {
        tGroup.rowsMap.set(rowLabel, {
          label: rowLabel,
          index: seat.row,
          seats: [],
        });
      }
      
      tGroup.rowsMap.get(rowLabel).seats.push(seat);
    });

    // 2. Convert to arrays for rendering
    const tierGroupsArray = Array.from(tierMap.values())
      .sort((a, b) => a.firstRowIndex - b.firstRowIndex)
      .map(tier => {
        const rowsArray = Array.from(tier.rowsMap.values()).sort((a, b) => a.index - b.index);
        
        // For each row, we need a padded array to represent the physical grid (empty slots where seats don't exist)
        rowsArray.forEach(row => {
          const rowGrid = Array(maxColIndex + 1).fill(null);
          row.seats.forEach(s => {
            rowGrid[s.col] = s;
          });
          
          // Apply numbering direction (reverse the array if RTL)
          if (numberingDirection === 'rtl') {
            rowGrid.reverse();
          }
          
          row.grid = rowGrid;
        });

        return {
          ...tier,
          rows: rowsArray
        };
      });

    return { 
      tierGroups: tierGroupsArray, 
      maxColsInAnyRow: maxColIndex + 1 
    };
  }, [seats, numberingDirection]);

  if (!seats.length) {
    return (
      <div className="text-gray-500 text-sm p-4 text-center">No seat layout available.</div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-6 w-full pb-8">

      {/* Seat Grid */}
      <div className="w-full overflow-x-auto pb-4 custom-scrollbar flex justify-center">
        <div className="flex flex-col gap-6 min-w-max px-2">
          {tierGroups.map((tier) => (
            <div key={tier.id} className="flex flex-col gap-2">
              {/* Tier Header */}
              <div className="flex items-center gap-4 mb-2">
                <hr className="grow border-gray-200" />
                <span className="text-xs font-medium text-gray-500 bg-gray-50 px-3 py-1 rounded-full whitespace-nowrap">
                  ₹{tier.price} {tier.name}
                </span>
                <hr className="grow border-gray-200" />
              </div>

              {/* Rows */}
              <div className="flex flex-col gap-2">
                {tier.rows.map((row) => (
                  <div key={row.label} className="flex items-center gap-4">
                    {/* Row Label (Left) */}
                    <div className="w-6 shrink-0 flex justify-end">
                      <span className="text-xs font-bold text-gray-500 font-mono">
                        {row.label}
                      </span>
                    </div>

                    {/* Seats */}
                    <div className="flex gap-1.5 items-center">
                      {row.grid.map((seat, index) => {
                        if (!seat) {
                          return <div key={`empty-${index}`} className="w-7 h-7 sm:w-8 sm:h-8" />;
                        }

                        const safeLabel = seat.label || "";
                        const isBooked = bookedSet.has(safeLabel);
                        const isSelected = selected.includes(safeLabel);
                        
                        // Extract seat number for display (e.g. "A1" -> "01")
                        const numMatch = safeLabel.match(/\d+$/);
                        const seatNumber = numMatch ? numMatch[0].padStart(2, '0') : "";

                        // Base classes for the seat box
                        let className =
                          "w-7 h-7 sm:w-8 sm:h-8 rounded-[4px] sm:rounded-md text-[9px] sm:text-[10px] font-mono flex items-center justify-center transition-all duration-200 select-none ";
                        
                        if (isBooked) {
                          className += "bg-gray-200 text-gray-400 border border-gray-200 cursor-not-allowed pointer-events-none";
                        } else if (isSelected) {
                          className += "bg-[#1ea83c] text-white border border-[#1ea83c] shadow-sm transform scale-110 z-10 font-bold cursor-pointer";
                        } else {
                          className += "bg-white text-[#1ea83c] border border-[#1ea83c] hover:bg-[#1ea83c]/10 cursor-pointer font-medium";
                        }

                        return (
                          <button
                            key={safeLabel}
                            type="button"
                            className={className}
                            disabled={readOnly || isBooked}
                            onClick={() => handleSeatClick(safeLabel)}
                            title={readOnly ? safeLabel : `${safeLabel} - ₹${seat.price}${isBooked ? " (Booked)" : ""}`}
                          >
                            {seatNumber}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Screen/Stage */}
      <div className="w-full max-w-2xl px-4 flex flex-col items-center mt-6">
        <span className="text-xs font-semibold tracking-[0.2em] text-gray-400 uppercase mb-2">Screen this way</span>
        <svg viewBox="0 0 400 40" className="w-full max-w-sm text-gray-200 fill-current rotate-180">
          <path d="M 0 40 Q 200 0 400 40 L 400 40 L 0 40 Z" />
        </svg>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center justify-center gap-6 mt-2 pt-4 border-t border-gray-100 w-full max-w-md">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-sm border border-[#1ea83c] bg-white" />
          <span className="text-xs text-gray-600 font-medium">Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-sm bg-[#1ea83c]" />
          <span className="text-xs text-gray-600 font-medium">Selected</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-sm bg-gray-200" />
          <span className="text-xs text-gray-600 font-medium">Sold</span>
        </div>
      </div>

      {/* Selection Summary Overlay / Bar */}
      {!readOnly && selected.length > 0 && (
        <div className="fixed bottom-4 inset-x-4 md:static md:bottom-auto md:inset-x-auto w-auto md:w-full max-w-lg bg-white border border-gray-200 shadow-[0_-8px_30px_rgba(0,0,0,0.12)] md:shadow-sm rounded-2xl p-4 z-50 flex items-center justify-between">
          <div>
            <span className="text-sm font-bold text-gray-800">
              {selected.length} Ticket{selected.length > 1 ? "s" : ""}
            </span>
            <div className="text-xs text-gray-500 font-mono mt-1 break-words max-w-[200px]">
              {selected.sort((a, b) => {
                const rowA = (a || "").match(/[A-Z]+/)?.[0] || '';
                const rowB = (b || "").match(/[A-Z]+/)?.[0] || '';
                if (rowA !== rowB) return rowA.localeCompare(rowB);
                const numA = parseInt((a || "").match(/\d+/)?.[0] || '0', 10);
                const numB = parseInt((b || "").match(/\d+/)?.[0] || '0', 10);
                return numA - numB;
              }).join(", ")}
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-lg font-bold text-gray-900">
              ₹{totalPrice.toLocaleString("en-IN")}
            </div>
            <div className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">
              Total Amount
            </div>
          </div>
        </div>
      )}

      {!readOnly && (
        <style dangerouslySetInnerHTML={{
          __html: `
          .custom-scrollbar::-webkit-scrollbar {
            height: 6px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
          }
        `}} />
      )}
    </div>
  );
}
