"use client";

import { useEffect, useRef, useState, useCallback } from "react";

function buildQrConfig(data, options = {}) {
  const {
    size = 280,
    type = "svg",
    logo = "/logo.png",
    showLogo = true,
    dotsColor = "#111827",
    bgColor = "#ffffff",
    cornerSquareColor = "#111827",
    cornerDotColor = "#111827",
    dotsType = "rounded",
    imageSize = 0.18,
  } = options;

  const config = {
    width: size,
    height: size,
    type,
    data,
    dotsOptions: {
      color: dotsColor,
      type: dotsType,
    },
    backgroundOptions: {
      color: bgColor,
    },
    cornersSquareOptions: {
      color: cornerSquareColor,
      type: "extra-rounded",
    },
    cornersDotOptions: {
      color: cornerDotColor,
      type: "dot",
    },
    qrOptions: {
      errorCorrectionLevel: "H",
      mode: "Byte",
      margin: 2,
    },
  };

  if (showLogo && logo) {
    config.image = logo;
    config.imageOptions = {
      crossOrigin: "anonymous",
      margin: 8,
      imageSize,
      hideBackgroundDots: true,
    };
  }

  return config;
}

/**
 * StyledQR — Beautiful branded QR code component using qr-code-styling.
 *
 * Props:
 * - data (string, required): The data to encode in the QR code.
 * - size (number): QR code size in pixels. Default: 280
 * - logo (string): Path to logo image for center overlay. Default: "/logo.png"
 * - showLogo (boolean): Whether to show logo in center. Default: true
 * - dotsColor (string): Color of QR dots. Default: "#0b3c5d"
 * - bgColor (string): Background color. Default: "#ffffff"
 * - cornerSquareColor (string): Corner square color. Default: "#000000"
 * - cornerDotColor (string): Corner dot color. Default: "#000000"
 * - dotsType (string): Dot style type. Default: "classy-rounded"
 * - className (string): Additional CSS classes for the wrapper.
 * - onReady (function): Called with the QRCodeStyling instance when ready.
 */
export default function StyledQR({
  data,
  size = 280,
  logo = "/logo.png",
  showLogo = true,
  dotsColor = "#0b3c5d",
  bgColor = "#ffffff",
  cornerSquareColor = "#000000",
  cornerDotColor = "#000000",
  dotsType = "classy-rounded",
  className = "",
  onReady,
}) {
  const canvasRef = useRef(null);
  const qrRef = useRef(null);
  const [loaded, setLoaded] = useState(false);

  const initQR = useCallback(async () => {
    if (!data || !canvasRef.current) return;

    try {
      // Dynamic import for SSR-safety
      const QRCodeStyling = (await import("qr-code-styling")).default;
      const qr = new QRCodeStyling(
        buildQrConfig(data, {
          size,
          type: "svg",
          logo,
          showLogo,
          dotsColor,
          bgColor,
          cornerSquareColor,
          cornerDotColor,
          dotsType,
        }),
      );
      qrRef.current = qr;

      // Clear any previous content
      canvasRef.current.innerHTML = "";
      qr.append(canvasRef.current);

      setLoaded(true);
      if (onReady) onReady(qr);
    } catch (err) {
      console.error("Failed to initialize QR code:", err);
    }
  }, [data, size, logo, showLogo, dotsColor, dotsType, bgColor, cornerSquareColor, cornerDotColor, onReady]);

  useEffect(() => {
    initQR();
  }, [initQR]);

  return (
    <div
      ref={canvasRef}
      className={`inline-flex items-center justify-center ${className}`}
      style={{
        width: size,
        height: size,
        opacity: loaded ? 1 : 0.3,
        transition: "opacity 0.3s ease",
      }}
    />
  );
}

/**
 * Utility: Download a styled QR code as PNG.
 */
export async function downloadStyledQR(data, filename = "qr-code.png", options = {}) {
  try {
    const QRCodeStyling = (await import("qr-code-styling")).default;
    const qr = new QRCodeStyling(
      buildQrConfig(data, {
        ...options,
        size: options.size || 600,
        type: "canvas",
      }),
    );
    await qr.download({ name: filename.replace(/\.png$/, ""), extension: "png" });
  } catch (err) {
    console.error("Failed to download QR code:", err);
  }
}

/**
 * Utility: Get QR code as data URL (for print/embedded use)
 */
export async function getStyledQRDataUrl(data, options = {}) {
  try {
    const QRCodeStyling = (await import("qr-code-styling")).default;
    const qr = new QRCodeStyling(
      buildQrConfig(data, {
        ...options,
        size: options.size || 400,
        type: "canvas",
      }),
    );
    const blob = await qr.getRawData("png");
    return URL.createObjectURL(blob);
  } catch (err) {
    console.error("Failed to generate QR data URL:", err);
    return null;
  }
}
