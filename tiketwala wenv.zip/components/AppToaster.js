"use client";

import { Toaster } from "react-hot-toast";

export default function AppToaster() {
  return (
    <Toaster
      position="top-right"
      gutter={10}
      toastOptions={{
        duration: 3200,
        style: {
          background: "#0f172a",
          color: "#f8fafc",
          border: "1px solid #1e293b",
          borderRadius: "12px",
          padding: "12px 14px",
          boxShadow: "0 10px 30px rgba(2, 6, 23, 0.35)",
        },
        success: {
          iconTheme: {
            primary: "#10b981",
            secondary: "#ecfeff",
          },
        },
        error: {
          iconTheme: {
            primary: "#ef4444",
            secondary: "#fef2f2",
          },
        },
      }}
    />
  );
}
