"use client";

import { useState, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import { useAdminAuth } from "@/lib/AdminAuthContext";

const NAV_ITEMS = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: "dashboard",
    path: "/admin",
    roles: ["superadmin", "super_admin", "owner"],
  },
  {
    id: "listings",
    label: "Listings",
    icon: "storefront",
    path: "/admin/listings",
    roles: ["superadmin", "super_admin", "owner"],
  },
  {
    id: "bookings",
    label: "Bookings",
    icon: "confirmation_number",
    path: "/admin/bookings",
    roles: ["superadmin", "super_admin", "owner"],
  },
  {
    id: "workers",
    label: "Workers",
    icon: "groups",
    path: "/admin/workers",
    roles: ["superadmin", "super_admin", "owner"],
  },
  {
    id: "pos-transactions",
    label: "POS Transactions",
    icon: "point_of_sale",
    path: "/admin/transactions",
    roles: ["superadmin", "super_admin", "owner"],
  },
  {
    id: "reports",
    label: "Reports",
    icon: "analytics",
    path: "/admin/reports",
    roles: ["superadmin", "super_admin", "owner"],
  },
  {
    id: "register",
    label: "Register Admin",
    icon: "person_add",
    path: "/admin/register",
    roles: ["superadmin", "super_admin"],
  },
  {
    id: "manage-admins",
    label: "Manage Admins",
    icon: "admin_panel_settings",
    path: "/admin/admins",
    roles: ["superadmin", "super_admin"],
  },
  {
    id: "manage-users",
    label: "Manage Users",
    icon: "group",
    path: "/admin/users",
    roles: ["superadmin", "super_admin"],
  },
];

export default function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { admin, logout, isSuperAdmin, isOwner } = useAdminAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  const userRole = admin?.role || "";

  const visibleItems = NAV_ITEMS.filter((item) =>
    item.roles.includes(userRole),
  );

  const isActive = (path) => {
    if (path === "/admin") return pathname === "/admin";
    return pathname.startsWith(path);
  };

  // Close mobile sidebar on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  return (
    <>
      {/* Mobile Toggle Button */}
      <button
        onClick={() => setMobileOpen(true)}
        className="fixed bottom-4 right-4 z-40 lg:hidden w-14 h-14 bg-primary text-white rounded-full shadow-xl flex items-center justify-center hover:bg-primary/90 transition-all"
      >
        <span className="material-symbols-outlined text-2xl">menu</span>
      </button>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-50 h-screen bg-white border-r border-gray-100 shadow-lg lg:shadow-none flex flex-col transition-all duration-300 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 lg:sticky lg:z-10 ${
          collapsed ? "w-[72px]" : "w-64"
        } shrink-0`}
      >
        {/* Header */}
        <div className={`flex items-center ${collapsed ? "justify-center px-2" : "justify-between px-4"} py-5 border-b border-gray-100`}>
          {!collapsed && (
            <Link href="/admin" className="flex items-center gap-2">
              <img
                src="/logo.png"
                alt="TiketWala"
                className="h-8 w-auto object-contain"
              />
              <span className="text-lg font-bold text-gray-900">
                TiketWala
              </span>
            </Link>
          )}
          {collapsed && (
            <img
              src="/logo.png"
              alt="TiketWala"
              className="h-8 w-auto object-contain"
            />
          )}

          {/* Collapse/Mobile close */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setMobileOpen(false)}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors lg:hidden"
            >
              <span className="material-symbols-outlined">close</span>
            </button>
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors hidden lg:flex"
            >
              <span className="material-symbols-outlined text-lg">
                {collapsed ? "chevron_right" : "chevron_left"}
              </span>
            </button>
          </div>
        </div>

        {/* Role Badge */}
        {!collapsed && (
          <div className="px-4 py-3 border-b border-gray-50">
            <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full ${
              isSuperAdmin()
                ? "bg-purple-100 text-purple-700"
                : "bg-primary/10 text-primary"
            }`}>
              <span className="material-symbols-outlined text-sm">
                {isSuperAdmin() ? "shield" : "work"}
              </span>
              {isSuperAdmin() ? "Super Admin" : "Admin"}
            </span>
          </div>
        )}

        {/* Nav Items */}
        <nav className="flex-1 py-3 overflow-y-auto px-2">
          <div className="space-y-0.5">
            {visibleItems.map((item) => {
              const active = isActive(item.path);
              return (
                <Link
                  key={item.id}
                  href={item.path}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                    active
                      ? "bg-primary text-white shadow-sm"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  } ${collapsed ? "justify-center" : ""}`}
                  title={collapsed ? item.label : undefined}
                >
                  <span
                    className={`material-symbols-outlined text-xl ${
                      active
                        ? "text-white"
                        : "text-gray-400 group-hover:text-gray-600"
                    }`}
                  >
                    {item.icon}
                  </span>
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Footer / User Info */}
        <div className={`border-t border-gray-100 p-3 ${collapsed ? "px-2" : ""}`}>
          {!collapsed && admin && (
            <div className="mb-2 px-2">
              <p
                className="text-sm font-medium text-gray-800 truncate"
                title={admin.name}
              >
                {admin.name}
              </p>
              <p
                className="text-xs text-gray-400 truncate"
                title={admin.email}
              >
                {admin.email}
              </p>
            </div>
          )}
          <button
            onClick={() => {
              logout();
              router.push("/admin/login");
            }}
            className={`flex items-center gap-2 w-full px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors ${
              collapsed ? "justify-center" : ""
            }`}
            title="Logout"
          >
            <span className="material-symbols-outlined text-lg">logout</span>
            {!collapsed && "Logout"}
          </button>
        </div>
      </aside>
    </>
  );
}
