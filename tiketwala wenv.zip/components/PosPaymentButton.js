"use client";

import { useState } from "react";
import { createPaymentOptions, initiatePayment } from "@/lib/razorpay";
import { useAdminAuth } from "@/lib/AdminAuthContext";

/**
 * PosPaymentButton component - Handles triggering the Razorpay checkout modal
 * Specifically for POST /api/pos/order and POST /api/pos/verify-payment
 * using AdminAuthContext (for workers/owners/superadmins).
 */
export default function PosPaymentButton({
  amount,
  listingName,
  listingId,
  quantity = 1,
  attendeeCounts = null,
  slot,
  customerName,
  customerEmail,
  customerPhone,
  guestAges = [],
  selectedAddOns = [],
  selectedOffering = null,
  disabled = false,
  onSuccess,
  onError,
}) {
  const [loading, setLoading] = useState(false);
  const { authHeaders } = useAdminAuth();

  const handlePaymentClick = async () => {
    if (disabled || loading) return;
    setLoading(true);

    try {
      // 1. Create Order on our backend (which calls Razorpay Orders API)
      const orderRes = await fetch("/api/pos/order", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
          listingId,
          slot,
          quantity,
          attendeeCounts,
          customerName,
          customerEmail,
          customerPhone,
          guestAges,
          selectedAddOns,
          selectedOffering,
        }),
      });

      const orderData = await orderRes.json();

      if (!orderRes.ok) {
        throw new Error(orderData.error || "Failed to create POS order");
      }

      // 2. Prepare Razorpay Options
      const options = createPaymentOptions({
        amount: orderData.totalAmount * 100, // paise
        description: `POS Booking for ${listingName}`,
        listingName,
        onSuccess: async (rzpResponse) => {
          try {
            // 3. Verify payment and create booking atomically on backend.
            const verifyRes = await fetch("/api/pos/verify-payment", {
              method: "POST",
              headers: authHeaders(),
              body: JSON.stringify({
                razorpay_order_id: rzpResponse.orderId,
                razorpay_payment_id: rzpResponse.paymentId,
                razorpay_signature: rzpResponse.signature,
              }),
            });

            const verifyData = await verifyRes.json();

            if (verifyData.success) {
              setLoading(false);
              // Pass the booking returned by backend.
              if (onSuccess)
                onSuccess({
                  ...rzpResponse,
                  bookingId: verifyData.booking?.bookingId,
                  booking: verifyData.booking,
                });
            } else {
              throw new Error(
                verifyData.error || "POS Payment verification failed",
              );
            }
          } catch (err) {
            console.error(err);
            setLoading(false);
            if (onError)
              onError({ message: "POS Payment verification failed" });
          }
        },
        onError: (err) => {
          setLoading(false);
          if (onError) onError(err);
        },
      });

      // Inject the dynamically generated order ID from our backend.
      options.order_id = orderData.rzpOrderId;

      // Auto-fill customer details if provided
      if (customerName || customerEmail || customerPhone) {
        options.prefill = {
          name: customerName,
          email: customerEmail,
          contact: customerPhone,
        };
      }

      // 4. Open Razorpay Checkout overlay.
      await initiatePayment(options);
    } catch (e) {
      console.error(e);
      setLoading(false);
      if (onError)
        onError({ message: e.message || "An error occurred during payment" });
    }
  };

  return (
    <button
      type="button"
      onClick={handlePaymentClick}
      disabled={disabled || loading}
      className={`
        w-full flex items-center justify-center gap-2 px-6 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg
        transition-all duration-200 shadow-lg
        ${
          disabled || loading
            ? "bg-gray-300 text-gray-500 cursor-not-allowed"
            : "bg-primary text-white hover:bg-primary/90 hover:shadow-xl hover:-translate-y-0.5"
        }
      `}
    >
      {loading ? (
        <>
          <span className="material-symbols-outlined animate-spin">
            progress_activity
          </span>
          Processing Securely...
        </>
      ) : (
        <>
          <span className="material-symbols-outlined">lock</span>
          Pay ₹{amount}
        </>
      )}
    </button>
  );
}
