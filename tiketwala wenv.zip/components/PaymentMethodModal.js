"use client";

export default function PaymentMethodModal({
  isOpen,
  onClose,
  amount,
  onSelectMethod
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col">
        <div className="bg-primary px-4 py-3 text-white font-bold flex justify-between items-center">
          <span>Choose Payment Method</span>
          <button onClick={onClose} className="hover:text-gray-200">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>
        
        <div className="p-6 flex flex-col gap-4">
          <div className="text-center mb-2">
            <div className="text-sm text-gray-500 mb-1">Total Amount to Collect</div>
            <div className="text-3xl font-bold text-gray-800">₹{amount}</div>
          </div>
          
          <button 
            onClick={() => onSelectMethod("worldline")}
            className="w-full flex items-center justify-between p-4 border-2 border-gray-200 rounded-xl hover:border-primary hover:bg-primary/5 transition-all group"
          >
            <div className="flex items-center gap-3">
              <span className="material-symbols-outlined text-2xl text-gray-400 group-hover:text-primary transition-colors">point_of_sale</span>
              <div className="text-left">
                <p className="font-semibold text-gray-800">POS Machine</p>
                <p className="text-xs text-gray-500">Worldline Terminal (Card)</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-gray-300 group-hover:text-primary">chevron_right</span>
          </button>

          <button 
            onClick={() => onSelectMethod("worldline-upi")}
            className="w-full flex items-center justify-between p-4 border-2 border-gray-200 rounded-xl hover:border-primary hover:bg-primary/5 transition-all group"
          >
            <div className="flex items-center gap-3">
              <span className="material-symbols-outlined text-2xl text-gray-400 group-hover:text-primary transition-colors">qr_code_2</span>
              <div className="text-left">
                <p className="font-semibold text-gray-800">POS UPI</p>
                <p className="text-xs text-gray-500">Worldline Terminal (UPI)</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-gray-300 group-hover:text-primary">chevron_right</span>
          </button>

          <button 
            onClick={() => onSelectMethod("setu")}
            className="w-full flex items-center justify-between p-4 border-2 border-gray-200 rounded-xl hover:border-primary hover:bg-primary/5 transition-all group"
          >
            <div className="flex items-center gap-3">
              <span className="material-symbols-outlined text-2xl text-gray-400 group-hover:text-primary transition-colors">qr_code_scanner</span>
              <div className="text-left">
                <p className="font-semibold text-gray-800">UPI QR Code</p>
                <p className="text-xs text-gray-500">Setu Dynamic QR</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-gray-300 group-hover:text-primary">chevron_right</span>
          </button>
        </div>
      </div>
    </div>
  );
}
