"use client";

import { useState, useEffect, useRef } from "react";
import toast from "react-hot-toast";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";

export default function ReviewsComponent({ listingId, onReviewAdded = null }) {
  const { customer, isAuthenticated, authHeaders } = useCustomerAuth();
  const [reviews, setReviews] = useState([]);
  const [stats, setStats] = useState({
    averageRating: 0,
    totalReviews: 0,
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [hasBooking, setHasBooking] = useState(false);
  const [checkingBooking, setCheckingBooking] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    rating: 5,
    comment: "",
  });

  // Polling interval for real-time updates
  const pollingIntervalRef = useRef(null);

  // Load reviews on mount
  useEffect(() => {
    fetchReviews();

    // Setup polling (every 30 seconds)
    pollingIntervalRef.current = setInterval(fetchReviews, 30000);

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [listingId]);

  // Check if the logged-in customer has a confirmed booking for this listing
  useEffect(() => {
    if (isAuthenticated && customer?.email && listingId) {
      checkCustomerBooking();
    } else {
      setHasBooking(false);
    }
  }, [isAuthenticated, customer, listingId]);

  const checkCustomerBooking = async () => {
    setCheckingBooking(true);
    try {
      const res = await fetch(
        `/api/bookings?email=${encodeURIComponent(customer.email)}&listingId=${listingId}`,
        { headers: authHeaders() }
      );
      if (res.ok) {
        const data = await res.json();
        const bookings = Array.isArray(data.bookings) ? data.bookings : Array.isArray(data) ? data : [];
        const hasConfirmed = bookings.some(
          (b) => b.status === "confirmed" && (b.propertyId === listingId || b.listingId === listingId)
        );
        setHasBooking(hasConfirmed);
      }
    } catch (err) {
      console.error("Failed to check booking status:", err);
    } finally {
      setCheckingBooking(false);
    }
  };

  const fetchReviews = async () => {
    try {
      const response = await fetch(
        `/api/reviews?listingId=${listingId}&limit=10&skip=0`,
      );
      const data = await response.json();

      if (data.success !== false) {
        setReviews(data.reviews || []);
        setStats({
          averageRating: data.averageRating || 0,
          totalReviews: data.totalRatings || data.totalReviews || (data.reviews || []).length,
        });
      }
    } catch (error) {
      console.error("Failed to fetch reviews:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();

    if (!customer) {
      toast.error("Please log in to submit a review");
      return;
    }

    if (!formData.comment.trim()) {
      toast.error("Please write a comment");
      return;
    }

    if (formData.comment.trim().length < 5) {
      toast.error("Comment must be at least 5 characters");
      return;
    }

    setSubmitting(true);

    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
          listingId,
          rating: formData.rating,
          comment: formData.comment.trim(),
        }),
      });

      const data = await response.json();

      if (data.success === false) {
        if (response.status === 409) {
          toast.error("You have already reviewed this listing");
          setShowForm(false);
        } else if (response.status === 403) {
          toast.error(
            "You can only review listings where you have a confirmed booking",
          );
        } else {
          toast.error(data.error || "Failed to submit review");
        }
      } else {
        toast.success("Review submitted successfully!");
        setFormData({ rating: 5, comment: "" });
        setShowForm(false);

        // Refresh reviews
        await fetchReviews();
        if (onReviewAdded) {
          onReviewAdded();
        }
      }
    } catch (error) {
      console.error("Error submitting review:", error);
      toast.error("Failed to submit review");
    } finally {
      setSubmitting(false);
    }
  };

  // Check if current user already reviewed
  const alreadyReviewed =
    customer &&
    reviews.some(
      (r) =>
        r.customerId === customer.id ||
        r.customerEmail === customer.email
    );

  return (
    <div className="bg-white rounded-3xl shadow-md p-5 sm:p-6">
      {/* Reviews Header */}
      <h2 className="text-lg sm:text-xl font-semibold text-primary mb-4 flex items-center gap-2">
        <span className="material-symbols-outlined">reviews</span>
        Reviews & Ratings
      </h2>

      {/* Rating Summary */}
      {stats.totalReviews > 0 && (
        <div className="flex items-center gap-6 mb-6 p-4 bg-accent/50 rounded-2xl">
          <div className="text-center">
            <div className="text-4xl font-bold text-amber-500">
              {stats.averageRating}
            </div>
            <div className="flex justify-center gap-0.5 mt-1">
              {[...Array(5)].map((_, i) => (
                <span
                  key={i}
                  className={`material-symbols-outlined text-lg ${
                    i < Math.floor(stats.averageRating)
                      ? "text-amber-500"
                      : "text-gray-300"
                  }`}
                >
                  star
                </span>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {stats.totalReviews}{" "}
              {stats.totalReviews === 1 ? "review" : "reviews"}
            </p>
          </div>

          {/* Rating Breakdown */}
          <div className="flex-1 space-y-1.5">
            {[5, 4, 3, 2, 1].map((rating) => {
              const count = reviews.filter((r) => r.rating === rating).length;
              const percent =
                stats.totalReviews > 0
                  ? Math.round((count / stats.totalReviews) * 100)
                  : 0;

              return (
                <div key={rating} className="flex items-center gap-2">
                  <span className="text-xs text-gray-600 w-3">{rating}</span>
                  <span className="material-symbols-outlined text-amber-500 text-sm">
                    star
                  </span>
                  <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded-full transition-all"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-gray-400 w-7 text-right">
                    {percent}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Write Review Button — only if user is logged in, has a booking, and hasn't reviewed yet */}
      {isAuthenticated && hasBooking && !alreadyReviewed && !showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="w-full py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors font-medium flex items-center justify-center gap-2 mb-4"
        >
          <span className="material-symbols-outlined">rate_review</span>
          Write a Review
        </button>
      )}

      {/* Message for logged-in users without a booking */}
      {isAuthenticated && !hasBooking && !checkingBooking && !alreadyReviewed && (
        <div className="flex items-center gap-2 p-3 bg-amber-50 text-amber-700 rounded-xl text-sm mb-4">
          <span className="material-symbols-outlined text-base">info</span>
          Book a ticket first to leave a review.
        </div>
      )}

      {/* Already reviewed message */}
      {isAuthenticated && alreadyReviewed && (
        <div className="flex items-center gap-2 p-3 bg-green-50 text-green-700 rounded-xl text-sm mb-4">
          <span className="material-symbols-outlined text-base">check_circle</span>
          You have already reviewed this listing. Thank you!
        </div>
      )}

      {/* Review Form */}
      {showForm && customer && (
        <form onSubmit={handleSubmitReview} className="bg-accent/30 rounded-2xl p-5 mb-5">
          <h3 className="font-semibold text-gray-800 mb-4">
            Share Your Experience
          </h3>

          {/* Rating Input */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Rating
            </label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  type="button"
                  onClick={() => setFormData({ ...formData, rating })}
                  className="transition-transform hover:scale-110"
                >
                  <span
                    className={`material-symbols-outlined text-3xl cursor-pointer ${
                      rating <= formData.rating
                        ? "text-amber-500"
                        : "text-gray-300"
                    }`}
                  >
                    {rating <= formData.rating ? "star" : "star_outline"}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Comment Input */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Review
            </label>
            <textarea
              value={formData.comment}
              onChange={(e) =>
                setFormData({ ...formData, comment: e.target.value })
              }
              placeholder="Tell others about your experience..."
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary/30 focus:border-primary focus:outline-none resize-none"
              rows="4"
            />
            <p className="text-xs text-gray-400 mt-1">
              {formData.comment.length} / 5 min characters
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={submitting || formData.comment.length < 5}
              className="flex-1 py-2.5 bg-primary text-white rounded-xl hover:bg-primary/90 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-base">send</span>
              {submitting ? "Submitting..." : "Submit Review"}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="flex-1 py-2.5 bg-gray-200 text-gray-700 rounded-xl hover:bg-gray-300 transition-colors font-medium"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Reviews List */}
      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block animate-spin">
            <span className="material-symbols-outlined text-3xl text-primary">
              progress_activity
            </span>
          </div>
          <p className="text-gray-500 mt-2">Loading reviews...</p>
        </div>
      ) : reviews.length === 0 ? (
        <div className="text-center py-8">
          <span className="material-symbols-outlined text-5xl text-gray-300">
            comment_disabled
          </span>
          <p className="text-gray-500 mt-2">
            No reviews yet. Be the first to review!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {reviews.map((review) => (
            <div
              key={review._id || review.id}
              className="p-4 rounded-2xl border border-gray-100 bg-gray-50/50"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center font-bold text-sm">
                  {(review.customerName || review.userName || "A")
                    .charAt(0)
                    .toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-800 text-sm truncate">
                    {review.customerName || review.userName || "Anonymous"}
                  </p>
                  <div className="flex items-center gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <span
                        key={i}
                        className={`material-symbols-outlined text-[14px] ${
                          i < review.rating
                            ? "text-amber-400"
                            : "text-gray-200"
                        }`}
                      >
                        star
                      </span>
                    ))}
                  </div>
                </div>
                <span className="text-xs text-gray-400 shrink-0">
                  {new Date(review.createdAt).toLocaleDateString()}
                </span>
              </div>
              {review.comment && (
                <p className="text-sm text-gray-600 mt-1 leading-relaxed">
                  &ldquo;{review.comment}&rdquo;
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
