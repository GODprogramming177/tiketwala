"use client";

import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { useAdminAuth } from "@/lib/AdminAuthContext";

/**
 * QRScanner Component - Scans QR codes for ticket validation
 * Features:
 *   - Defaults to rear (environment) camera
 *   - Shows camera selector when 2+ cameras are available
 *   - Entry / Exit / Expired scan flow
 */
export default function QRScanner({ onScan, onClose }) {
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [cameras, setCameras] = useState([]);
  const [selectedCameraId, setSelectedCameraId] = useState(null);
  const scannerRef = useRef(null);
  const html5QrCodeRef = useRef(null);
  const { authHeaders } = useAdminAuth();

  /* ── Enumerate cameras on mount ──────── */
  useEffect(() => {
    Html5Qrcode.getCameras()
      .then((devices) => {
        setCameras(devices || []);

        // Default to rear camera (environment-facing)
        const rear = devices.find(
          (d) =>
            /back|rear|environment/i.test(d.label) ||
            d.label.toLowerCase().includes("0") // fallback heuristic
        );
        const initial = rear || devices[devices.length - 1]; // last camera is usually rear
        if (initial) {
          setSelectedCameraId(initial.id);
        }
      })
      .catch(() => {
        // If enumeration fails, we'll fall back to facingMode
        setSelectedCameraId(null);
      });

    return () => {
      stopScanner();
    };
  }, []);

  /* ── Start scanner when a camera is selected ── */
  useEffect(() => {
    if (selectedCameraId !== null || cameras.length === 0) {
      const timer = setTimeout(() => {
        startScanner();
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [selectedCameraId]);

  const startScanner = async () => {
    try {
      setError(null);
      setResult(null);

      // Stop any existing instance first
      if (html5QrCodeRef.current) {
        try {
          await html5QrCodeRef.current.stop();
        } catch {
          /* ignore */
        }
      }

      html5QrCodeRef.current = new Html5Qrcode("qr-reader");

      const cameraConfig = selectedCameraId
        ? { deviceId: { exact: selectedCameraId } }
        : { facingMode: "environment" };

      await html5QrCodeRef.current.start(
        cameraConfig,
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        (decodedText) => {
          handleScanSuccess(decodedText);
        },
        () => {
          // Ignore scan errors (no QR found in frame)
        },
      );
      setScanning(true);
    } catch (err) {
      setError(
        "Failed to start camera. Please ensure camera permissions are granted.",
      );
      console.error("Scanner error:", err);
    }
  };

  const stopScanner = async () => {
    if (html5QrCodeRef.current) {
      try {
        await html5QrCodeRef.current.stop();
        setScanning(false);
      } catch (err) {
        console.error("Error stopping scanner:", err);
      }
    }
  };

  /* ── Switch camera ──────────────────── */
  const handleCameraChange = async (newCameraId) => {
    setSelectedCameraId(newCameraId);
    // The useEffect for selectedCameraId will restart the scanner
  };

  /* ── Scan success handler (entry/exit/expired) ── */
  const handleScanSuccess = async (decodedText) => {
    await stopScanner();

    try {
      const bookingData = JSON.parse(decodedText);

      // POST to the scan endpoint — handles entry/exit/expired logic
      const response = await fetch("/api/bookings/scan", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ bookingId: bookingData.bookingId }),
      });

      const data = await response.json();

      if (data.success) {
        const scanType = data.scanType; // "entry", "exit", "expired"

        if (scanType === "entry") {
          const resultData = {
            bookingId: bookingData.bookingId,
            listingName: data.booking?.listingName || bookingData.listingName,
            slot: data.booking?.slot || bookingData.slot,
            quantity: data.booking?.quantity || bookingData.quantity,
            status: "valid",
            scanType: "entry",
            message: "✅ Entry scan — Welcome!",
          };
          setResult(resultData);
          if (onScan) onScan(resultData);
        } else if (scanType === "exit") {
          const resultData = {
            bookingId: bookingData.bookingId,
            listingName: data.booking?.listingName || bookingData.listingName,
            slot: data.booking?.slot || bookingData.slot,
            quantity: data.booking?.quantity || bookingData.quantity,
            status: "valid",
            scanType: "exit",
            message: "👋 Exit scan — Thank you for visiting!",
          };
          setResult(resultData);
          if (onScan) onScan(resultData);
        } else if (scanType === "expired") {
          const errorData = {
            bookingId: bookingData.bookingId,
            listingName: data.booking?.listingName || bookingData.listingName,
            status: "invalid",
            scanType: "expired",
            message: "🚫 Ticket Expired — Already used (Entry + Exit completed)",
          };
          setResult(errorData);
          if (onScan) onScan(errorData);
        }
      } else {
        // API returned an error
        const errorData = {
          bookingId: bookingData.bookingId,
          listingName: bookingData.listingName,
          status: "invalid",
          scanType: data.scanType || "error",
          message: data.error || "Validation failed",
        };
        setResult(errorData);
        if (onScan) onScan(errorData);
      }
    } catch (err) {
      setError("Invalid QR code format");
      setResult(null);
    }
  };

  /* ── Manual entry handler ──────────── */
  const handleManualEntry = async (bookingId) => {
    if (!bookingId?.trim()) return;
    setError(null);

    try {
      const response = await fetch("/api/bookings/scan", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ bookingId: bookingId.trim() }),
      });

      const data = await response.json();

      if (data.success) {
        const scanType = data.scanType;
        const statusMap = {
          entry: { status: "valid", message: "✅ Entry scan — Welcome!" },
          exit: { status: "valid", message: "👋 Exit scan — Thank you for visiting!" },
          expired: { status: "invalid", message: "🚫 Ticket Expired — Already used (Entry + Exit completed)" },
        };
        const mapped = statusMap[scanType] || { status: "valid", message: data.message || "Scanned" };

        const resultData = {
          bookingId,
          listingName: data.booking?.listingName,
          slot: data.booking?.slot,
          quantity: data.booking?.quantity,
          scanType,
          ...mapped,
        };
        setResult(resultData);
        if (onScan) onScan(resultData);
      } else {
        const errorData = {
          bookingId,
          status: "invalid",
          scanType: data.scanType || "error",
          message: data.error || "Validation failed",
        };
        setResult(errorData);
        if (onScan) onScan(errorData);
      }
    } catch (err) {
      setError("Failed to validate booking");
    }
  };

  /* ── Derived UI helpers ─────────────── */
  const getScanTypeColor = (scanType) => {
    switch (scanType) {
      case "entry":
        return { bg: "bg-green-50", border: "border-green-200", text: "text-green-700", icon: "login", iconColor: "text-green-600", label: "ENTRY", labelBg: "bg-green-100 text-green-800" };
      case "exit":
        return { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", icon: "logout", iconColor: "text-blue-600", label: "EXIT", labelBg: "bg-blue-100 text-blue-800" };
      case "expired":
        return { bg: "bg-red-50", border: "border-red-200", text: "text-red-700", icon: "block", iconColor: "text-red-600", label: "EXPIRED", labelBg: "bg-red-100 text-red-800" };
      default:
        return { bg: "bg-gray-50", border: "border-gray-200", text: "text-gray-700", icon: "help", iconColor: "text-gray-600", label: "UNKNOWN", labelBg: "bg-gray-100 text-gray-800" };
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b flex items-center justify-between">
          <h2 className="text-xl font-semibold text-primary flex items-center gap-2">
            <span className="material-symbols-outlined">qr_code_scanner</span>
            Scan Ticket
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="p-6">
          {/* Camera Selector — only shown if 2+ cameras exist */}
          {cameras.length >= 2 && !result && (
            <div className="mb-4">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                Camera
              </label>
              <select
                value={selectedCameraId || ""}
                onChange={(e) => handleCameraChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-primary/40 text-sm"
              >
                {cameras.map((cam) => (
                  <option key={cam.id} value={cam.id}>
                    {cam.label || `Camera ${cam.id.slice(-4)}`}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Scanner Area — always visible so html5-qrcode can attach */}
          <div
            id="qr-reader"
            ref={scannerRef}
            className="w-full aspect-square bg-gray-100 rounded-xl overflow-hidden mb-4"
            style={{ display: result ? "none" : "block" }}
          />

          {!scanning && !result && (
            <div className="text-center py-4">
              <p className="text-gray-500 mb-4">Starting camera...</p>
              <button
                onClick={startScanner}
                className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2 mx-auto"
              >
                <span className="material-symbols-outlined">photo_camera</span>
                Retry Camera
              </button>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3 mb-4">
              <span className="material-symbols-outlined text-red-500">
                error
              </span>
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {/* Result — Entry / Exit / Expired */}
          {result && (() => {
            const colors = getScanTypeColor(result.scanType);
            return (
              <div className="space-y-4">
                <div className={`p-4 border rounded-lg ${colors.bg} ${colors.border}`}>
                  <div className="flex items-center gap-3 mb-3">
                    <span className={`material-symbols-outlined text-3xl ${colors.iconColor}`}>
                      {result.status === "valid"
                        ? (result.scanType === "exit" ? "logout" : "check_circle")
                        : "cancel"}
                    </span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`font-semibold text-lg ${result.status === "valid" ? "text-green-800" : "text-red-800"}`}>
                          {result.status === "valid" ? "Ticket Valid" : "Ticket Invalid"}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${colors.labelBg}`}>
                          {colors.label}
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className={`text-sm mb-3 ${colors.text} font-medium`}>
                    {result.message}
                  </p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Booking ID:</span>
                      <span className="font-mono font-medium">
                        {result.bookingId}
                      </span>
                    </div>
                    {result.listingName && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Venue:</span>
                        <span className="font-medium">{result.listingName}</span>
                      </div>
                    )}
                    {result.slot && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Time Slot:</span>
                        <span className="font-medium">{result.slot}</span>
                      </div>
                    )}
                    {result.quantity && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Visitors:</span>
                        <span className="font-medium">{result.quantity}</span>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => {
                    setResult(null);
                    startScanner();
                  }}
                  className="w-full px-4 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined">
                    qr_code_scanner
                  </span>
                  Scan Another Ticket
                </button>
              </div>
            );
          })()}

          {/* Manual Entry */}
          {!result && (
            <div className="mt-6 pt-6 border-t">
              <p className="text-sm text-gray-500 mb-3">
                Or enter booking ID manually:
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.target);
                  handleManualEntry(formData.get("bookingId"));
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  name="bookingId"
                  placeholder="Enter Booking ID"
                  className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-accent text-primary rounded-lg hover:bg-primary hover:text-white transition-colors"
                >
                  <span className="material-symbols-outlined">search</span>
                </button>
              </form>
            </div>
          )}

          {/* Stop Scanner */}
          {scanning && (
            <button
              onClick={stopScanner}
              className="w-full mt-4 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
            >
              Stop Scanning
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
