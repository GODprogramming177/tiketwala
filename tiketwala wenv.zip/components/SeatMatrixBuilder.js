"use client";
import { useState, useMemo, useCallback } from "react";

/**
 * SeatMatrixBuilder
 * Interactive component for admins to configure a seating layout.
 *
 * Props:
 *   initialSeating - { rows, cols, seats, numberingDirection }
 *   onChange       - Callback(seatingConfig)
 */
export default function SeatMatrixBuilder({ initialSeating, onChange }) {
  const initialStandard = initialSeating?.seats?.find(s => s.tier === 'standard')?.price || 150;
  const initialPremium = initialSeating?.seats?.find(s => s.tier === 'premium')?.price || 250;
  const initialVip = initialSeating?.seats?.find(s => s.tier === 'vip')?.price || 400;

  const [rows, setRows] = useState(initialSeating?.rows || 10);
  const [cols, setCols] = useState(initialSeating?.cols || 12);
  const [standardPrice, setStandardPrice] = useState(initialStandard);
  const [premiumPrice, setPremiumPrice] = useState(initialPremium);
  const [vipPrice, setVipPrice] = useState(initialVip);
  const [seats, setSeats] = useState(initialSeating?.seats || []);
  const [numberingDirection, setNumberingDirection] = useState(
    initialSeating?.numberingDirection || "rtl"
  );
  const [mode, setMode] = useState("standard"); // standard, premium, vip, disabled

  const generateGrid = () => {
    const newSeats = [];
    for (let r = 0; r < rows; r++) {
      const rowLabel = String.fromCharCode(65 + r);
      for (let c = 0; c < cols; c++) {
        newSeats.push({
          row: r,
          col: c,
          label: `${rowLabel}${c + 1}`,
          tier: "standard",
          price: standardPrice,
        });
      }
    }
    setSeats(newSeats);
    onChange?.({ rows, cols, seats: newSeats, numberingDirection });
  };

  const handleSeatClick = useCallback(
    (label) => {
      let nextSeats = [...seats];
      const seatIndex = nextSeats.findIndex((s) => s.label === label);

      if (mode === "disabled") {
        if (seatIndex >= 0) {
          nextSeats.splice(seatIndex, 1); // Remove seat
        } else {
          // Re-add seat
          const match = label.match(/^([A-Z]+)(\d+)$/);
          if (match) {
            const r = match[1].charCodeAt(0) - 65;
            const c = parseInt(match[2], 10) - 1;
            nextSeats.push({
              row: r,
              col: c,
              label,
              tier: "standard",
              price: standardPrice,
            });
          }
        }
      } else {
        if (seatIndex >= 0) {
          let price = standardPrice;
          if (mode === "premium") price = premiumPrice;
          if (mode === "vip") price = vipPrice;

          nextSeats[seatIndex] = {
            ...nextSeats[seatIndex],
            tier: mode,
            price: price,
          };
        }
      }
      setSeats(nextSeats);
      onChange?.({ rows, cols, seats: nextSeats, numberingDirection });
    },
    [seats, mode, standardPrice, premiumPrice, vipPrice, rows, cols, numberingDirection, onChange]
  );

  const handlePriceChange = (tier, newPrice) => {
    if (tier === "standard") setStandardPrice(newPrice);
    if (tier === "premium") setPremiumPrice(newPrice);
    if (tier === "vip") setVipPrice(newPrice);

    // Update all existing seats of this tier
    const nextSeats = seats.map((seat) => 
      seat.tier === tier ? { ...seat, price: newPrice } : seat
    );
    setSeats(nextSeats);
    onChange?.({ rows, cols, seats: nextSeats, numberingDirection });
  };

  const handleDirectionChange = (val) => {
    setNumberingDirection(val);
    onChange?.({ rows, cols, seats, numberingDirection: val });
  };

  // Group seats by row for our custom admin view
  const rowLabels = useMemo(() => {
    const labels = [];
    for (let r = 0; r < rows; r++) labels.push(String.fromCharCode(65 + r));
    return labels;
  }, [rows]);

  const seatMap = useMemo(() => {
    const m = new Map();
    seats.forEach((s) => m.set(s.label, s));
    return m;
  }, [seats]);

  const tierColors = {
    vip: "bg-[#f59e0b] text-white border-[#f59e0b]",
    premium: "bg-[#3b82f6] text-white border-[#3b82f6]",
    standard: "bg-[#1ea83c] text-white border-[#1ea83c]",
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-4 items-end bg-gray-50 p-4 rounded-xl border">
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
            Rows (A-Z)
          </label>
          <input
            type="number"
            min="1"
            max="26"
            value={rows}
            onChange={(e) => setRows(Number(e.target.value))}
            className="w-20 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
            Columns
          </label>
          <input
            type="number"
            min="1"
            max="50"
            value={cols}
            onChange={(e) => setCols(Number(e.target.value))}
            className="w-20 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
            Standard (₹)
          </label>
          <input
            type="number"
            min="0"
            value={standardPrice}
            onChange={(e) => handlePriceChange("standard", Number(e.target.value))}
            className="w-24 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
            Premium (₹)
          </label>
          <input
            type="number"
            min="0"
            value={premiumPrice}
            onChange={(e) => handlePriceChange("premium", Number(e.target.value))}
            className="w-24 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
            VIP (₹)
          </label>
          <input
            type="number"
            min="0"
            value={vipPrice}
            onChange={(e) => handlePriceChange("vip", Number(e.target.value))}
            className="w-24 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
            Numbering Direction
          </label>
          <select
            value={numberingDirection}
            onChange={(e) => handleDirectionChange(e.target.value)}
            className="w-40 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="ltr">Left to Right (1, 2, 3...)</option>
            <option value="rtl">Right to Left (...3, 2, 1)</option>
          </select>
        </div>
        <button
          type="button"
          onClick={generateGrid}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 font-medium"
        >
          Generate Initial Grid
        </button>
      </div>

      {seats.length > 0 && (
        <div className="border rounded-xl p-6 bg-white shadow-sm">
          <div className="mb-6 flex flex-col gap-3">
            <div>
              <h4 className="font-bold text-gray-800 text-lg">Paint Mode</h4>
              <p className="text-sm text-gray-500">
                Select a tier or action, then click on the seats below to apply it. The grid previews the customer layout.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setMode("standard")}
                className={`px-4 py-2 rounded-lg text-sm font-medium border-2 transition-colors ${mode === "standard" ? "bg-green-50 border-green-600 text-green-700" : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"}`}
              >
                Standard Tier
              </button>
              <button
                type="button"
                onClick={() => setMode("premium")}
                className={`px-4 py-2 rounded-lg text-sm font-medium border-2 transition-colors ${mode === "premium" ? "bg-blue-50 border-blue-600 text-blue-700" : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"}`}
              >
                Premium Tier
              </button>
              <button
                type="button"
                onClick={() => setMode("vip")}
                className={`px-4 py-2 rounded-lg text-sm font-medium border-2 transition-colors ${mode === "vip" ? "bg-amber-50 border-amber-500 text-amber-700" : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"}`}
              >
                VIP Tier
              </button>
              <button
                type="button"
                onClick={() => setMode("disabled")}
                className={`px-4 py-2 rounded-lg text-sm font-medium border-2 transition-colors ${mode === "disabled" ? "bg-red-50 border-red-500 text-red-600" : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"}`}
              >
                Toggle Gap/Disabled
              </button>
            </div>
          </div>


          <div className="overflow-x-auto w-full custom-scrollbar pb-6 flex justify-center">
            <div className="inline-flex flex-col gap-2 p-2">
              {rowLabels.map((rowLabel) => {
                // Generate column array based on direction
                let colArray = Array.from({ length: cols }, (_, c) => c);
                if (numberingDirection === 'rtl') {
                  colArray.reverse();
                }

                return (
                  <div key={rowLabel} className="flex items-center gap-4">
                    <div className="w-6 shrink-0 flex justify-end">
                      <span className="text-xs font-bold text-gray-400 font-mono">
                        {rowLabel}
                      </span>
                    </div>
                    <div className="flex gap-1.5 items-center">
                      {colArray.map((c) => {
                        const label = `${rowLabel}${c + 1}`;
                        const seat = seatMap.get(label);

                        let className =
                          "w-7 h-7 sm:w-8 sm:h-8 rounded-[4px] sm:rounded-md text-[9px] sm:text-[10px] font-mono flex items-center justify-center cursor-pointer transition-transform hover:scale-110 ";
                        
                        if (!seat) {
                          // Disabled gap
                          className += "bg-gray-100 border border-dashed border-gray-300 text-transparent hover:bg-gray-200";
                        } else {
                          // Colored by tier
                          className += (tierColors[seat.tier] || tierColors.standard);
                        }

                        // Display number inside
                        const seatNumber = String(c + 1).padStart(2, '0');

                        return (
                          <button
                            key={label}
                            type="button"
                            className={className}
                            onClick={() => handleSeatClick(label)}
                            title={seat ? `${label} - ${seat.tier} - ₹${seat.price}` : `${label} - Click to restore`}
                          >
                            {seatNumber}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="w-full flex flex-col items-center mt-8">
            <span className="text-xs font-semibold tracking-[0.2em] text-gray-400 uppercase mb-2">Screen this way</span>
            <svg viewBox="0 0 400 40" className="w-full max-w-sm text-gray-200 fill-current rotate-180 mb-4">
              <path d="M 0 40 Q 200 0 400 40 L 400 40 L 0 40 Z" />
            </svg>
          </div>

          <div className="flex justify-between items-center mt-2 pt-4 border-t text-sm text-gray-500">
            <p>Total configured seats: <span className="font-bold text-gray-900">{seats.length}</span></p>
            <div className="flex gap-4">
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-[#1ea83c]" /> Standard</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-[#3b82f6]" /> Premium</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm bg-[#f59e0b]" /> VIP</div>
            </div>
          </div>
        </div>
      )}

      <style dangerouslySetInnerHTML={{
        __html: `
        .custom-scrollbar::-webkit-scrollbar {
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }
      `}} />
    </div>
  );
}
