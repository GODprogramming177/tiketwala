"use client";

import Link from "next/link";
import { getTypeIcon } from "@/lib/typeIcons";

/**
 * ListingCard component - Single Responsibility: Display listing information
 * Follows Liskov Substitution: Works with any listing type (Temple, Park, Event)
 */
export default function ListingCard({ listing }) {
  const { id, name, type, location, image, description, price, rating } =
    listing;
  const typeIcon = getTypeIcon(type);

  return (
    <div className="group listing-card bg-white rounded-xl sm:rounded-2xl shadow-md hover:shadow-xl overflow-hidden border border-gray-100 transition-all duration-300 hover:-translate-y-1">
      {/* Image Section */}
      <div className="relative h-40 sm:h-48 bg-gray-100 overflow-hidden">
        {image ? (
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-primary/5">
            <span className="material-symbols-outlined text-5xl sm:text-6xl text-primary/30">
              {typeIcon}
            </span>
          </div>
        )}
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Type Badge */}
        <div className="absolute top-2 sm:top-3 left-2 sm:left-3">
          <span className="inline-flex items-center gap-1 px-2 sm:px-2.5 py-1 bg-white/95 backdrop-blur-sm rounded-full text-xs sm:text-sm font-medium text-primary shadow-sm">
            <span className="material-symbols-outlined text-sm sm:text-base">
              {typeIcon}
            </span>
            {type}
          </span>
        </div>
        {/* Rating Badge */}
        <div className="absolute top-2 sm:top-3 right-2 sm:right-3">
          <span className="inline-flex items-center gap-1 px-2 py-1 bg-white/95 backdrop-blur-sm rounded-full text-xs sm:text-sm font-medium text-gray-700 shadow-sm">
            <span className="material-symbols-outlined text-sm sm:text-base text-yellow-500">
              star
            </span>
            {rating}
          </span>
        </div>
      </div>

      {/* Content Section */}
      <div className="p-3 sm:p-4">
        <h3 className="text-base sm:text-lg font-semibold text-gray-800 truncate group-hover:text-primary transition-colors">
          {name}
        </h3>

        <div className="flex items-center gap-1 mt-1 text-gray-500 text-xs sm:text-sm">
          <span className="material-symbols-outlined text-sm sm:text-base">
            location_on
          </span>
          {location}
        </div>

        <p className="mt-2 text-gray-600 text-xs sm:text-sm line-clamp-2">
          {description}
        </p>

        {/* Footer */}
        <div className="mt-3 sm:mt-4 flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="text-gray-800">
            <span className="text-xs sm:text-sm text-gray-500 block">
              Starting from
            </span>
            <span className="text-lg sm:text-xl font-bold text-primary">
              ₹{price}
            </span>
          </div>

          <Link
            href={`/booking/${id}`}
            className="inline-flex items-center gap-1 px-3 sm:px-4 py-2 sm:py-2.5 bg-primary text-white rounded-lg hover:bg-primary/90 transition-all font-medium text-sm sm:text-base hover:shadow-md"
          >
            <span className="material-symbols-outlined text-lg sm:text-xl">
              book_online
            </span>
            <span className="hidden sm:inline">Book Now</span>
            <span className="sm:hidden">Book</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

/**
 * ListingCardSkeleton - Loading placeholder
 */
export function ListingCardSkeleton() {
  return (
    <div className="bg-white rounded-xl sm:rounded-2xl shadow-md overflow-hidden border border-gray-100 animate-pulse">
      <div className="h-40 sm:h-48 bg-gray-200" />
      <div className="p-3 sm:p-4">
        <div className="h-5 sm:h-6 bg-gray-200 rounded w-3/4" />
        <div className="h-3 sm:h-4 bg-gray-200 rounded w-1/2 mt-2" />
        <div className="h-3 sm:h-4 bg-gray-200 rounded w-full mt-3" />
        <div className="h-3 sm:h-4 bg-gray-200 rounded w-2/3 mt-1" />
        <div className="flex items-center justify-between mt-3 sm:mt-4 pt-3 border-t border-gray-100">
          <div className="h-6 sm:h-8 bg-gray-200 rounded w-16 sm:w-20" />
          <div className="h-9 sm:h-10 bg-gray-200 rounded w-20 sm:w-28" />
        </div>
      </div>
    </div>
  );
}
