"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { useAdminAuth } from "@/lib/AdminAuthContext";
import { useCustomerAuth } from "@/lib/CustomerAuthContext";

export default function Navbar({ isAdmin = false, onLocationChange = null }) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isAdminRoute =
    pathname.startsWith("/admin") || pathname.startsWith("/worker");
  const isWorkerRoute = pathname.startsWith("/worker");
  const { admin, logout, isWorker, isSuperAdmin, hasPosPermission } =
    useAdminAuth();
  const { customer, logoutCustomer } = useCustomerAuth();
  const isPublicNavbar = !(isAdmin || isAdminRoute);

  // Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [locationName, setLocationName] = useState("My Location");
  const searchRef = useRef(null);

  // Debounce search query (400ms)
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Fetch search suggestions
  useEffect(() => {
    if (!debouncedQuery || debouncedQuery.length < 2) {
      setSuggestions([]);
      return;
    }

    let cancelled = false;
    const fetchSuggestions = async () => {
      setSearchLoading(true);
      try {
        const response = await fetch(
          `/api/search?q=${encodeURIComponent(debouncedQuery)}&limit=6`,
        );
        if (!cancelled) {
          const data = await response.json();
          setSuggestions(Array.isArray(data) ? data : []);
        }
      } catch {
        if (!cancelled) setSuggestions([]);
      } finally {
        if (!cancelled) setSearchLoading(false);
      }
    };

    fetchSuggestions();
    return () => {
      cancelled = true;
    };
  }, [debouncedQuery]);

  // Close suggestions on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    setMobileMenuOpen(false);
    logout();
    router.replace("/admin/login");
  };

  const handleCustomerLogout = () => {
    logoutCustomer();
    setMobileMenuOpen(false);
  };

  const handleUseMyLocation = useCallback(() => {
    setMobileMenuOpen(false);
    if (!navigator.geolocation) return;
    setLocationName("Locating...");
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${coords.lat}&lon=${coords.lng}&format=json`,
          );
          const data = await res.json();
          const city =
            data.address?.city ||
            data.address?.town ||
            data.address?.village ||
            data.address?.county ||
            data.address?.state_district ||
            "Current Location";
          setLocationName(city);
        } catch (e) {
          setLocationName("Current Location");
        }
        if (onLocationChange) {
          onLocationChange({ type: "coords", coords });
        } else {
          router.push(`/?lat=${coords.lat}&lng=${coords.lng}`);
        }
      },
      () => {
        console.warn("Geolocation unavailable");
        setLocationName("My Location");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
    );
  }, [onLocationChange, router]);

  const adminHomeHref =
    admin?.role === "worker" || isWorkerRoute ? "/worker" : "/admin";
  const showWorkerLinks = admin?.role === "worker" || isWorker();
  const showAdminManagement = !showWorkerLinks;
  const showWorkerPosLink = showWorkerLinks && hasPosPermission("pos");
  const showWorkerSalesLink = showWorkerLinks && hasPosPermission("pos");
  const showWorkerScanLink = showWorkerLinks && hasPosPermission("scan");

  return (
    <nav className="sticky top-0 z-50">
      <div className="bg-white text-primary shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo — left */}
            <Link
              href={isAdmin || isAdminRoute ? adminHomeHref : "/"}
              className="flex items-center h-16 shrink-0"
            >
              <Image
                src="/logo.png"
                alt="TiketWala Logo"
                width={200}
                height={65}
                className="w-auto h-15 sm:h-16 object-contain"
              />
            </Link>

            {/* Right side — Search + Hamburger (public) or Admin nav */}
            {isAdmin || isAdminRoute ? (
              /* ── Admin navigation ── */
              <>
                <button
                  onClick={() => setMobileMenuOpen((prev) => !prev)}
                  className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="material-symbols-outlined text-2xl">
                    {mobileMenuOpen ? "close" : "menu"}
                  </span>
                </button>

                <div className="hidden md:flex items-center gap-3 lg:gap-4">
                  <NavLink href={adminHomeHref} currentPath={pathname} exact>
                    <span className="material-symbols-outlined text-xl">
                      {showWorkerLinks ? "home" : "dashboard"}
                    </span>
                    <span className="hidden lg:inline">
                      {showWorkerLinks ? "Home" : "Dashboard"}
                    </span>
                  </NavLink>

                  {showWorkerLinks && (
                    <>
                      {showWorkerPosLink && (
                        <NavLink href="/worker/pos" currentPath={pathname}>
                          <span className="material-symbols-outlined text-xl">
                            point_of_sale
                          </span>
                          <span className="hidden lg:inline">POS</span>
                        </NavLink>
                      )}
                      {showWorkerSalesLink && (
                        <NavLink
                          href="/worker/dashboard"
                          currentPath={pathname}
                        >
                          <span className="material-symbols-outlined text-xl">
                            insights
                          </span>
                          <span className="hidden lg:inline">Sales</span>
                        </NavLink>
                      )}
                      {showWorkerScanLink && (
                        <NavLink href="/worker/scan" currentPath={pathname}>
                          <span className="material-symbols-outlined text-xl">
                            qr_code_scanner
                          </span>
                          <span className="hidden lg:inline">Scan</span>
                        </NavLink>
                      )}
                    </>
                  )}

                  {showAdminManagement && (
                    <>
                      <NavLink href="/admin/listings" currentPath={pathname}>
                        <span className="material-symbols-outlined text-xl">
                          list
                        </span>
                        <span className="hidden lg:inline">Listings</span>
                      </NavLink>
                      <NavLink href="/admin/slots" currentPath={pathname}>
                        <span className="material-symbols-outlined text-xl">
                          schedule
                        </span>
                        <span className="hidden lg:inline">Slots</span>
                      </NavLink>
                      {isSuperAdmin() && (
                        <NavLink href="/admin/admins" currentPath={pathname}>
                          <span className="material-symbols-outlined text-xl">
                            manage_accounts
                          </span>
                          <span className="hidden lg:inline">Admins</span>
                        </NavLink>
                      )}
                      {!isSuperAdmin() && (
                        <NavLink href="/admin/workers" currentPath={pathname}>
                          <span className="material-symbols-outlined text-xl">
                            groups
                          </span>
                          <span className="hidden lg:inline">Workers</span>
                        </NavLink>
                      )}
                    </>
                  )}

                  <Link
                    href="/"
                    className="flex items-center gap-1 px-3 py-1.5 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors text-gray-700"
                  >
                    <span className="material-symbols-outlined text-xl">
                      exit_to_app
                    </span>
                    <span className="hidden lg:inline">Exit</span>
                  </Link>
                  {admin && (
                    <button
                      onClick={handleLogout}
                      className="flex items-center gap-1 px-3 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-colors"
                    >
                      <span className="material-symbols-outlined text-xl">
                        logout
                      </span>
                      <span className="hidden lg:inline">Logout</span>
                    </button>
                  )}
                </div>
              </>
            ) : (
              /* ── Public navbar — search + hamburger on RIGHT ── */
              <div className="flex items-center gap-2 sm:gap-3">
                {/* Desktop search bar */}
                <div className="hidden md:block relative" ref={searchRef}>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
                      search
                    </span>
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setShowSuggestions(true);
                      }}
                      onFocus={() => {
                        if (debouncedQuery.length >= 2)
                          setShowSuggestions(true);
                      }}
                      placeholder="Search parks, cinemas, events..."
                      className="w-[280px] lg:w-[360px] xl:w-[420px] pl-10 pr-3 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                    />
                    {searchLoading && (
                      <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg animate-spin">
                        progress_activity
                      </span>
                    )}
                  </div>

                  {/* Autocomplete suggestions dropdown */}
                  {showSuggestions && suggestions.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 z-50 max-h-80 overflow-y-auto">
                      {suggestions.map((suggestion) => (
                        <button
                          key={suggestion.id}
                          type="button"
                          onClick={() => {
                            setShowSuggestions(false);
                            setSearchQuery("");
                            router.push(`/booking/${suggestion.id}`);
                          }}
                          className="w-full px-4 py-3 flex items-center gap-3 hover:bg-accent/60 transition-colors text-left border-b border-gray-50 last:border-b-0"
                        >
                          <img
                            src={suggestion.image}
                            alt={suggestion.name}
                            className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                          />
                          <div className="min-w-0 flex-1">
                            <p className="font-medium text-gray-800 text-sm truncate">
                              {suggestion.name}
                            </p>
                            <p className="text-xs text-gray-500 truncate">
                              {suggestion.type} • {suggestion.location}
                            </p>
                          </div>
                          <span className="text-xs text-primary font-medium flex-shrink-0">
                            ₹{suggestion.price}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}

                  {showSuggestions &&
                    debouncedQuery.length >= 2 &&
                    suggestions.length === 0 &&
                    !searchLoading && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 z-50 px-4 py-6 text-center">
                        <span className="material-symbols-outlined text-3xl text-gray-300">
                          search_off
                        </span>
                        <p className="text-sm text-gray-500 mt-2">
                          No results for &ldquo;{debouncedQuery}&rdquo;
                        </p>
                      </div>
                    )}
                </div>

                {/* Hamburger button */}
                <button
                  onClick={() => setMobileMenuOpen((prev) => !prev)}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                  aria-label="Menu"
                >
                  <span className="material-symbols-outlined text-2xl">
                    {mobileMenuOpen ? "close" : "menu"}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* ── Mobile search (public only) ── */}
        {isPublicNavbar && (
          <div className="md:hidden px-4 pb-3">
            <div
              className="relative"
              ref={!searchRef.current ? searchRef : undefined}
            >
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
                search
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSuggestions(true);
                }}
                onFocus={() => {
                  if (debouncedQuery.length >= 2) setShowSuggestions(true);
                }}
                placeholder="Search parks, cinemas, events..."
                className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
              {searchLoading && (
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg animate-spin">
                  progress_activity
                </span>
              )}

              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 z-50 max-h-60 overflow-y-auto">
                  {suggestions.map((suggestion) => (
                    <button
                      key={suggestion.id}
                      type="button"
                      onClick={() => {
                        setShowSuggestions(false);
                        setSearchQuery("");
                        setMobileMenuOpen(false);
                        router.push(`/booking/${suggestion.id}`);
                      }}
                      className="w-full px-4 py-3 flex items-center gap-3 hover:bg-accent/60 transition-colors text-left border-b border-gray-50 last:border-b-0"
                    >
                      <img
                        src={suggestion.image}
                        alt={suggestion.name}
                        className="w-9 h-9 rounded-lg object-cover flex-shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-gray-800 text-sm truncate">
                          {suggestion.name}
                        </p>
                        <p className="text-xs text-gray-500 truncate">
                          {suggestion.type} • ₹{suggestion.price}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Side Panel Navigation ── */}
        {/* Backdrop */}
        {mobileMenuOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Side Panel - Always toggleable */}
        <div
          className={`fixed top-0 right-0 h-full w-64 bg-white shadow-2xl transform transition-transform duration-300 ease-in-out z-50 flex flex-col ${
            mobileMenuOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          {/* Panel Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-100">
            <h2 className="text-lg font-semibold text-gray-800">Menu</h2>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Close menu"
            >
              <span className="material-symbols-outlined text-2xl">close</span>
            </button>
          </div>

          {/* Panel Content - Scrollable */}
          <div className="flex-1 overflow-y-auto">
            <div className="flex flex-col gap-2 p-4">
              {isAdmin || isAdminRoute ? (
                /* Admin side menu */
                <>
                  <SideNavLink
                    href={adminHomeHref}
                    currentPath={pathname}
                    exact
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <span className="material-symbols-outlined">
                      {showWorkerLinks ? "home" : "dashboard"}
                    </span>
                    {showWorkerLinks ? "Home" : "Dashboard"}
                  </SideNavLink>

                  {showWorkerLinks && (
                    <>
                      {showWorkerPosLink && (
                        <SideNavLink
                          href="/worker/pos"
                          currentPath={pathname}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <span className="material-symbols-outlined">
                            point_of_sale
                          </span>
                          POS
                        </SideNavLink>
                      )}
                      {showWorkerSalesLink && (
                        <SideNavLink
                          href="/worker/dashboard"
                          currentPath={pathname}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <span className="material-symbols-outlined">
                            insights
                          </span>
                          Sales
                        </SideNavLink>
                      )}
                      {showWorkerScanLink && (
                        <SideNavLink
                          href="/worker/scan"
                          currentPath={pathname}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <span className="material-symbols-outlined">
                            qr_code_scanner
                          </span>
                          Scan Ticket
                        </SideNavLink>
                      )}
                    </>
                  )}

                  {showAdminManagement && (
                    <>
                      <SideNavLink
                        href="/admin/listings"
                        currentPath={pathname}
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <span className="material-symbols-outlined">list</span>
                        Listings
                      </SideNavLink>
                      <SideNavLink
                        href="/admin/slots"
                        currentPath={pathname}
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <span className="material-symbols-outlined">
                          schedule
                        </span>
                        Slots
                      </SideNavLink>
                      {isSuperAdmin() && (
                        <SideNavLink
                          href="/admin/admins"
                          currentPath={pathname}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <span className="material-symbols-outlined">
                            manage_accounts
                          </span>
                          Manage Admins
                        </SideNavLink>
                      )}
                      {!isSuperAdmin() && (
                        <SideNavLink
                          href="/admin/workers"
                          currentPath={pathname}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <span className="material-symbols-outlined">
                            groups
                          </span>
                          Workers
                        </SideNavLink>
                      )}
                    </>
                  )}

                  <div className="border-t border-gray-100 my-2" />

                  <Link
                    href="/"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 transition-colors text-gray-700"
                  >
                    <span className="material-symbols-outlined">
                      exit_to_app
                    </span>
                    Exit to Public
                  </Link>
                </>
              ) : (
                /* Public side navigation:
                   All Locations, My Location, Home, Dashboard (if logged in), Logout */
                <>
                  <SideNavLink
                    href="/"
                    currentPath={pathname}
                    exact
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <span className="material-symbols-outlined">explore</span>
                    All Locations
                  </SideNavLink>

                  <button
                    onClick={handleUseMyLocation}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-100 transition-colors text-gray-700 text-left w-full"
                  >
                    <span className="material-symbols-outlined">
                      my_location
                    </span>
                    {locationName}
                  </button>

                  <SideNavLink
                    href="/"
                    currentPath={pathname}
                    exact
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <span className="material-symbols-outlined">home</span>
                    Home
                  </SideNavLink>

                  {customer && (
                    <>
                      <div className="border-t border-gray-100 my-2" />
                      <SideNavLink
                        href="/user/dashboard"
                        currentPath={pathname}
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <span className="material-symbols-outlined">
                          dashboard
                        </span>
                        Dashboard
                      </SideNavLink>
                    </>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Panel Footer - Action Buttons */}
          <div className="border-t border-gray-100 p-4 flex flex-col gap-2">
            {/* Admin logout takes priority over customer logout */}
            {admin ? (
              <button
                onClick={() => {
                  handleLogout();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 px-4 py-3 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors text-left w-full"
              >
                <span className="material-symbols-outlined">logout</span>
                Logout
              </button>
            ) : customer ? (
              <button
                onClick={handleCustomerLogout}
                className="flex items-center gap-3 px-4 py-3 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors text-left w-full"
              >
                <span className="material-symbols-outlined">logout</span>
                Logout
              </button>
            ) : !isAdminRoute ? (
              <Link
                href="/booking/login"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-3 px-4 py-3 rounded-lg bg-primary text-white hover:bg-primary/90 transition-colors text-center justify-center w-full"
              >
                <span className="material-symbols-outlined">login</span>
                Login
              </Link>
            ) : null}
          </div>
        </div>
      </div>

      {isPublicNavbar && (
        <div
          className="h-[18px] bg-primary relative overflow-hidden"
          aria-hidden="true"
        >
          <div
            className="absolute inset-0 opacity-35"
            style={{
              backgroundImage:
                "radial-gradient(circle at 8px 9px, #7da6c3 1.2px, transparent 1.2px), radial-gradient(circle at 28px 9px, #7da6c3 1.2px, transparent 1.2px)",
              backgroundSize: "40px 18px",
            }}
          />
        </div>
      )}
    </nav>
  );
}

function NavLink({ href, currentPath, exact = false, children }) {
  const isActive = exact ? currentPath === href : currentPath.startsWith(href);

  return (
    <Link
      href={href}
      className={`flex items-center gap-1 px-3 py-2 rounded-lg transition-colors ${
        isActive
          ? "bg-primary/10 text-primary font-medium"
          : "text-gray-600 hover:bg-gray-100 hover:text-primary"
      }`}
    >
      {children}
    </Link>
  );
}

function MobileNavLink({
  href,
  currentPath,
  exact = false,
  onClick,
  children,
}) {
  const isActive = exact ? currentPath === href : currentPath.startsWith(href);

  return (
    <Link
      href={href}
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
        isActive
          ? "bg-primary/10 text-primary font-medium"
          : "hover:bg-gray-100 text-gray-700"
      }`}
    >
      {children}
    </Link>
  );
}

function SideNavLink({ href, currentPath, exact = false, onClick, children }) {
  const isActive = exact ? currentPath === href : currentPath.startsWith(href);

  return (
    <Link
      href={href}
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
        isActive
          ? "bg-primary/10 text-primary font-semibold"
          : "hover:bg-gray-100 text-gray-700"
      }`}
    >
      {children}
    </Link>
  );
}
