"use client";

/**
 * SlotGrid component - Single Responsibility: Display and select slots
 * Follows Interface Segregation: Doesn't know about payment logic
 */
import { useState, useEffect } from "react";

/**
 * SlotGrid component - Single Responsibility: Display and select slots by date
 */
export default function SlotGrid({
  slots,
  selectedSlot,
  onSelectSlot,
  loading = false,
}) {
  const [selectedDate, setSelectedDate] = useState("");

  // Group slots by date
  const dateMap = new Map();
  if (slots && slots.length > 0) {
    slots.forEach((s) => {
      // s.start is an ISO string like "2026-03-08T10:00:00+05:30"
      const dateKey = s.start.split("T")[0]; // "2026-03-08"
      if (!dateMap.has(dateKey)) {
        dateMap.set(dateKey, []);
      }
      dateMap.get(dateKey).push(s);
    });
  }

  const uniqueDates = Array.from(dateMap.keys()).sort();

  // Initialize or reset selected date
  const uniqueDatesStr = uniqueDates.join(",");
  useEffect(() => {
    if (uniqueDates.length > 0) {
      if (!selectedDate || !uniqueDates.includes(selectedDate)) {
        setSelectedDate(uniqueDates[0]);
      }
    } else if (selectedDate) {
      setSelectedDate("");
    }
  }, [uniqueDatesStr, selectedDate, uniqueDates]);

  // When a date or time is picked, set the entire ISO start string as the picked slot
  const handleSlotClick = (isoStart) => {
    onSelectSlot(isoStart);
  };

  if (loading) {
    return <SlotGridSkeleton />;
  }

  if (!slots || slots.length === 0) {
    return (
      <div className="text-center py-8">
        <span className="material-symbols-outlined text-5xl text-gray-300">
          event_busy
        </span>
        <p className="mt-2 text-gray-500">
          No slots available for this listing
        </p>
      </div>
    );
  }

  const currentSlots = selectedDate ? dateMap.get(selectedDate) || [] : [];

  return (
    <div className="space-y-6">
      {/* Date Picker Rail */}
      <div>
        <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span className="material-symbols-outlined text-lg">
              calendar_month
            </span>
            Select Date
          </div>
          <p className="text-xs text-gray-400 whitespace-nowrap">
            Swipe for more dates
          </p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide py-1 snap-x snap-mandatory">
          {uniqueDates.map((dateStr) => {
            const dateObj = new Date(`${dateStr}T00:00:00`);
            const dayName = dateObj.toLocaleDateString("en-US", {
              weekday: "short",
            });
            const dayNum = dateObj.getDate();
            const monthName = dateObj.toLocaleDateString("en-US", {
              month: "short",
            });
            const isSelected = dateStr === selectedDate;

            return (
              <button
                key={dateStr}
                onClick={() => setSelectedDate(dateStr)}
                className={`snap-start shrink-0 flex flex-col items-center justify-center rounded-xl p-3 border-2 transition-all min-w-[84px] sm:min-w-24 ${
                  isSelected
                    ? "border-primary bg-primary/5 text-primary shadow-sm"
                    : "border-gray-100 bg-white text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                }`}
              >
                <span className="text-xs font-semibold uppercase tracking-wider opacity-80">
                  {monthName} {dayName}
                </span>
                <span className="text-2xl font-bold">{dayNum}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Time Slots Grid */}
      <div>
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
          <span className="material-symbols-outlined text-lg">schedule</span>
          Select Time Slot
        </div>

        {currentSlots.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-3">
            {currentSlots.map((slot, index) => (
              <SlotChip
                key={index}
                time={slot.time}
                available={slot.available}
                selected={selectedSlot === slot.start}
                onClick={() => slot.available && handleSlotClick(slot.start)}
                capacity={slot.capacity}
                booked={slot.booked}
              />
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500 italic p-4 bg-gray-50 rounded-lg text-center">
            No times available for this date.
          </p>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 sm:gap-6 mt-6 pt-4 border-t text-xs sm:text-sm border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full border-2 border-primary bg-white" />
          <span className="text-gray-600 font-medium">Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full border-2 border-primary bg-primary" />
          <span className="text-gray-600 font-medium">Selected</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-gray-100 border-2 border-gray-200" />
          <span className="text-gray-400 font-medium whitespace-nowrap">
            Sold Out
          </span>
        </div>
      </div>
    </div>
  );
}

/**
 * SlotChip component - Individual slot button
 */
function SlotChip({ time, available, selected, onClick }) {
  const baseClasses =
    "slot-chip flex items-center justify-center gap-2 text-xs sm:text-sm font-medium min-h-[52px] text-center";

  let stateClasses = "";
  if (!available) {
    stateClasses = "disabled";
  } else if (selected) {
    stateClasses = "selected";
  } else {
    stateClasses = "border-primary text-primary hover:bg-accent";
  }

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!available}
      className={`${baseClasses} ${stateClasses}`}
    >
      <span className="material-symbols-outlined text-lg">
        {available ? (selected ? "check_circle" : "schedule") : "block"}
      </span>
      {time}
    </button>
  );
}

/**
 * SlotGridSkeleton - Loading placeholder
 */
function SlotGridSkeleton() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-5 bg-gray-200 rounded w-48" />
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-12 bg-gray-200 rounded-lg" />
        ))}
      </div>
    </div>
  );
}
