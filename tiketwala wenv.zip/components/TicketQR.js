"use client";

import { useEffect, useState } from "react";
import StyledQR, { getStyledQRDataUrl } from "@/components/StyledQR";

export default function TicketQR({
  booking,
  onClose,
  allowThermalPrint = true,
}) {
  const [thermalQrUrl, setThermalQrUrl] = useState("");
  const [downloading, setDownloading] = useState(false);
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  const qrData = booking
    ? JSON.stringify({
        bookingId: booking.bookingId,
      })
    : "";

  useEffect(() => {
    let cancelled = false;
    let previousUrl = null;

    const generateQr = async () => {
      if (!booking || !qrData) {
        return;
      }

      try {
        const nextUrl = await getStyledQRDataUrl(qrData, {
          size: 220,
          showLogo: true,
          dotsColor: "#111827",
          cornerSquareColor: "#111827",
          cornerDotColor: "#111827",
          dotsType: "square",
          imageSize: 0.16,
        });
        previousUrl = nextUrl;
        if (!cancelled) {
          setThermalQrUrl(nextUrl || "");
        }
      } catch (err) {
        console.error("Ticket QR error:", err);
      }
    };

    generateQr();

    return () => {
      cancelled = true;
      if (previousUrl) {
        URL.revokeObjectURL(previousUrl);
      }
    };
  }, [booking, qrData]);

  const handlePrint = () => {
    window.print();
  };

  /** Format a date value for display */
  const formatDate = (dateVal) => {
    if (!dateVal) return "N/A";
    // Already a nice string like "10 Apr 2026"
    if (typeof dateVal === "string" && dateVal.includes(" ")) return dateVal;
    // ISO date like "2026-04-10" or "2026-04-10T..."
    try {
      const d = new Date(dateVal);
      if (!isNaN(d.getTime())) {
        return d.toLocaleDateString("en-IN", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });
      }
    } catch {}
    return String(dateVal);
  };

  const formatTimeSlot = (isoStart, isoEnd) => {
    if (!isoStart || isoStart === "N/A") return "N/A";
    try {
      if (!isoStart.includes("T")) return isoStart; // Already formatted or not ISO
      const d = new Date(isoStart);
      if (isNaN(d.getTime())) return String(isoStart);
      
      let timeStr = d.toLocaleTimeString("en-IN", { hour: 'numeric', minute: '2-digit', hour12: true });
      if (isoEnd) {
        const endD = new Date(isoEnd);
        if (!isNaN(endD.getTime())) {
          timeStr += " - " + endD.toLocaleTimeString("en-IN", { hour: 'numeric', minute: '2-digit', hour12: true });
        }
      }
      return timeStr;
    } catch {
      return String(isoStart);
    }
  };

  const displayDate = formatDate(booking?.date || booking?.bookingDateIso);
  const displaySlot = formatTimeSlot(booking?.slot, booking?.slotEnd);
  const displayValidUntil = formatDate(
    booking?.validUntil || booking?.validUntilIso,
  );

  const buildTicketCanvas = async () => {
    const exportCanvas = document.createElement("canvas");
    exportCanvas.width = 1200;
    exportCanvas.height = 1800;
    const ctx = exportCanvas.getContext("2d");
    if (!ctx) throw new Error("Canvas export is unavailable");

    const selectedAddOns = Array.isArray(booking?.selectedAddOns)
      ? booking.selectedAddOns
      : [];

    let exportQrUrl = thermalQrUrl;
    let generatedQrFallback = false;

    try {
      ctx.fillStyle = "#f8fafc";
      ctx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);

      ctx.fillStyle = "#0B3C5D";
      ctx.fillRect(80, 80, 1040, 400);

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 64px Arial";
      ctx.fillText("TiketWala", 120, 170);
      ctx.font = "32px Arial";
      ctx.fillText("Digital Entry Ticket", 120, 225);

      ctx.font = "bold 36px Arial";
      ctx.fillText(`Booking ID: ${booking.bookingId}`, 120, 290);

      ctx.font = "28px Arial";
      ctx.fillText(booking.listingName || "TiketWala Experience", 120, 340);
      ctx.fillText(`${displayDate} • ${displaySlot}`, 120, 385);
      ctx.fillText(
        `${booking.quantity} ${booking.quantity === 1 ? "guest" : "guests"} • Paid ₹${booking.totalAmount}`,
        120,
        430,
      );

      if (!exportQrUrl) {
        exportQrUrl = await getStyledQRDataUrl(qrData, {
          size: 520,
          showLogo: true,
          dotsColor: "#111827",
          cornerSquareColor: "#111827",
          cornerDotColor: "#111827",
          dotsType: "square",
          imageSize: 0.16,
        });
        generatedQrFallback = true;
      }

      if (exportQrUrl) {
        await new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => {
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(820, 140, 260, 260);
            ctx.drawImage(img, 830, 150, 240, 240);
            resolve();
          };
          img.onerror = reject;
          img.src = exportQrUrl;
        });
      }

      ctx.fillStyle = "#ffffff";
      ctx.fillRect(80, 500, 1040, 1220);

      const rows = [
        ["Venue", booking.listingName],
        ...(booking.location && booking.location !== "N/A" ? [["Location", booking.location]] : []),
        ...(booking.selectedOffering
          ? [
              [
                booking.listingType?.toLowerCase() === "cinema"
                  ? "Movie"
                  : booking.listingType?.toLowerCase() === "event"
                    ? "Event"
                    : "Package",
                booking.selectedOffering,
              ],
            ]
          : []),
        ["Date", displayDate],
        ["Time Slot", displaySlot],
        [
          "Visitors",
          `${booking.quantity} ${booking.quantity === 1 ? "person" : "people"}`,
        ],
        ...(booking.selectedSeats && booking.selectedSeats.length > 0
          ? [["Seats", booking.selectedSeats.join(", ")]]
          : []),
        ["Amount Paid", `₹${booking.totalAmount}`],
      ];

      let y = 620;
      rows.forEach(([label, value]) => {
        ctx.font = "26px Arial";
        ctx.fillStyle = "#64748b";
        ctx.fillText(label, 120, y);
        ctx.font = "bold 30px Arial";
        ctx.fillStyle = "#0f172a";
        wrapText(ctx, value || "-", 480, y, 520, 36);
        y += 92;
      });

      if (selectedAddOns.length > 0) {
        ctx.fillStyle = "#0f172a";
        ctx.font = "bold 34px Arial";
        ctx.fillText("Selected Add-ons", 120, y + 20);
        y += 80;

        selectedAddOns.forEach((addOn) => {
          ctx.font = "26px Arial";
          ctx.fillStyle = "#334155";
          wrapText(ctx, addOn.name, 120, y, 600, 34);
          ctx.font = "bold 26px Arial";
          ctx.fillStyle = "#0B3C5D";
          ctx.fillText(`₹${Number(addOn.price) || 0}`, 900, y);
          y += 64;
        });
      }

      ctx.fillStyle = "#64748b";
      ctx.font = "26px Arial";
      wrapText(
        ctx,
        "Present this QR code at the entrance. Keep this ticket accessible until your visit is complete.",
        120,
        1600,
        960,
        36,
      );

      return exportCanvas;
    } finally {
      if (generatedQrFallback && exportQrUrl) {
        URL.revokeObjectURL(exportQrUrl);
      }
    }
  };

  const handleDownload = async () => {
    if (!booking) return;

    setDownloading(true);
    try {
      const exportCanvas = await buildTicketCanvas();
      const link = document.createElement("a");
      link.href = exportCanvas.toDataURL("image/png");
      link.download = `${booking.bookingId || "tiketwala-ticket"}.png`;
      link.click();
    } catch (error) {
      console.error("Failed to download ticket", error);
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadPdf = async () => {
    if (!booking) return;

    setDownloadingPdf(true);
    try {
      const exportCanvas = await buildTicketCanvas();
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({
        unit: "pt",
        format: "a4",
        orientation: "portrait",
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 24;
      const maxWidth = pageWidth - margin * 2;
      const maxHeight = pageHeight - margin * 2;
      const scale = Math.min(
        maxWidth / exportCanvas.width,
        maxHeight / exportCanvas.height,
      );

      const renderWidth = exportCanvas.width * scale;
      const renderHeight = exportCanvas.height * scale;
      const offsetX = (pageWidth - renderWidth) / 2;
      const offsetY = (pageHeight - renderHeight) / 2;

      pdf.addImage(
        exportCanvas.toDataURL("image/png"),
        "PNG",
        offsetX,
        offsetY,
        renderWidth,
        renderHeight,
        undefined,
        "FAST",
      );

      pdf.save(`${booking.bookingId || "tiketwala-ticket"}.pdf`);
    } catch (error) {
      console.error("Failed to download ticket PDF", error);
    } finally {
      setDownloadingPdf(false);
    }
  };

  if (!booking) return null;

  const addOns = Array.isArray(booking.selectedAddOns)
    ? booking.selectedAddOns
    : [];

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 print:bg-white print:p-0">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[calc(100vh-2rem)] overflow-y-auto print:shadow-none print:rounded-none print:max-h-none">
        {allowThermalPrint && (
          <style jsx global>{`
            @media print {
              body * {
                visibility: hidden;
              }
              .print-wrapper,
              .print-wrapper * {
                visibility: visible;
              }
              .print-wrapper {
                position: absolute;
                left: 0;
                top: 0;
                margin: 0;
                padding: 0;
                width: 58mm; /* Standard thermal roll width */
                background: #fff;
                color: #000;
              }
              .screen-ticket {
                display: none !important;
              }
              .thermal-ticket {
                display: block !important;
                width: 48mm; /* Printable width */
                margin: 0 auto;
                font-family: monospace;
                font-size: 12px;
                color: #000;
              }
              .thermal-ticket h1 {
                font-size: 16px;
                font-weight: bold;
                text-align: center;
                margin: 0 0 4px 0;
              }
              .thermal-ticket p {
                margin: 2px 0;
              }
              .thermal-ticket .center {
                text-align: center;
              }
              .thermal-ticket .line {
                border-top: 1px dashed #000;
                margin: 6px 0;
              }
              .thermal-ticket .flex-row {
                display: flex;
                justify-content: space-between;
              }
              @page {
                size: 58mm auto;
                margin: 0;
              }
            }
            @media screen {
              .thermal-ticket {
                display: none !important;
              }
            }
          `}</style>
        )}

        <div className="p-4 sm:p-5 border-b flex items-center justify-between no-print">
          <div>
            <h2 className="text-xl font-semibold text-primary">Your Ticket</h2>
            <p className="text-sm text-gray-500">Responsive e-ticket view</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="print-wrapper">
          {/* ════════ Thermal Ticket Output (Only visible on paper) ════════ */}
          {allowThermalPrint && (
            <div className="thermal-ticket">
              <h1>{booking.listingName}</h1>
              <p className="center">Digital Entry Ticket</p>
              <div className="line"></div>
              <p>
                <strong>ID:</strong> {booking.bookingId}
              </p>
              {booking.selectedOffering && (
                <p>
                  <strong>
                    {booking.listingType?.toLowerCase() === "cinema"
                      ? "Movie"
                      : booking.listingType?.toLowerCase() === "event"
                        ? "Event"
                        : "Package"}
                    :
                  </strong>{" "}
                  {booking.selectedOffering}
                </p>
              )}
              <p>
                <strong>Date:</strong> {displayDate}
              </p>
              {booking.location && booking.location !== "N/A" && (
                <p>
                  <strong>Location:</strong> {booking.location}
                </p>
              )}
              <p>
                <strong>Slot:</strong> {displaySlot}
              </p>
              <div className="line"></div>
              <p>Qty: {booking.quantity}</p>
              {booking.selectedSeats && booking.selectedSeats.length > 0 && (
                <p>
                  <strong>Seats:</strong> {booking.selectedSeats.join(", ")}
                </p>
              )}
              <div className="flex-row">
                <p>Amount Paid:</p>
                <p>Rs.{booking.totalAmount}</p>
              </div>
              {addOns.length > 0 && (
                <>
                  <p style={{ marginTop: "4px" }}>Add-ons:</p>
                  {addOns.map((a) => (
                    <div key={a.id || a.name} className="flex-row">
                      <p>- {a.name}</p>
                      <p>Rs.{a.price}</p>
                    </div>
                  ))}
                </>
              )}
              <div className="line"></div>
              <div className="center" style={{ margin: "10px 0" }}>
                {thermalQrUrl && (
                  <img
                    src={thermalQrUrl}
                    alt="QR Code"
                    style={{
                      display: "block",
                      margin: "0 auto",
                      width: "160px",
                      height: "160px",
                    }}
                  />
                )}
              </div>
              <p className="center">Show at entrance</p>
              <p
                className="center"
                style={{ fontSize: "10px", marginTop: "10px" }}
              >
                Valid until: {displayValidUntil}
              </p>
              <div
                className="line"
                style={{ marginTop: "10px", marginBottom: "10px" }}
              ></div>
              <p
                className="center"
                style={{ fontSize: "10px", fontWeight: "bold" }}
              >
                Powered by TiketWala
              </p>
              <p className="center" style={{ margin: "10px 0" }}>
                - - - - - -
              </p>
            </div>
          )}

          {/* ════════ Screen Ticket (Visible on Screen) ════════ */}
          <div className="screen-ticket p-5 sm:p-6">
            <div className="rounded-[28px] overflow-hidden border border-gray-100">
              <div className="bg-primary px-5 py-6 text-white text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <span className="material-symbols-outlined text-3xl">
                    confirmation_number
                  </span>
                  <span className="text-2xl font-bold">TiketWala</span>
                </div>
                <p className="text-white/80 text-sm">Digital Entry Ticket</p>
              </div>

              <div className="p-5 sm:p-6 bg-white">
                <div className="flex justify-center mb-5">
                  <div className="p-4 bg-accent rounded-2xl">
                    <StyledQR data={qrData} size={220} />
                  </div>
                </div>

                <div className="text-center mb-5">
                  <p className="text-xs text-gray-500 uppercase tracking-[0.2em]">
                    Booking ID
                  </p>
                  <p className="text-lg font-mono font-bold text-primary mt-1 break-all">
                    {booking.bookingId}
                  </p>
                </div>

                <div className="space-y-3 border-t-2 border-dashed border-gray-200 pt-4">
                  <TicketRow label="Venue" value={booking.listingName} />
                  {booking.location && booking.location !== "N/A" && (
                    <TicketRow label="Location" value={booking.location} />
                  )}
                  {booking.selectedOffering && (
                    <TicketRow
                      label={
                        booking.listingType?.toLowerCase() === "cinema"
                          ? "Movie"
                          : booking.listingType?.toLowerCase() === "event"
                            ? "Event"
                            : "Package"
                      }
                      value={booking.selectedOffering}
                    />
                  )}
                  <TicketRow label="Date" value={displayDate} />
                  <TicketRow label="Time Slot" value={displaySlot} />
                  <TicketRow
                    label="Visitors"
                    value={`${booking.quantity} ${
                      booking.quantity === 1 ? "person" : "people"
                    }`}
                  />
                  {booking.selectedSeats && booking.selectedSeats.length > 0 && (
                    <TicketRow
                      label="Seats"
                      value={booking.selectedSeats.join(", ")}
                    />
                  )}
                  <TicketRow
                    label="Amount Paid"
                    value={`₹${booking.totalAmount}`}
                    strong
                  />
                </div>

                {addOns.length > 0 && (
                  <div className="mt-5 border-t-2 border-dashed border-gray-200 pt-4">
                    <p className="text-sm font-semibold text-primary mb-3">
                      Selected Add-ons
                    </p>
                    <div className="space-y-2">
                      {addOns.map((addOn) => (
                        <div
                          key={addOn.id || addOn.name}
                          className="flex items-start justify-between gap-3 text-sm"
                        >
                          <span className="text-gray-700">{addOn.name}</span>
                          <span className="font-medium text-primary">
                            ₹{addOn.price}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mt-5 pt-4 border-t-2 border-dashed border-gray-200 text-center">
                  <p className="text-xs text-gray-400">
                    Present this QR code at the entrance
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    Valid until: {displayValidUntil}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 sm:p-5 border-t bg-gray-50 rounded-b-3xl flex flex-col sm:flex-row gap-3 screen-ticket">
          {allowThermalPrint ? (
            <>
              <button
                onClick={handleDownload}
                disabled={downloading || downloadingPdf}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white text-primary border border-primary/20 rounded-xl hover:bg-primary/5 transition-colors disabled:opacity-60"
              >
                <span className="material-symbols-outlined">download</span>
                {downloading ? "Preparing..." : "Download PNG"}
              </button>
              <button
                onClick={handlePrint}
                disabled={!thermalQrUrl}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-60"
              >
                <span className="material-symbols-outlined">print_connect</span>
                Print Thermal
              </button>
            </>
          ) : (
            <button
              onClick={handleDownloadPdf}
              disabled={downloading || downloadingPdf}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-60"
            >
              <span className="material-symbols-outlined">picture_as_pdf</span>
              {downloadingPdf ? "Preparing PDF..." : "Download PDF"}
            </button>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
            >
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function TicketRow({ label, value, strong = false }) {
  return (
    <div
      className={`flex items-start justify-between gap-4 ${
        strong ? "font-semibold text-primary" : ""
      }`}
    >
      <span className="text-gray-500 text-sm">{label}</span>
      <span
        className={`text-right ${
          strong ? "font-bold" : "font-medium text-gray-800"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = String(text || "").split(" ");
  let line = "";
  let currentY = y;

  words.forEach((word, index) => {
    const nextLine = `${line}${word} `;
    const metrics = ctx.measureText(nextLine);
    if (metrics.width > maxWidth && index > 0) {
      ctx.fillText(line.trim(), x, currentY);
      line = `${word} `;
      currentY += lineHeight;
    } else {
      line = nextLine;
    }
  });

  if (line.trim()) {
    ctx.fillText(line.trim(), x, currentY);
  }
}
