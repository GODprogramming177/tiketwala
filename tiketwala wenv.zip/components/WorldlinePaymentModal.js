"use client";

import { useState, useEffect } from "react";
import toast from "react-hot-toast";

export default function WorldlinePaymentModal({
  isOpen,
  onClose,
  amount,
  invoiceNo,
  actionId = "1",
  onSuccess,
  onError
}) {
  const [status, setStatus] = useState("idle"); // idle, initiating, waiting, success, failed, cancelled
  const [transactionId, setTransactionId] = useState(null);

  useEffect(() => {
    let interval;
    if (status === "waiting" && transactionId) {
      interval = setInterval(async () => {
        try {
          const res = await fetch("/api/worldline/status", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ transactionId })
          });
          const data = await res.json();
          
          if (data.status === "success") {
            setStatus("success");
            clearInterval(interval);
            setTimeout(() => {
              if (onSuccess) onSuccess(data);
              onClose();
            }, 2000);
          } else if (data.status === "failed" || data.status === "cancelled" || data.status === "timeout") {
            setStatus(data.status);
            clearInterval(interval);
            if (onError) onError(data);
          }
        } catch (error) {
          console.error("Polling error", error);
        }
      }, 3000); // poll every 3 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [status, transactionId, onSuccess, onError, onClose]);

  const initiatePayment = async () => {
    try {
      setStatus("initiating");
      const res = await fetch("/api/worldline/initiate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ invoiceNo, amount, actionId })
      });
      
      const data = await res.json();
      if (data.success) {
        setTransactionId(data.transactionId);
        setStatus("waiting");
      } else {
        setStatus("failed");
        toast.error(data.error || "Failed to initiate POS payment");
      }
    } catch (error) {
      console.error(error);
      setStatus("failed");
      toast.error("Network error while initiating payment");
    }
  };

  const cancelPayment = async () => {
    if (!transactionId) return;
    try {
      await fetch("/api/worldline/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transactionId })
      });
      setStatus("cancelled");
      toast.error("Transaction cancelled");
    } catch (error) {
      console.error("Cancel error", error);
    }
  };

  useEffect(() => {
    if (isOpen && status === "idle") {
      initiatePayment();
    }
    if (!isOpen) {
      setStatus("idle");
      setTransactionId(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col">
        <div className="bg-primary px-4 py-3 text-white font-bold flex justify-between items-center">
          <span>Worldline POS Terminal</span>
          {(status === "failed" || status === "cancelled" || status === "success") && (
            <button onClick={onClose} className="hover:text-gray-200">
              <span className="material-symbols-outlined">close</span>
            </button>
          )}
        </div>
        
        <div className="p-6 flex flex-col items-center justify-center min-h-[250px] text-center">
          <div className="text-3xl font-bold text-gray-800 mb-2">₹{amount}</div>
          <div className="text-xs text-gray-500 mb-6">Invoice: {invoiceNo}</div>

          {status === "initiating" && (
            <div className="flex flex-col items-center">
              <span className="material-symbols-outlined text-4xl text-blue-500 animate-pulse mb-3">wifi_tethering</span>
              <p className="text-sm font-medium text-gray-600">Sending request to terminal...</p>
            </div>
          )}

          {status === "waiting" && (
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 border-4 border-gray-200 border-t-primary rounded-full animate-spin mb-4"></div>
              <p className="text-sm font-medium text-gray-800">Waiting for customer payment...</p>
              <p className="text-xs text-gray-500 mt-2">Please tap card or scan QR on terminal</p>
              
              <button 
                onClick={cancelPayment}
                className="mt-6 text-red-500 text-sm font-medium hover:underline flex items-center gap-1"
              >
                <span className="material-symbols-outlined text-sm">cancel</span>
                Cancel Transaction
              </button>
            </div>
          )}

          {status === "success" && (
            <div className="flex flex-col items-center animate-in fade-in zoom-in">
              <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-4xl">check_circle</span>
              </div>
              <p className="text-lg font-bold text-green-700">Payment Successful</p>
            </div>
          )}

          {(status === "failed" || status === "cancelled" || status === "timeout") && (
            <div className="flex flex-col items-center animate-in fade-in zoom-in">
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-4xl">error</span>
              </div>
              <p className="text-lg font-bold text-red-700 capitalize">Payment {status}</p>
              <button 
                onClick={initiatePayment}
                className="mt-4 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg text-sm font-medium"
              >
                Retry
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
